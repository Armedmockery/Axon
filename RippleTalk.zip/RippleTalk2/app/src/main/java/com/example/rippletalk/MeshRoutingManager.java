package com.example.rippletalk;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class MeshRoutingManager {
    private static final String TAG = "MeshRoutingManager";
    private static final int MAX_HOPS = 5;
    private static final long ROUTE_TIMEOUT = 60000;
    private static final long MESSAGE_TIMEOUT = 300000;

    private DeviceMappingDao deviceMappingDao;
    private BluetoothMeshManager meshManager;
    private AuthenticationManager authManager;

    private Map<String, RouteInfo> routingTable = new ConcurrentHashMap<>();
    private Map<String, MeshMessage> pendingMessages = new ConcurrentHashMap<>();
    private Map<String, Long> messageTimestamps = new ConcurrentHashMap<>();

    public static class RouteInfo {
        public String nextHop;
        public int hopCount;
        public long lastUpdated;
        public int reliability;

        public RouteInfo(String nextHop, int hopCount) {
            this.nextHop = nextHop;
            this.hopCount = hopCount;
            this.lastUpdated = System.currentTimeMillis();
            this.reliability = 100;
        }
    }

    public static class MeshMessage {
        public String messageId;
        public String sourcePhone;
        public String targetPhone;
        public String content;
        public int currentHop;
        public int maxHops;
        public List<String> path;
        public long timestamp;
        public String type;

        public MeshMessage(String source, String target, String content) {
            this.messageId = UUID.randomUUID().toString().substring(0, 8);
            this.sourcePhone = source;
            this.targetPhone = target;
            this.content = content;
            this.currentHop = 0;
            this.maxHops = MAX_HOPS;
            this.path = new ArrayList<>();
            this.timestamp = System.currentTimeMillis();
            this.type = "DIRECT";
        }
    }

    public MeshRoutingManager(DeviceMappingDao deviceMappingDao, BluetoothMeshManager meshManager, AuthenticationManager authManager) {
        this.deviceMappingDao = deviceMappingDao;
        this.meshManager = meshManager;
        this.authManager = authManager;
        startCleanupThread();
    }

    private void startCleanupThread() {
        new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep(30000);
                    cleanupOldMessages();
                    cleanupOldRoutes();
                } catch (InterruptedException e) {
                    break;
                }
            }
        }).start();
    }

    public RouteInfo findOptimalRoute(String targetPhone) {
        if (meshManager.isDeviceInRange(targetPhone)) {
            RouteInfo directRoute = new RouteInfo(targetPhone, 1);
            routingTable.put(targetPhone, directRoute);
            return directRoute;
        }

        List<DeviceMapping> nearbyDevices = deviceMappingDao.getRecentDevices(System.currentTimeMillis() - 120000);
        RouteInfo bestRoute = null;

        for (DeviceMapping device : nearbyDevices) {
            if (device.isRouter &&
                    !device.phoneNumber.equals(targetPhone) &&
                    !device.phoneNumber.equals(authManager.getAuthenticatedUser()) &&
                    meshManager.isDeviceInRange(device.phoneNumber)) {

                RouteInfo route = new RouteInfo(device.phoneNumber, 2);

                if (bestRoute == null || device.signalStrength > getDeviceSignalStrength(bestRoute.nextHop)) {
                    bestRoute = route;
                }
            }
        }

        if (bestRoute != null) {
            routingTable.put(targetPhone, bestRoute);
            Log.d(TAG, "Found optimal route to " + targetPhone + " via " + bestRoute.nextHop);
        }

        return bestRoute;
    }

    private int getDeviceSignalStrength(String phoneNumber) {
        return -70;
    }

    public boolean sendMessage(String targetPhone, String message) {
        String currentUser = authManager.getAuthenticatedUser();
        if (currentUser == null) {
            Log.e(TAG, "No authenticated user");
            return false;
        }

        MeshMessage meshMessage = new MeshMessage(currentUser, targetPhone, message);
        RouteInfo route = findOptimalRoute(targetPhone);

        if (route == null) {
            Log.w(TAG, "No route found to: " + targetPhone);
            return false;
        }

        pendingMessages.put(meshMessage.messageId, meshMessage);
        messageTimestamps.put(meshMessage.messageId, System.currentTimeMillis());

        Log.d(TAG, "Sending message via route: " + targetPhone + " via " + route.nextHop + " (hops: " + route.hopCount + ")");
        return forwardMessageToNextHop(meshMessage, route.nextHop);
    }

    private boolean forwardMessageToNextHop(MeshMessage meshMessage, String nextHop) {
        meshMessage.currentHop++;
        meshMessage.path.add(nextHop);

        if (meshMessage.currentHop > meshMessage.maxHops) {
            Log.e(TAG, "Message exceeded max hops: " + meshMessage.messageId);
            pendingMessages.remove(meshMessage.messageId);
            messageTimestamps.remove(meshMessage.messageId);
            return false;
        }

        String forwardedMessage = formatMeshMessage(meshMessage);

        // ✅ FIXED: Use public method with automatic routing
        boolean success = meshManager.sendMessageToContact(nextHop, forwardedMessage);

        Log.d(TAG, "🔄 Forwarding message to " + nextHop + " (hop " + meshMessage.currentHop + "/" + meshMessage.maxHops + ") - Success: " + success);

        return success;
    }
    public void handleIncomingMeshMessage(String rawMessage) {
        try {
            MeshMessage meshMessage = parseMeshMessage(rawMessage);
            if (meshMessage == null) return;

            String currentUser = authManager.getAuthenticatedUser();
            if (currentUser == null) return;

            if (meshMessage.targetPhone.equals(currentUser)) {
                Log.d(TAG, "Mesh message delivered to us: " + meshMessage.content);
                deliverMessageToApp(meshMessage);
            } else {
                Log.d(TAG, "Forwarding mesh message from " + meshMessage.sourcePhone + " to " + meshMessage.targetPhone);
                forwardMeshMessage(meshMessage);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error handling mesh message", e);
        }
    }

    private void forwardMeshMessage(MeshMessage meshMessage) {
        if (meshMessage.path.contains(authManager.getAuthenticatedUser())) {
            Log.w(TAG, "Message loop detected, dropping: " + meshMessage.messageId);
            return;
        }

        RouteInfo route = findOptimalRoute(meshMessage.targetPhone);
        if (route != null) {
            forwardMessageToNextHop(meshMessage, route.nextHop);
        } else {
            Log.w(TAG, "No route for forwarding message to: " + meshMessage.targetPhone);
        }
    }

    private void deliverMessageToApp(MeshMessage meshMessage) {
        if (meshManager.meshCallback != null) {
            meshManager.handler.post(() ->
                    meshManager.meshCallback.onMessageReceived(meshMessage.sourcePhone, meshMessage.content)
            );
        }
    }

    private String formatMeshMessage(MeshMessage meshMessage) {
        return String.format("MESH|%s|%s|%s|%d|%d|%s",
                meshMessage.messageId,
                meshMessage.sourcePhone,
                meshMessage.targetPhone,
                meshMessage.currentHop,
                meshMessage.maxHops,
                meshMessage.content);
    }

    private MeshMessage parseMeshMessage(String rawMessage) {
        try {
            if (!rawMessage.startsWith("MESH|")) {
                return null;
            }

            String[] parts = rawMessage.split("\\|", 7);
            if (parts.length != 7) {
                Log.e(TAG, "Invalid mesh message format: " + rawMessage);
                return null;
            }

            MeshMessage meshMessage = new MeshMessage(parts[2], parts[3], parts[6]);
            meshMessage.messageId = parts[1];
            meshMessage.currentHop = Integer.parseInt(parts[4]);
            meshMessage.maxHops = Integer.parseInt(parts[5]);

            return meshMessage;

        } catch (Exception e) {
            Log.e(TAG, "Error parsing mesh message: " + rawMessage, e);
            return null;
        }
    }

    public void updateRoutes(List<DeviceMapping> discoveredDevices) {
        Log.d(TAG, "Updating routes for " + discoveredDevices.size() + " devices");
        for (DeviceMapping device : discoveredDevices) {
            if (meshManager.isDeviceInRange(device.phoneNumber)) {
                RouteInfo route = new RouteInfo(device.phoneNumber, 1);
                routingTable.put(device.phoneNumber, route);
                Log.d(TAG, "Route updated for: " + device.phoneNumber);
            }
        }
    }

    public RouteInfo getRoute(String targetPhone) {
        RouteInfo route = routingTable.get(targetPhone);
        if (route != null && (System.currentTimeMillis() - route.lastUpdated) > ROUTE_TIMEOUT) {
            routingTable.remove(targetPhone);
            return null;
        }
        return route;
    }

    public void cleanupOldRoutes() {
        long currentTime = System.currentTimeMillis();
        List<String> toRemove = new ArrayList<>();

        for (Map.Entry<String, RouteInfo> entry : routingTable.entrySet()) {
            if (currentTime - entry.getValue().lastUpdated > ROUTE_TIMEOUT) {
                toRemove.add(entry.getKey());
            }
        }

        for (String phone : toRemove) {
            routingTable.remove(phone);
            Log.d(TAG, "Removed old route for: " + phone);
        }
    }

    private void cleanupOldMessages() {
        long currentTime = System.currentTimeMillis();
        List<String> toRemove = new ArrayList<>();

        for (Map.Entry<String, Long> entry : messageTimestamps.entrySet()) {
            if (currentTime - entry.getValue() > MESSAGE_TIMEOUT) {
                toRemove.add(entry.getKey());
            }
        }

        for (String messageId : toRemove) {
            pendingMessages.remove(messageId);
            messageTimestamps.remove(messageId);
            Log.d(TAG, "Removed expired message: " + messageId);
        }
    }
}