package com.example.rippletalk;

import android.util.Log;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class RelayService {
    private static final String TAG = "RelayService";
    private final String myId;
    private final RelayCallback cb;

    private final Set<String> seenMessageIds = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final ConcurrentHashMap<String, Long> pendingAcks = new ConcurrentHashMap<>();

    // ✅ ADDED SHUTDOWN FLAG
    private volatile boolean running = true;

    public interface RelayCallback {
        void onMessageDelivered(String from, String message);
        void onMessageAcknowledged(String messageId);
        void onMessageFailed(String messageId);
        void onRelayMessage(String json); // For forwarding hop2hop messages
    }

    public RelayService(String myId, RelayCallback cb) {
        this.myId = myId;
        this.cb = cb;

        // Periodic pending-ACK cleanup
        new Thread(() -> {
            try {
                while (running) {
                    Thread.sleep(30000);
                    if (running) {
                        cleanupOldAcks();
                    }
                }
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }, "AckCleaner").start();
    }

    public void handleIncoming(String json, String interfaceType) {
        // ✅ ADD NULL AND EMPTY CHECKING
        if (json == null || json.trim().isEmpty()) {
            Log.e(TAG, "Received null or empty JSON");
            return;
        }

        MeshEnvelope env = MeshEnvelope.fromJson(json);
        if (env == null) {
            Log.e(TAG, "Failed to parse MeshEnvelope from JSON: " + json);
            return;
        }

        // ✅ NOW SAFE TO USE env
        env.addPathStep(interfaceType);
        String msgId = env.getMessageId();

        if (!seenMessageIds.add(msgId)) {
            Log.d(TAG, "Duplicate message ignored: " + msgId);
            return;
        }
        if (seenMessageIds.size() > 2000) seenMessageIds.clear();

        if (env.isAck()) {
            handleAck(env, interfaceType);
            return;
        }

        if (env.getDestId().equals(myId) || "BROADCAST".equals(env.getDestId())) {
            deliver(env, interfaceType);
        } else {
            relay(env, interfaceType);
        }
    }

    private void handleAck(MeshEnvelope ack, String interfaceType) {
        String original = ack.getAckedMessageId();
        if (original != null && pendingAcks.remove(original) != null) {
            cb.onMessageAcknowledged(original);
            Log.d(TAG, "ACK received for " + original);
        } else if (!ack.getDestId().equals(myId)) {
            // Forward ACK onwards
            forwardJson(ack.toJson(), interfaceType);
        }
    }

    private void deliver(MeshEnvelope env, String interfaceType) {
        Log.d(TAG, "Hop2Hop delivered from " + env.getSourceId() + " via " + interfaceType + ": " + env.getPayload());
        cb.onMessageDelivered(env.getSourceId(), env.getPayload());

        if (env.requiresAck() && !env.getSourceId().equals(myId)) {
            MeshEnvelope ack = new MeshEnvelope(env.getMessageId(), myId, env.getSourceId(), true);
            forwardJson(ack.toJson(), interfaceType);
            Log.d(TAG, "ACK sent for " + env.getMessageId());
        }
    }

    private void relay(MeshEnvelope env, String interfaceType) {
        if (env.getHopCount() <= 0) {
            Log.d(TAG, "Hop limit reached: " + env.getMessageId());
            if (env.requiresAck()) {
                MeshEnvelope nack = new MeshEnvelope(env.getMessageId(), myId, env.getSourceId(), false);
                forwardJson(nack.toJson(), interfaceType);
            }
            return;
        }
        env.decrementHop();
        String json = env.toJson();
        forwardJson(json, interfaceType);
        Log.d(TAG, "Relayed → " + env.getDestId() + " | hops left: " + env.getHopCount());
    }

    private void forwardJson(String json, String incomingInterface) {
        cb.onRelayMessage(json);
    }

    public String createOutgoing(String destId, String payload, int maxHops, boolean requireAck) {
        MeshEnvelope env = new MeshEnvelope(myId, destId, payload, maxHops, requireAck);
        if (requireAck) pendingAcks.put(env.getMessageId(), System.currentTimeMillis());
        return env.toJson();
    }

    private void cleanupOldAcks() {
        long now = System.currentTimeMillis();
        pendingAcks.entrySet().removeIf(e -> {
            boolean expired = now - e.getValue() > 60000;
            if (expired) cb.onMessageFailed(e.getKey());
            return expired;
        });
    }

    // ✅ ADDED CLEANUP METHOD
    public void cleanup() {
        running = false;
        seenMessageIds.clear();
        pendingAcks.clear();
    }
}