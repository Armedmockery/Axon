package com.example.rippletalk;

import android.content.Context;
import android.content.SharedPreferences;
import android.telephony.SmsManager;
import android.util.Log;

import java.util.concurrent.ConcurrentHashMap;

public class AuthenticationManager {

    private static final String TAG = "AuthenticationManager";
    private static final String PREFS_NAME = "AxonAuth";
    private static final String KEY_IS_AUTHENTICATED = "is_authenticated";
    private static final String KEY_USER_PHONE = "user_phone";
    private static final String KEY_USER_NAME = "user_name";

    // Server SIM number (Phone A with OTP Server App)
    private static final String GSM_MODEM_NUMBER = "+919860206205";
    private static final String OTP_COMMAND = "REGISTER";
    private static final int OTP_VALIDITY_MS = 5 * 60 * 1000; // 5 min

    // Singleton instance
    private static AuthenticationManager instance;
    private final Context context;
    private final SharedPreferences prefs;
    private final ConcurrentHashMap<String, OTPData> otpStorage = new ConcurrentHashMap<>();
    private AuthenticationCallback callback;
    private String lastPhoneNumber;

    // Private constructor
    private AuthenticationManager(Context context) {
        this.context = context.getApplicationContext();
        prefs = this.context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // Singleton getInstance method
    public static synchronized AuthenticationManager getInstance(Context context) {
        if (instance == null) {
            instance = new AuthenticationManager(context);
        }
        return instance;
    }

    public void setCallback(AuthenticationCallback callback) {
        this.callback = callback;
    }

    public void setLastPhoneNumber(String phoneNumber) {
        this.lastPhoneNumber = phoneNumber;
        Log.d(TAG, "📞 Last phone number set: " + phoneNumber);
    }

    public interface AuthenticationCallback {
        void onAuthenticationSuccess();
        void onAuthenticationFailed(String reason);
        void onOTPSent();
        void onOTPReceived(String otp);
    }

    public boolean isUserAuthenticated() {
        return prefs.getBoolean(KEY_IS_AUTHENTICATED, false);
    }

    public void setUserAuthenticated(boolean isAuthenticated) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_IS_AUTHENTICATED, isAuthenticated);

        if (!isAuthenticated) {
            editor.remove(KEY_USER_PHONE);
            editor.remove(KEY_USER_NAME);
        }
        editor.apply();

        Log.d(TAG, "✅ Authentication status set to: " + isAuthenticated);
    }

    public void setUserName(String userName) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_USER_NAME, userName);
        editor.apply();

        Log.d(TAG, "✅ Username set to: " + userName);
    }

    public String getAuthenticatedUser() {
        return prefs.getString(KEY_USER_PHONE, null);
    }

    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, null);
    }

    public String getDisplayName() {
        String userName = getUserName();
        String phone = getAuthenticatedUser();

        if (userName != null && !userName.trim().isEmpty()) {
            return userName;
        }

        if (phone != null) {
            return maskPhoneNumber(phone);
        }

        return "User";
    }

    private String maskPhoneNumber(String phone) {
        if (phone == null || phone.length() < 4) return "User";

        int length = phone.length();
        if (length <= 4) {
            return "User";
        }

        if (phone.startsWith("+") && length > 6) {
            String countryCode = phone.substring(0, 3);
            String maskedPart = "XXXXX";
            String visiblePart = phone.substring(length - 4);
            return countryCode + maskedPart + visiblePart;
        } else {
            String maskedPart = "XXXXX";
            String visiblePart = phone.substring(length - 4);
            return maskedPart + visiblePart;
        }
    }

    public void logout() {
        prefs.edit()
                .remove(KEY_IS_AUTHENTICATED)
                .remove(KEY_USER_PHONE)
                .remove(KEY_USER_NAME)
                .apply();
        otpStorage.clear();
    }

    // ✅ FIXED: Store OTP for the specific phone number that was requested
    public void startAuthentication(String phoneNumber) {
        try {
            // Set the phone number first
            setLastPhoneNumber(phoneNumber);

            SmsManager smsManager = SmsManager.getDefault();
            String msg = OTP_COMMAND + " " + phoneNumber;
            smsManager.sendTextMessage(GSM_MODEM_NUMBER, null, msg, null, null);

            if (callback != null) callback.onOTPSent();
            Log.d(TAG, "✅ Sent registration SMS for phone: " + phoneNumber + " - Message: " + msg);
        } catch (Exception e) {
            if (callback != null) callback.onAuthenticationFailed("Failed to send SMS: " + e.getMessage());
            Log.e(TAG, "❌ Error sending SMS for phone: " + phoneNumber, e);
        }
    }

    // ✅ FIXED: Store OTP with phone number from the SMS
    public void storeOTP(String otp, String targetPhoneNumber) {
        if (targetPhoneNumber != null && !targetPhoneNumber.isEmpty()) {
            Log.d(TAG, "💾 Storing OTP: " + otp + " for phone: " + targetPhoneNumber);
            otpStorage.put(targetPhoneNumber, new OTPData(otp));

            // Also update lastPhoneNumber to match the OTP target
            setLastPhoneNumber(targetPhoneNumber);

            if (callback != null) callback.onOTPReceived(otp);
        } else {
            Log.d(TAG, "❌ Cannot store OTP: No phone number provided");
        }
    }

    // ✅ FIXED: Verify OTP for specific phone number
    public boolean verifyOTP(String otp, String phoneNumber) {
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Log.d(TAG, "❌ Cannot verify OTP: No phone number provided");
            if (callback != null) callback.onAuthenticationFailed("Phone number not found");
            return false;
        }

        Log.d(TAG, "🔍 Verifying OTP: " + otp + " for phone: " + phoneNumber);

        OTPData otpData = otpStorage.get(phoneNumber);

        if (otpData == null) {
            Log.d(TAG, "❌ OTP not found in storage for phone: " + phoneNumber);
            Log.d(TAG, "📊 Available OTPs in storage: " + otpStorage.keySet());
            if (callback != null) callback.onAuthenticationFailed("OTP expired or not found");
            return false;
        }

        if (otpData.isExpired()) {
            Log.d(TAG, "❌ OTP expired: " + otpData.otp + " for phone: " + phoneNumber);
            otpStorage.remove(phoneNumber); // Clean up expired OTP
            if (callback != null) callback.onAuthenticationFailed("OTP expired");
            return false;
        }

        Log.d(TAG, "✅ Stored OTP: " + otpData.otp + ", Entered OTP: " + otp);
        boolean isMatch = otpData.otp.equals(otp);
        Log.d(TAG, "✅ OTP Match: " + isMatch + " for phone: " + phoneNumber);

        if (!isMatch) {
            if (callback != null) callback.onAuthenticationFailed("Invalid OTP");
            return false;
        }

        // Clean up and authenticate
        otpStorage.remove(phoneNumber);
        setLastPhoneNumber(phoneNumber);
        prefs.edit()
                .putBoolean(KEY_IS_AUTHENTICATED, true)
                .putString(KEY_USER_PHONE, phoneNumber)
                .apply();

        if (callback != null) callback.onAuthenticationSuccess();
        return true;
    }

    // Overloaded method for backward compatibility
    public boolean verifyOTP(String otp) {
        if (lastPhoneNumber != null) {
            return verifyOTP(otp, lastPhoneNumber);
        } else {
            Log.d(TAG, "❌ Cannot verify OTP: No last phone number set");
            return false;
        }
    }

    // ✅ ADD: Method to get phone number for BLE advertising
    public String getPhoneNumberForAdvertising() {
        String phone = prefs.getString(KEY_USER_PHONE, null);

        if (phone == null) {
            Log.e(TAG, "❌ No phone number found in shared preferences for BLE advertising");
            // Try to get from last phone number used
            if (lastPhoneNumber != null) {
                Log.d(TAG, "✅ Using last phone number: " + lastPhoneNumber);
                return lastPhoneNumber;
            }

            // Try to extract from authenticated user
            String currentUser = getAuthenticatedUser();
            if (currentUser != null && currentUser.matches(".*\\d.*")) {
                String cleanPhone = currentUser.replaceAll("[^0-9]", "");
                if (cleanPhone.matches("^[0-9]{10,15}$")) {
                    Log.d(TAG, "✅ Extracted phone from authenticated user: " + cleanPhone);
                    return cleanPhone;
                }
            }

            Log.e(TAG, "❌❌❌ CRITICAL: No phone number available for BLE advertising!");
            return null;
        }

        Log.d(TAG, "📱 Phone number retrieved for BLE advertising: " + phone);
        return phone;
    }

    // ✅ ADD: Check if phone number is valid for advertising
    public boolean hasValidPhoneForAdvertising() {
        String phone = getPhoneNumberForAdvertising();
        if (phone == null) {
            Log.e(TAG, "❌ No phone number available for advertising");
            return false;
        }

        boolean isValid = phone.matches("^[0-9]{10,15}$");
        Log.d(TAG, "📱 Phone validation: " + phone + " -> " + isValid);
        return isValid;
    }

    // ✅ ADD: Debug method to show phone number status
    public void debugPhoneNumberStatus() {
        Log.d(TAG, "=== PHONE NUMBER DEBUG ===");
        Log.d(TAG, "1. Authenticated User: " + getAuthenticatedUser());
        Log.d(TAG, "2. Last Phone Number: " + lastPhoneNumber);
        Log.d(TAG, "3. Phone for Advertising: " + getPhoneNumberForAdvertising());
        Log.d(TAG, "4. Has Valid Phone: " + hasValidPhoneForAdvertising());
        Log.d(TAG, "5. Is Authenticated: " + isUserAuthenticated());
        Log.d(TAG, "6. Stored OTP Phones: " + getStoredOTPPhones());

        // Check SharedPreferences directly
        String storedPhone = prefs.getString(KEY_USER_PHONE, "NOT_FOUND");
        Log.d(TAG, "7. SharedPrefs Phone: " + storedPhone);

        if (!hasValidPhoneForAdvertising()) {
            Log.e(TAG, "❌❌❌ PROBLEM: No valid phone number for BLE advertising!");
        } else {
            Log.d(TAG, "✅✅✅ SUCCESS: Phone number available for BLE advertising!");
        }
    }


    // Helper method to check if OTP exists for a phone number
    public boolean hasOTPForPhone(String phoneNumber) {
        OTPData otpData = otpStorage.get(phoneNumber);
        return otpData != null && !otpData.isExpired();
    }

    // Helper method to get stored phone numbers with OTPs
    public String getStoredOTPPhones() {
        return otpStorage.keySet().toString();
    }

    private static class OTPData {
        String otp;
        long timestamp;

        OTPData(String otp) {
            this.otp = otp;
            this.timestamp = System.currentTimeMillis();
        }

        boolean isExpired() {
            return System.currentTimeMillis() - timestamp > OTP_VALIDITY_MS;
        }
    }
}