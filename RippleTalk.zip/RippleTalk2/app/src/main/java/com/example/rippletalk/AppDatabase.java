package com.example.rippletalk;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {DeviceMapping.class, ChatMessage.class}, version = 4, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract DeviceMappingDao deviceMappingDao();
    public abstract ChatMessageDao chatMessageDao();

    private static volatile AppDatabase INSTANCE;

    // Migration from version 3 to 4 - Add contactName column
    static final Migration MIGRATION_3_4 = new Migration(3, 4) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Add the new contactName column
            database.execSQL("ALTER TABLE device_mappings ADD COLUMN contactName TEXT DEFAULT ''");
        }
    };

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "rippletalk_database"
                            ).addMigrations(MIGRATION_3_4)
                            .fallbackToDestructiveMigration() // Fallback if migration fails
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}