package com.example.rippletalk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class OtpActivity extends AppCompatActivity {

    private static final String TAG = "OtpActivity";
    private EditText[] otpBoxes = new EditText[6];
    private Button verifyOtpButton, resendOtpButton;
    private ProgressBar progressBar;
    private TextView statusText, phoneNumberText;
    private AuthenticationManager authManager;
    private String currentPhoneNumber;
    private String currentUserName;

    private BroadcastReceiver otpReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "📩 OTP Broadcast received");
            if ("OTP_RECEIVED".equals(intent.getAction())) {
                String otp = intent.getStringExtra("otp");
                String receivedPhoneNumber = intent.getStringExtra("phone_number");

                Log.d(TAG, "📱 OTP: " + otp + ", Phone: " + receivedPhoneNumber);

                if (otp != null && otp.length() == 6) {
                    // Auto-fill the OTP boxes
                    for (int i = 0; i < 6; i++) {
                        if (i < otp.length()) {
                            otpBoxes[i].setText(String.valueOf(otp.charAt(i)));
                        }
                    }
                    showInfo("OTP auto-filled");

                    // Use received phone number or current one
                    String targetPhoneNumber = receivedPhoneNumber != null ? receivedPhoneNumber : currentPhoneNumber;
                    Log.d(TAG, "🎯 Verifying for phone: " + targetPhoneNumber);

                    if (targetPhoneNumber != null) {
                        showProgress("Verifying OTP...");
                        authManager.setLastPhoneNumber(targetPhoneNumber);
                        authManager.verifyOTP(otp, targetPhoneNumber);
                    } else {
                        Log.e(TAG, "❌ No phone number available for OTP verification");
                        showError("Phone number not found");
                    }
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "🚀 OtpActivity onCreate");

        setContentView(R.layout.activity_otp);

        // Get phone number and username from intent
        currentPhoneNumber = getIntent().getStringExtra("PHONE_NUMBER");
        currentUserName = getIntent().getStringExtra("USER_NAME");

        Log.d(TAG, "📞 Phone: " + currentPhoneNumber + ", User: " + currentUserName);

        if (currentPhoneNumber == null) {
            Log.e(TAG, "❌ No phone number provided, finishing activity");
            finish();
            return;
        }

        initializeViews();
        setupOtpBoxes();
        setupAuthManager();
        setupButtonListeners();
    }

    private void initializeViews() {
        try {
            otpBoxes[0] = findViewById(R.id.otpBox1);
            otpBoxes[1] = findViewById(R.id.otpBox2);
            otpBoxes[2] = findViewById(R.id.otpBox3);
            otpBoxes[3] = findViewById(R.id.otpBox4);
            otpBoxes[4] = findViewById(R.id.otpBox5);
            otpBoxes[5] = findViewById(R.id.otpBox6);

            verifyOtpButton = findViewById(R.id.verifyOtpButton);
            resendOtpButton = findViewById(R.id.resendOtpButton);
            progressBar = findViewById(R.id.progressBar);
            statusText = findViewById(R.id.statusText);
            phoneNumberText = findViewById(R.id.phoneNumberText);

            // Display phone number
            if (phoneNumberText != null) {
                phoneNumberText.setText("Phone: " + currentPhoneNumber);
            }

            Log.d(TAG, "✅ Views initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "❌ Error initializing views: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing OTP screen", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void setupAuthManager() {
        try {
            authManager = AuthenticationManager.getInstance(this);
            authManager.setCallback(new AuthenticationManager.AuthenticationCallback() {
                @Override
                public void onAuthenticationSuccess() {
                    Log.d(TAG, "✅ Authentication successful!");
                    hideProgress();
                    showInfo("Authentication successful!");

                    // Save user data
                    SharedPreferences prefs = getSharedPreferences("OTP_Prefs", MODE_PRIVATE);
                    prefs.edit()
                            .putString("LAST_USER_NAME", currentUserName)
                            .putString("LAST_PHONE_NUMBER", currentPhoneNumber)
                            .apply();

                    Log.d(TAG, "📝 Saved user data: " + currentUserName + ", " + currentPhoneNumber);

                    // Redirect to MainActivity
                    Intent intent = new Intent(OtpActivity.this, MainActivity.class);
                    intent.putExtra("USER_NAME", currentUserName);
                    intent.putExtra("PHONE_NUMBER", currentPhoneNumber);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);

                    Log.d(TAG, "🔄 Starting MainActivity...");
                    startActivity(intent);
                    finish();
                }

                @Override
                public void onAuthenticationFailed(String reason) {
                    Log.e(TAG, "❌ Authentication failed: " + reason);
                    hideProgress();
                    showError(reason);
                }

                @Override
                public void onOTPSent() {
                    Log.d(TAG, "📤 OTP sent successfully");
                    hideProgress();
                    showInfo("OTP sent successfully!");
                    enableResendButtonAfterDelay();
                }

                @Override
                public void onOTPReceived(String otp) {
                    Log.d(TAG, "📥 OTP received callback: " + otp);
                    // Handled by broadcast receiver
                }
            });
            Log.d(TAG, "✅ AuthManager setup complete");
        } catch (Exception e) {
            Log.e(TAG, "❌ Error setting up AuthManager: " + e.getMessage(), e);
            Toast.makeText(this, "Authentication error", Toast.LENGTH_LONG).show();
        }
    }

    private void setupOtpBoxes() {
        for (int i = 0; i < otpBoxes.length; i++) {
            final int currentIndex = i;
            if (otpBoxes[i] != null) {
                otpBoxes[i].addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if (s.length() == 1 && currentIndex < otpBoxes.length - 1) {
                            otpBoxes[currentIndex + 1].requestFocus();
                        }

                        // Auto-verify if all boxes are filled
                        if (isAllBoxesFilled()) {
                            Log.d(TAG, "⚡ All OTP boxes filled, auto-verifying...");
                            verifyOTP();
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {}
                });

                // Handle backspace
                otpBoxes[i].setOnKeyListener((v, keyCode, event) -> {
                    if (keyCode == KeyEvent.KEYCODE_DEL && event.getAction() == KeyEvent.ACTION_DOWN) {
                        if (otpBoxes[currentIndex].getText().toString().isEmpty() && currentIndex > 0) {
                            otpBoxes[currentIndex - 1].requestFocus();
                            otpBoxes[currentIndex - 1].setText("");
                        }
                    }
                    return false;
                });
            }
        }
    }

    private void setupButtonListeners() {
        if (verifyOtpButton != null) {
            verifyOtpButton.setOnClickListener(v -> {
                Log.d(TAG, "🔐 Verify OTP button clicked");
                verifyOTP();
            });
        }

        if (resendOtpButton != null) {
            resendOtpButton.setOnClickListener(v -> {
                Log.d(TAG, "🔄 Resend OTP button clicked");
                resendOTP();
            });
        }

        // Initially disable resend button
        if (resendOtpButton != null) {
            resendOtpButton.setEnabled(false);
        }
    }

    private boolean isAllBoxesFilled() {
        for (EditText box : otpBoxes) {
            if (box == null || box.getText().toString().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private String getOtpFromBoxes() {
        StringBuilder otp = new StringBuilder();
        for (EditText box : otpBoxes) {
            if (box != null) {
                otp.append(box.getText().toString());
            }
        }
        return otp.toString();
    }

    private void verifyOTP() {
        String enteredOTP = getOtpFromBoxes();
        Log.d(TAG, "🔍 Verifying OTP: " + enteredOTP);

        if (enteredOTP.length() != 6) {
            showError("Please enter complete 6-digit OTP");
            return;
        }

        // Hide keyboard
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (verifyOtpButton != null) {
            imm.hideSoftInputFromWindow(verifyOtpButton.getWindowToken(), 0);
        }

        showProgress("Verifying OTP...");

        if (authManager != null) {
            authManager.setLastPhoneNumber(currentPhoneNumber);
            boolean result = authManager.verifyOTP(enteredOTP, currentPhoneNumber);
            Log.d(TAG, "📊 OTP verification initiated, result: " + result);
        } else {
            Log.e(TAG, "❌ AuthManager is null");
            showError("Authentication error");
        }
    }

    private void resendOTP() {
        Log.d(TAG, "🔄 Resending OTP...");
        showProgress("Resending OTP...");

        // Clear existing OTP boxes
        for (EditText box : otpBoxes) {
            if (box != null) {
                box.setText("");
            }
        }

        if (otpBoxes[0] != null) {
            otpBoxes[0].requestFocus();
        }

        resendOtpButton.setEnabled(false);

        if (authManager != null) {
            authManager.startAuthentication(currentPhoneNumber);
        } else {
            Log.e(TAG, "❌ AuthManager is null during resend");
            showError("Authentication error");
        }
    }

    private void enableResendButtonAfterDelay() {
        if (resendOtpButton != null) {
            resendOtpButton.postDelayed(() -> {
                resendOtpButton.setEnabled(true);
                showInfo("You can now resend OTP");
            }, 30000);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "🔄 OtpActivity onResume");

        LocalBroadcastManager.getInstance(this)
                .registerReceiver(otpReceiver, new IntentFilter("OTP_RECEIVED"));

        // Focus first OTP box
        if (otpBoxes[0] != null) {
            otpBoxes[0].requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(otpBoxes[0], InputMethodManager.SHOW_IMPLICIT);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "⏸️ OtpActivity onPause");
        LocalBroadcastManager.getInstance(this).unregisterReceiver(otpReceiver);
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "🔙 Back pressed, going to LoginActivity");
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    // UI Helper Methods
    private void showProgress(String msg) {
        Log.d(TAG, "⏳ " + msg);
        runOnUiThread(() -> {
            if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
            if (statusText != null) {
                statusText.setVisibility(View.VISIBLE);
                statusText.setText(msg);
                statusText.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
            }
        });
    }

    private void hideProgress() {
        Log.d(TAG, "✅ Hiding progress");
        runOnUiThread(() -> {
            if (progressBar != null) progressBar.setVisibility(View.GONE);
            if (statusText != null) statusText.setVisibility(View.GONE);
        });
    }

    private void showInfo(String msg) {
        Log.d(TAG, "ℹ️ " + msg);
        runOnUiThread(() -> {
            if (statusText != null) {
                statusText.setVisibility(View.VISIBLE);
                statusText.setText(msg);
                statusText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        });
    }

    private void showError(String msg) {
        Log.e(TAG, "❌ " + msg);
        runOnUiThread(() -> {
            if (statusText != null) {
                statusText.setVisibility(View.VISIBLE);
                statusText.setText(msg);
                statusText.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            }
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        });
    }
}