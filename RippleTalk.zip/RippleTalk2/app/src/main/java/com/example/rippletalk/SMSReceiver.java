package com.example.rippletalk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SMSReceiver extends BroadcastReceiver {
    private static final String TAG = "SMSReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "📩 SMS received intent: " + intent.getAction());

        if ("android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Log.d(TAG, "📦 Bundle contains SMS data");

                Object[] pdus = (Object[]) bundle.get("pdus");
                String format = bundle.getString("format");
                if (pdus != null) {
                    Log.d(TAG, "📨 Number of PDUs: " + pdus.length);

                    for (Object pdu : pdus) {
                        SmsMessage sms;
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                            sms = SmsMessage.createFromPdu((byte[]) pdu, format);
                        } else {
                            sms = SmsMessage.createFromPdu((byte[]) pdu);
                        }

                        if (sms != null) {
                            String sender = sms.getOriginatingAddress();
                            String body = sms.getMessageBody();

                            Log.d(TAG, "👤 Sender: " + sender);
                            Log.d(TAG, "📝 Message: " + body);

                            // Extract 6-digit OTP
                            Pattern pattern = Pattern.compile("\\b\\d{6}\\b");
                            Matcher matcher = pattern.matcher(body);
                            if (matcher.find()) {
                                String otp = matcher.group(0);
                                Log.d(TAG, "✅ OTP extracted: " + otp);

                                // FIX: Extract phone number from the message body
                                String targetPhoneNumber = extractPhoneNumberFromMessage(body);

                                if (targetPhoneNumber == null) {
                                    // Fallback: Try to get from shared preferences
                                    SharedPreferences prefs = context.getSharedPreferences("OTP_Prefs", Context.MODE_PRIVATE);
                                    targetPhoneNumber = prefs.getString("LAST_PHONE_NUMBER", null);
                                    Log.d(TAG, "🔄 Using phone number from prefs: " + targetPhoneNumber);
                                } else {
                                    Log.d(TAG, "📱 Phone number extracted from message: " + targetPhoneNumber);
                                }

                                if (targetPhoneNumber != null) {
                                    // Store OTP using singleton with the target phone number
                                    AuthenticationManager authManager = AuthenticationManager.getInstance(context);
                                    authManager.storeOTP(otp, targetPhoneNumber); // Use the new method

                                    Log.d(TAG, "💾 OTP stored for phone: " + targetPhoneNumber);
                                } else {
                                    Log.d(TAG, "❌ No phone number found for OTP");
                                }

                                // Broadcast to activities
                                Intent otpIntent = new Intent("OTP_RECEIVED");
                                otpIntent.putExtra("otp", otp);
                                if (targetPhoneNumber != null) {
                                    otpIntent.putExtra("phone_number", targetPhoneNumber);
                                }
                                LocalBroadcastManager.getInstance(context).sendBroadcast(otpIntent);
                                Log.d(TAG, "📤 OTP broadcast sent");
                            } else {
                                Log.d(TAG, "❌ No OTP found in message");
                            }
                        }
                    }
                }
            }
        }
    }

    // FIX: Extract phone number from SMS message body
    private String extractPhoneNumberFromMessage(String messageBody) {
        try {
            // Pattern 1: Look for phone number patterns in the message
            Pattern phonePattern = Pattern.compile("\\+?[0-9]{10,13}");
            Matcher phoneMatcher = phonePattern.matcher(messageBody);

            if (phoneMatcher.find()) {
                String phoneNumber = phoneMatcher.group();
                Log.d(TAG, "🔍 Found phone number in message: " + phoneNumber);
                return phoneNumber;
            }

            // Pattern 2: Look for "for +91XXXXXXXXXX" pattern
            Pattern forPattern = Pattern.compile("for\\s*(\\+?[0-9]{10,13})", Pattern.CASE_INSENSITIVE);
            Matcher forMatcher = forPattern.matcher(messageBody);
            if (forMatcher.find()) {
                String phoneNumber = forMatcher.group(1);
                Log.d(TAG, "🔍 Found phone number using 'for' pattern: " + phoneNumber);
                return phoneNumber;
            }

            // Pattern 3: Look for common OTP message formats
            String[] commonPatterns = {
                    "number", "mobile", "phone", "registered"
            };

            for (String pattern : commonPatterns) {
                int index = messageBody.toLowerCase().indexOf(pattern);
                if (index != -1) {
                    // Try to extract number after the pattern
                    String remaining = messageBody.substring(index + pattern.length());
                    phoneMatcher = phonePattern.matcher(remaining);
                    if (phoneMatcher.find()) {
                        String phoneNumber = phoneMatcher.group();
                        Log.d(TAG, "🔍 Found phone number after '" + pattern + "': " + phoneNumber);
                        return phoneNumber;
                    }
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "❌ Error extracting phone number from message", e);
        }

        return null;
    }
}