package com.example.rippletalk;

import android.util.Log;

public class MessageProcessor {
    private static final String TAG = "MessageProcessor";

    // Message type constants
    public static final String TYPE_PRESENCE = "PRESENCE";
    public static final String TYPE_ROOM = "ROOM";
    public static final String TYPE_PUBLIC = "PUBLIC";
    public static final String TYPE_CHAT = "CHAT";
    public static final String TYPE_JOIN = "JOIN";
    public static final String TYPE_LEAVE = "LEAVE";

    public static class ProcessedMessage {
        public String senderPhone;
        public String messageType;
        public String userName;
        public String content;
        public String rawMessage;

        public ProcessedMessage(String senderPhone, String messageType, String userName, String content, String rawMessage) {
            this.senderPhone = senderPhone;
            this.messageType = messageType;
            this.userName = userName;
            this.content = content;
            this.rawMessage = rawMessage;
        }
    }

    /**
     * Process raw message and extract components
     */
    public static ProcessedMessage processMessage(String fromPhone, String rawMessage) {
        Log.d(TAG, "🔍 Processing message - From: " + fromPhone + ", Raw: " + rawMessage);

        // Extract actual message from raw format
        String actualMessage = extractActualMessage(rawMessage);
        Log.d(TAG, "📩 Extracted message: " + actualMessage);

        // Determine message type and parse
        if (isUserPresenceMessage(actualMessage)) {
            return parsePresenceMessage(fromPhone, actualMessage);
        } else if (isRoomMessage(actualMessage)) {
            return parseRoomMessage(fromPhone, actualMessage);
        } else if (isPublicChatMessage(actualMessage)) {
            return parsePublicMessage(fromPhone, actualMessage);
        } else {
            return parseRegularMessage(fromPhone, actualMessage);
        }
    }

    /**
     * Extract actual message from raw format (removes phone prefix)
     */
    private static String extractActualMessage(String rawMessage) {
        if (rawMessage == null || rawMessage.trim().isEmpty()) {
            return "";
        }

        // Handle format: "9527887311:PRESENCE|harshu"
        if (rawMessage.contains(":")) {
            String[] parts = rawMessage.split(":", 2);
            if (parts.length == 2) {
                return parts[1]; // Return the message part after phone number
            }
        }

        return rawMessage;
    }

    /**
     * Parse presence message: PRESENCE|username
     */
    private static ProcessedMessage parsePresenceMessage(String fromPhone, String message) {
        try {
            String[] parts = message.split("\\|", 2);
            if (parts.length == 2 && parts[0].equals(TYPE_PRESENCE)) {
                String userName = parts[1];
                Log.d(TAG, "👤 Presence detected - User: " + userName + " Phone: " + fromPhone);
                return new ProcessedMessage(fromPhone, TYPE_PRESENCE, userName, "", message);
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Error parsing presence message: " + message, e);
        }
        return null;
    }

    /**
     * Parse room message: ROOM|type|username|content
     */
    private static ProcessedMessage parseRoomMessage(String fromPhone, String message) {
        try {
            String[] parts = message.split("\\|", 4);
            if (parts.length == 4 && parts[0].equals(TYPE_ROOM)) {
                String messageType = parts[1];
                String userName = parts[2];
                String content = parts[3];
                Log.d(TAG, "🏠 Room message - Type: " + messageType + " User: " + userName + " Content: " + content);
                return new ProcessedMessage(fromPhone, messageType, userName, content, message);
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Error parsing room message: " + message, e);
        }
        return null;
    }

    /**
     * Parse public message: PUBLIC|type|username|content
     */
    private static ProcessedMessage parsePublicMessage(String fromPhone, String message) {
        try {
            String[] parts = message.split("\\|", 4);
            if (parts.length == 4 && parts[0].equals(TYPE_PUBLIC)) {
                String messageType = parts[1];
                String userName = parts[2];
                String content = parts[3];
                Log.d(TAG, "🌐 Public message - Type: " + messageType + " User: " + userName + " Content: " + content);
                return new ProcessedMessage(fromPhone, messageType, userName, content, message);
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Error parsing public message: " + message, e);
        }
        return null;
    }

    /**
     * Parse regular message (treat as chat message)
     */
    private static ProcessedMessage parseRegularMessage(String fromPhone, String message) {
        Log.d(TAG, "💬 Regular message: " + message);
        // For regular messages, generate a username from phone
        String userName = "User_" + fromPhone.substring(Math.max(0, fromPhone.length() - 4));
        return new ProcessedMessage(fromPhone, TYPE_CHAT, userName, message, message);
    }

    /**
     * Check if message is presence type
     */
    public static boolean isUserPresenceMessage(String message) {
        return message != null && message.startsWith(TYPE_PRESENCE + "|");
    }

    /**
     * Check if message is room type
     */
    public static boolean isRoomMessage(String message) {
        return message != null && message.startsWith(TYPE_ROOM + "|");
    }

    /**
     * Check if message is public type
     */
    public static boolean isPublicChatMessage(String message) {
        return message != null && message.startsWith(TYPE_PUBLIC + "|");
    }

    /**
     * Format a room message for sending
     */
    public static String formatRoomMessage(String type, String userName, String content) {
        return String.format("%s|%s|%s|%s", TYPE_ROOM, type, userName, content);
    }

    /**
     * Format a presence message for sending
     */
    public static String formatPresenceMessage(String userName) {
        return String.format("%s|%s", TYPE_PRESENCE, userName);
    }
}