package com.example.rippletalk;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class OnlineUsersAdapter extends RecyclerView.Adapter<OnlineUsersAdapter.UserViewHolder> {

    private List<OnlineUser> usersList;

    public OnlineUsersAdapter(List<OnlineUser> usersList) {
        this.usersList = usersList;
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_online_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, int position) {
        OnlineUser user = usersList.get(position);
        holder.bind(user);
    }

    @Override
    public int getItemCount() {
        return usersList.size();
    }

    public void updateUsers(List<OnlineUser> newUsers) {
        usersList.clear();
        usersList.addAll(newUsers);
        notifyDataSetChanged();
    }

    class UserViewHolder extends RecyclerView.ViewHolder {
        private TextView userNameText;
        private TextView statusText;
        private View userIndicator;

        public UserViewHolder(View itemView) {
            super(itemView);
            userNameText = itemView.findViewById(R.id.userNameText);
            statusText = itemView.findViewById(R.id.statusText);
            userIndicator = itemView.findViewById(R.id.userIndicator);
        }

        public void bind(OnlineUser user) {
            userNameText.setText(user.userName);

            if (user.isSelf) {
                // Current user styling
                userNameText.setTextColor(Color.parseColor("#1976D2"));
                statusText.setText("You");
                statusText.setTextColor(Color.parseColor("#666666"));
                userIndicator.setBackgroundColor(Color.parseColor("#1976D2"));
            } else {
                // Other users styling
                userNameText.setTextColor(Color.parseColor("#333333"));
                statusText.setText("Online");
                statusText.setTextColor(Color.parseColor("#059E0B"));
                userIndicator.setBackgroundColor(Color.parseColor("#038008"));
            }
        }
    }
}