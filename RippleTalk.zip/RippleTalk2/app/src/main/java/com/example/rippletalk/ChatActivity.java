package com.example.rippletalk;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ChatActivity extends AppCompatActivity {
    private static final String TAG = "ChatActivity";

    private RecyclerView messagesRecyclerView;
    private EditText messageInput;
    private ProgressBar progressBar;
    private TextView contactInfoText, onlineStatus;
    private LinearLayout typingIndicator;
    private ImageButton backButton, sendButton;

    private ChatAdapter chatAdapter;
    private BluetoothMeshManager meshManager;
    private ChatMessageDao chatMessageDao;
    private ContactManager contactManager;
    private List<ChatMessage> messagesList = new ArrayList<>();

    private String currentUserPhone;
    private String contactPhone;
    private String contactName;
    private Handler statusHandler = new Handler();
    private Handler typingHandler = new Handler();
    private Handler refreshHandler = new Handler();

    private boolean isSendingMessage = false;
    private boolean isConnecting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        contactPhone = getIntent().getStringExtra("CONTACT_PHONE");
        contactName = getIntent().getStringExtra("CONTACT_NAME");
        if (contactPhone == null) {
            Log.e(TAG, "No contact phone provided");
            finish();
            return;
        }

        // Get current user
        AuthenticationManager authManager = AuthenticationManager.getInstance(this);
        currentUserPhone = authManager.getAuthenticatedUser();

        if (currentUserPhone == null) {
            Log.e(TAG, "User not authenticated");
            finish();
            return;
        }

        Log.d(TAG, "💬 Starting chat with: " + contactName + " (" + contactPhone + ")");
        Log.d(TAG, "👤 Current user: " + currentUserPhone);

        initializeViews();
        initializeDatabase();
        initializeManagers();

        // ✅ ADD: Setup message listener
        setupMessageListener();

        emergencyCleanupMessages();


        loadChatHistory();
        startSmartConnection();

        // ✅ ADD: Start periodic message refresh
        startMessageRefresh();

        // ✅ ADD: Debug database
        debugDatabaseContents();

        // ✅ ADD: Test connection after short delay
        new Handler().postDelayed(this::testConnectionAndMessages, 3000);
    }

    // ✅ ADD: Refresh messages when new ones arrive
    private void setupMessageListener() {
        if (meshManager != null) {
            meshManager.setMeshCallback(new BluetoothMeshManager.MeshCallback() {
                @Override
                public void onMessageReceived(String fromPhone, String message) {
                    Log.d(TAG, "📩 REAL-TIME: Message received from " + fromPhone + ": " + message);

                    runOnUiThread(() -> {
                        // Only process messages from our target contact
                        if (fromPhone.equals(contactPhone)) {
                            // Refresh the chat history to show new message
                            loadChatHistory();

                            // Show typing indicator
                            showTypingIndicator();

                            // Update status
                            updateContactStatus();

                            Log.d(TAG, "✅ Message displayed in chat: " + message);

                            // Debug the database after receiving message
                            debugDatabaseContents();
                        }
                    });
                }

                @Override
                public void onDeviceConnected(String phoneNumber) {
                    if (phoneNumber.equals(contactPhone)) {
                        runOnUiThread(() -> {
                            updateContactStatus();
                            loadChatHistory(); // Refresh messages
                            Log.d(TAG, "✅ Device connected - refreshing messages");
                        });
                    }
                }

                // Add other required callback methods...
                @Override public void onDeviceDiscovered(String phoneNumber, String bluetoothAddress, int rssi) {}
                @Override public void onDeviceDisconnected(String phoneNumber) {
                    if (phoneNumber.equals(contactPhone)) {
                        runOnUiThread(() -> {
                            Log.w(TAG, "⚠️ Device disconnected");
                            updateContactStatus();
                        });
                    }
                }
                @Override public void onDiscoveryStarted() {}
                @Override public void onDiscoveryStopped() {}
                @Override public void onMessageDeliveryStatus(String phoneNumber, boolean delivered, String messageId) {}
                @Override public void onConnectionStatusChanged(String phoneNumber, boolean connected) {}
                @Override public void onDevicePaired(String phoneNumber) {}
                @Override public void onAdvertisingStarted() {}
                @Override public void onAdvertisingStopped() {}
                @Override public void onError(String error) {
                    Log.e(TAG, "❌ Mesh Error: " + error);
                }
            });
        }
    }

    private void initializeViews() {
        messagesRecyclerView = findViewById(R.id.messagesRecyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);
        progressBar = findViewById(R.id.progressBar);
        contactInfoText = findViewById(R.id.contactInfoText);
        onlineStatus = findViewById(R.id.onlineStatus);
        typingIndicator = findViewById(R.id.typingIndicator);
        backButton = findViewById(R.id.btnBack);

        String displayName = contactName != null ? contactName : contactPhone;
        contactInfoText.setText(displayName);

        // Setup RecyclerView
        messagesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatAdapter = new ChatAdapter(messagesList, currentUserPhone);
        messagesRecyclerView.setAdapter(chatAdapter);

        // Send button
        sendButton.setOnClickListener(v -> sendMessage());

        // Send on Enter key
        messageInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                sendMessage();
                return true;
            }
            return false;
        });

        // Add this in initializeViews()
        Button debugButton = findViewById(R.id.debugButton);
        if (debugButton != null) {
            debugButton.setOnClickListener(v -> {
                debugDatabaseContents();
                loadChatHistory(); // Force refresh UI
            });
        }



        // Real-time send button state
        messageInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateSendButtonState();
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
            }
        });

        // Back button
        backButton.setOnClickListener(v -> finish());

        // Auto-focus
        messageInput.requestFocus();

        // Initial button state
        updateSendButtonState();
    }

    private void initializeDatabase() {
        AppDatabase database = AppDatabase.getInstance(this);
        chatMessageDao = database.chatMessageDao();
    }

    private void initializeManagers() {
        AppDatabase database = AppDatabase.getInstance(this);
        contactManager = new ContactManager(this, database.deviceMappingDao(), chatMessageDao);
        meshManager = contactManager.getMeshManager();

        // ✅ IMPROVED: Set up mesh callback with better error handling
        meshManager.setMeshCallback(new BluetoothMeshManager.MeshCallback() {
            @Override
            public void onDeviceDiscovered(String phoneNumber, String bluetoothAddress, int rssi) {
                // ✅ ONLY care about our target contact
                if (phoneNumber.equals(contactPhone)) {
                    runOnUiThread(() -> {
                        Log.d(TAG, "✅ TARGET DEVICE FOUND: " + contactName + " (RSSI: " + rssi + ")");
                        updateContactStatus();

                        // ✅ AUTOMATIC: Connect when target device is found
                        if (!meshManager.isDeviceConnected(contactPhone)) {
                            attemptAutomaticConnection();
                        }
                    });
                }
            }

            public void onMessageReceived(String fromPhone, String message) {
                Log.d(TAG, "📩 Received message from: " + fromPhone + " - " + message);

                // ✅ ONLY process messages from our target contact
                if (fromPhone.equals(contactPhone)) {

                    // ✅ ADD THIS: FILTER OUT PUBLIC CHAT MESSAGES IMMEDIATELY
                    if (isPublicChatMessage(message)) {
                        Log.d(TAG, "🚫 IGNORING PUBLIC CHAT MESSAGE in personal chat: " + message);
                        return; // Don't process public chat messages in personal chat
                    }

                    runOnUiThread(() -> {
                        if (!isDuplicateMessage(message)) {
                            ChatMessage receivedMessage = new ChatMessage(contactPhone, currentUserPhone, message);
                            receivedMessage.isIncoming = true;
                            receivedMessage.messageStatus = 1; // Delivered
                            new SaveMessageTask(receivedMessage).execute();

                            Log.d(TAG, "💾 Saved PERSONAL message from: " + contactName);

                            // Show typing indicator briefly
                            showTypingIndicator();

                            // Update status
                            updateContactStatus();

                            // ✅ ADD: Immediate UI refresh
                            loadChatHistory();
                        }
                    });
                }
            }

            private boolean isDuplicateMessage(String message) {
                long currentTime = System.currentTimeMillis();
                for (ChatMessage existing : messagesList) {
                    if (existing.message.equals(message) &&
                            (currentTime - existing.timestamp) < 3000) {
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onDeviceConnected(String phoneNumber) {
                // ✅ ONLY care about our target contact
                if (phoneNumber.equals(contactPhone)) {
                    runOnUiThread(() -> {
                        isConnecting = false;
                        hideProgress();
                        updateContactStatus();
                        showToast("🟢 Connected to " + contactName);
                        Log.d(TAG, "✅ Connected to: " + contactName);

                        // Force message exchange immediately after connection
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            if (meshManager != null && meshManager.isDeviceConnected(contactPhone)) {

                            }
                        }, 1000);
                    });
                }
            }

            @Override
            public void onDeviceDisconnected(String phoneNumber) {
                // ✅ ONLY care about our target contact
                if (phoneNumber.equals(contactPhone)) {
                    runOnUiThread(() -> {
                        updateContactStatus();
                        showToast("🔴 " + contactName + " disconnected");
                        Log.d(TAG, "❌ Disconnected from: " + contactName);

                        // ✅ AUTOMATIC: Try to reconnect to our target contact
                        if (isChatActive()) {
                            new Handler().postDelayed(() -> {
                                if (isChatActive() && !isConnecting) {
                                    attemptAutomaticConnection();
                                }
                            }, 3000);
                        }
                    });
                }
            }

            @Override
            public void onDiscoveryStarted() {
                runOnUiThread(() -> {
                    showProgress("Finding " + contactName + "...");
                    Log.d(TAG, "🎯 TARGETED discovery started for: " + contactName);
                });
            }

            @Override
            public void onDiscoveryStopped() {
                runOnUiThread(() -> {
                    hideProgress();
                    Log.d(TAG, "🎯 Targeted discovery stopped");
                });
            }

            @Override
            public void onMessageDeliveryStatus(String phoneNumber, boolean delivered, String messageId) {
                // ✅ ONLY care about our target contact
                if (phoneNumber.equals(contactPhone)) {
                    runOnUiThread(() -> {
                        if (delivered) {
                            Log.d(TAG, "✅ Message delivered to: " + contactName);
                            showToast("✓ Delivered to " + contactName);
                        } else {
                            Log.d(TAG, "⏳ Message queued for: " + contactName);
                        }
                    });
                }
            }

            @Override
            public void onConnectionStatusChanged(String phoneNumber, boolean connected) {
                // ✅ ONLY care about our target contact
                if (phoneNumber.equals(contactPhone)) {
                    runOnUiThread(() -> {
                        updateContactStatus();
                        Log.d(TAG, "Connection status for " + contactName + ": " + connected);
                    });
                }
            }

            @Override
            public void onDevicePaired(String phoneNumber) {
                // ✅ ONLY care about our target contact
                if (phoneNumber.equals(contactPhone)) {
                    runOnUiThread(() -> {
                        hideProgress();
                        updateContactStatus();
                        Log.d(TAG, "✅ Device paired: " + contactName);
                        showToast("🤝 Connected to " + contactName);
                    });
                }
            }

            @Override
            public void onAdvertisingStarted() {
                Log.d(TAG, "✅ Advertising started for " + contactName);
            }

            @Override
            public void onAdvertisingStopped() {
                Log.d(TAG, "Advertising stopped");
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    Log.e(TAG, "Bluetooth error for " + contactName + ": " + error);
                    isConnecting = false;
                    hideProgress();
                    updateContactStatus();

                    if (error.contains("not available") || error.contains("disabled")) {
                        showToast("Bluetooth not available");
                    } else {
                        showToast("Connection error: " + error);
                    }
                });
            }
        });
    }

    // ✅ ADD: Test connection and message flow
    private void testConnectionAndMessages() {
        Log.d(TAG, "🧪 TESTING CONNECTION AND MESSAGES");

        // Test 1: Check Bluetooth status
        if (meshManager != null) {
            boolean isConnected = meshManager.isDeviceConnected(contactPhone);
            boolean inRange = meshManager.isDeviceInRange(contactPhone);
            boolean isPaired = meshManager.isDeviceDiscovered(contactPhone);

            Log.d(TAG, "📡 Connection Test:");
            Log.d(TAG, "   - Connected: " + isConnected);
            Log.d(TAG, "   - In Range: " + inRange);
            Log.d(TAG, "   - Discovered: " + isPaired);
        } else {
            Log.e(TAG, "❌ MeshManager is null");
        }

        // Test 2: Check contact manager status
        contactManager.getContactStatus(contactPhone, new ContactManager.ContactStatusCallback() {
            @Override
            public void onStatusReceived(String status) {
                Log.d(TAG, "📱 Contact Status: " + status);
            }
        });

        // Test 3: Force reload messages
        loadChatHistory();

        // Test 4: Send a test message if connected
        new Handler().postDelayed(() -> {
            if (meshManager != null && meshManager.isDeviceConnected(contactPhone)) {
                String testMessage = "Test message at " + System.currentTimeMillis();
                contactManager.sendMessageToContact(contactPhone, testMessage, new ContactManager.MessageSendCallback() {
                    @Override
                    public void onMessageSent(boolean success) {
                        Log.d(TAG, "🧪 TEST MESSAGE RESULT: " + (success ? "✅ SENT" : "❌ FAILED"));
                        // Reload messages to see if test message appears
                        new Handler().postDelayed(() -> {
                            loadChatHistory();
                            debugDatabaseContents();
                        }, 1000);
                    }
                });
            } else {
                Log.w(TAG, "⚠️ Cannot send test message - not connected");
            }
        }, 2000);
    }




    // ✅ ADD: Send message method
    private void sendMessage() {
        if (isSendingMessage) {
            return;
        }

        String message = messageInput.getText().toString().trim();
        if (TextUtils.isEmpty(message)) {
            return;
        }

        // Disable send button while sending
        isSendingMessage = true;
        updateSendButtonState();

        // Clear input immediately for better UX
        messageInput.setText("");

        // Create message object for local display
        ChatMessage chatMessage = new ChatMessage(currentUserPhone, contactPhone, message);
        chatMessage.isIncoming = false;
        chatMessage.messageStatus = 0; // Sent

        Log.d(TAG, "📤 Sending message to: " + contactName + " - " + message);

        // ✅ WHATSAPP-LIKE: Send via ContactManager - automatic routing
        contactManager.sendMessageToContact(contactPhone, message, new ContactManager.MessageSendCallback() {
            @Override
            public void onMessageSent(boolean success) {
                runOnUiThread(() -> {
                    isSendingMessage = false;
                    updateSendButtonState();

                    // Always save message locally
                    new SaveMessageTask(chatMessage).execute();

                    if (success) {
                        Log.d(TAG, "✅ Message delivered to: " + contactName);
                        showToast("✓ Delivered");
                    } else {
                        Log.d(TAG, "💾 Message queued for: " + contactName);
                        showToast("⏳ Message queued - will deliver when " + contactName + " comes online");
                    }

                    // ✅ ADD: Immediate UI refresh after sending
                    loadChatHistory();
                });
            }
        });

        updateContactStatus();
    }

    private void updateSendButtonState() {
        boolean hasText = !TextUtils.isEmpty(messageInput.getText().toString().trim());
        boolean canSend = hasText && !isSendingMessage && !isConnecting;
        sendButton.setEnabled(canSend);
        sendButton.setAlpha(canSend ? 1.0f : 0.5f);

        /*if (isSendingMessage) {
            sendButton.setText("Sending...");
        } else if (isConnecting) {
            sendButton.setText("Connecting...");
        } else {
            sendButton.setText("Send");
        }*/
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showTypingIndicator() {
        if (typingIndicator != null) {
            typingIndicator.setVisibility(View.VISIBLE);
            typingHandler.removeCallbacksAndMessages(null);
            typingHandler.postDelayed(() -> {
                if (typingIndicator != null) {
                    typingIndicator.setVisibility(View.GONE);
                }
            }, 2000);
        }
    }

    // ✅ IMPROVED: Smart connection with better state management
    private void startSmartConnection() {
        Log.d(TAG, "🔗 SMART CONNECT to " + contactName + " (" + contactPhone + ")");

        // Show connecting status
        isConnecting = true;
        updateSendButtonState();
        showProgress("Connecting to " + contactName + "...");

        // Start advertising first
        meshManager.startAdvertising();

        // ✅ START DISCOVERY ONLY FOR THIS CONTACT
        startDiscoveryForContact();

        // Brief delay before starting connection
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            contactManager.connectToContact(contactPhone, new ContactManager.ConnectionCallback() {
                @Override
                public void onConnectionResult(boolean success, String message) {
                    runOnUiThread(() -> {
                        isConnecting = false;
                        hideProgress();
                        updateSendButtonState();

                        if (success) {
                            Log.d(TAG, "✅ Connected to: " + contactName);
                            showToast("Connected to " + contactName);
                            updateContactStatus();

                            // Force message exchange after connection
                            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                                if (meshManager != null && meshManager.isDeviceConnected(contactPhone)) {

                                }
                            }, 1500);

                        } else {
                            Log.d(TAG, "❌ Connection failed: " + message);
                            showToast(contactName + " is offline - messages will be delivered when online");
                            updateContactStatus();
                        }
                    });
                }
            });
        }, 2000);

        // Start status updates
        startPeriodicStatusUpdates();
        updateContactStatus();
    }

    // ✅ AUTOMATIC: Attempt connection when device found
    private void attemptAutomaticConnection() {
        if (isConnecting) {
            Log.d(TAG, "⏭️ Already connecting, skipping");
            return;
        }

        isConnecting = true;
        updateSendButtonState();

        Log.d(TAG, "🔗 Attempting AUTOMATIC connection to: " + contactName);
        showProgress("Connecting to " + contactName + "...");
    }

    // ✅ AUTOMATIC: Start discovery for contact
    private void startDiscoveryForContact() {
        if (isConnecting) {
            Log.d(TAG, "⏭️ Already connecting, skipping discovery");
            return;
        }

        Log.d(TAG, "🔍 Starting discovery for: " + contactName);
        meshManager.startDiscovery();

        // Auto-stop discovery after 30 seconds
        statusHandler.postDelayed(() -> {
            if (!meshManager.isDeviceInRange(contactPhone)) {
                Log.d(TAG, "⏰ Discovery timeout - contact not found");
                meshManager.stopDiscovery();
                isConnecting = false;
                updateSendButtonState();
                updateContactStatus();
                showToast(contactName + " not found nearby");
            }
        }, 30000);
    }

    private void startPeriodicStatusUpdates() {
        statusHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateContactStatus();

                // ✅ AUTOMATIC: If contact is offline, try to reconnect
                String currentStatus = onlineStatus.getText().toString();
                if ((currentStatus.contains("Offline") || currentStatus.contains("Searching")) &&
                        isChatActive() && !isConnecting) {
                    Log.d(TAG, "Contact offline - attempting reconnection...");
                    startDiscoveryForContact();
                }

                statusHandler.postDelayed(this, 10000);
            }
        }, 5000);
    }

    // ✅ ADD: Periodic message refresh
    private void startMessageRefresh() {
        Handler refreshHandler = new Handler();
        refreshHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isChatActive()) {
                    loadChatHistory(); // Refresh messages every 3 seconds
                    refreshHandler.postDelayed(this, 3000);
                }
            }
        }, 3000);
    }
    // Check if chat is still active (user hasn't left)
    private boolean isChatActive() {
        return !isFinishing() && !isDestroyed();
    }

    private void updateContactStatus() {
        contactManager.getContactStatus(contactPhone, new ContactManager.ContactStatusCallback() {
            @Override
            public void onStatusReceived(String status) {
                runOnUiThread(() -> {
                    if (onlineStatus != null) {
                        onlineStatus.setText("● " + status);

                        // Set status colors
                        if (status.equals("Online") || status.equals("Connected")) {
                            onlineStatus.setTextColor(Color.parseColor("#D9FADD"));
                            isConnecting = false;
                        } else if (status.equals("Searching...") || status.contains("Connecting")) {
                            onlineStatus.setTextColor(Color.parseColor("#C5CC04"));
                            isConnecting = true;
                        } else if (status.equals("Offline")) {
                            onlineStatus.setTextColor(Color.parseColor("#CC0704"));
                            isConnecting = false;
                        } else {
                            onlineStatus.setTextColor(Color.parseColor("#333333"));
                        }

                        updateSendButtonState();
                    }
                });
            }
        });
    }

    private void loadChatHistory() {
        new LoadMessagesTask().execute();
    }

    // ✅ FIXED: Single LoadMessagesTask class
    private class LoadMessagesTask extends AsyncTask<Void, Void, List<ChatMessage>> {
        @Override
        protected List<ChatMessage> doInBackground(Void... voids) {
            try {
                List<ChatMessage> messages = chatMessageDao.getChatHistory(currentUserPhone, contactPhone);

                // ✅ REMOVE DUPLICATES IN MEMORY (for display)
                List<ChatMessage> uniqueMessages = new ArrayList<>();
                Set<String> seenMessages = new HashSet<>();

                // Sort by timestamp to keep the earliest version
                Collections.sort(messages, (m1, m2) -> Long.compare(m1.timestamp, m2.timestamp));

                for (ChatMessage message : messages) {
                    String messageKey = message.message + "_" + message.timestamp / 10000; // Group by 10-second windows

                    if (!seenMessages.contains(messageKey)) {
                        uniqueMessages.add(message);
                        seenMessages.add(messageKey);
                        Log.d(TAG, "💬 KEEPING MESSAGE: " + message.message);
                    } else {
                        Log.d(TAG, "⏭️ FILTERING DUPLICATE: " + message.message);
                    }
                }

                return uniqueMessages;
            } catch (Exception e) {
                Log.e(TAG, "Error loading chat history", e);
                return new ArrayList<>();
            }
        }

        @Override
        protected void onPostExecute(List<ChatMessage> messages) {
            messagesList.clear();
            if (messages != null) {
                messagesList.addAll(messages);
            }
            chatAdapter.notifyDataSetChanged();
            scrollToBottom();

            Log.d(TAG, "🔄 Displaying " + messagesList.size() + " unique messages in UI");
        }
    }

    private class SaveMessageTask extends AsyncTask<Void, Void, Void> {
        private ChatMessage message;

        public SaveMessageTask(ChatMessage message) {
            this.message = message;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                chatMessageDao.insert(message);
                Log.d(TAG, "💾 Message saved to database: " + message.message);
            } catch (Exception e) {
                Log.e(TAG, "Error saving message to database", e);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            // Refresh messages list
            loadChatHistory();
        }
    }

    private void scrollToBottom() {
        if (messagesRecyclerView != null && messagesList.size() > 0) {
            messagesRecyclerView.post(() -> {
                messagesRecyclerView.smoothScrollToPosition(messagesList.size() - 1);
            });
        }
    }

    private void showProgress(String message) {
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
    }

    private void hideProgress() {
        if (progressBar != null) {
            progressBar.setVisibility(View.GONE);
        }
    }

    // ✅ EMERGENCY CLEANUP: Delete all system messages from database
    // ✅ FIXED: Cleanup using the new delete methods
    private void emergencyCleanupMessages() {
        new Thread(() -> {
            try {
                AppDatabase database = AppDatabase.getInstance(this);
                ChatMessageDao chatMessageDao = database.chatMessageDao();

                List<ChatMessage> allMessages = chatMessageDao.getChatHistory(currentUserPhone, contactPhone);
                int removedCount = 0;

                for (ChatMessage message : allMessages) {
                    String msg = message.message.toLowerCase();

                    // ✅ IDENTIFY SYSTEM MESSAGES
                    if (msg.contains("ping") ||
                            msg.contains("test message") ||
                            msg.contains("hello from rippletalk") ||
                            msg.matches(".*test.*at.*[0-9]+.*")) {

                        // ✅ USE THE NEW DELETE METHOD
                        chatMessageDao.deleteMessage(message.id);
                        removedCount++;
                        Log.d(TAG, "🧹 DELETED: " + message.message);
                    }
                }

                if (removedCount > 0) {
                    Log.d(TAG, "✅ EMERGENCY CLEANUP: Removed " + removedCount + " junk messages");
                    runOnUiThread(this::loadChatHistory);
                }

            } catch (Exception e) {
                Log.e(TAG, "Error in emergency cleanup", e);
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "ChatActivity resumed");

        // ✅ Start periodic message refresh
        startMessageRefresh();

        updateContactStatus();
        if (meshManager != null) {
            meshManager.startAdvertising();

            // Try to reconnect if disconnected
            if (!meshManager.isDeviceConnected(contactPhone) && isChatActive() && !isConnecting) {
                new Handler().postDelayed(() -> {
                    if (isChatActive() && !meshManager.isDeviceConnected(contactPhone)) {
                        startDiscoveryForContact();
                    }
                }, 2000);
            }
        }

        // Reload messages when returning to chat
        loadChatHistory();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "ChatActivity paused");

        // Stop handlers
        if (refreshHandler != null) {
            refreshHandler.removeCallbacksAndMessages(null);
        }

        // Stop discovery to save battery
        if (meshManager != null) {
            meshManager.stopDiscovery();
        }
    }


    // ✅ ADD: Debug database contents
    private void debugDatabaseContents() {
        new Thread(() -> {
            try {
                List<ChatMessage> allMessages = chatMessageDao.getChatHistory(currentUserPhone, contactPhone);
                Log.d(TAG, "=== DATABASE DEBUG ===");
                Log.d(TAG, "Current User: " + currentUserPhone);
                Log.d(TAG, "Contact: " + contactPhone);
                Log.d(TAG, "Total messages in DB: " + allMessages.size());

                if (allMessages.isEmpty()) {
                    Log.d(TAG, "❌ NO MESSAGES FOUND IN DATABASE");
                } else {
                    for (ChatMessage msg : allMessages) {
                        Log.d(TAG, "DB MSG: " + (msg.isIncoming ? "INCOMING" : "OUTGOING") +
                                " | " + msg.senderPhone + " -> " + msg.receiverPhone +
                                " | '" + msg.message + "' | Status: " + msg.messageStatus +
                                " | Time: " + new Date(msg.timestamp));
                    }
                }
                Log.d(TAG, "=== END DATABASE DEBUG ===");
            } catch (Exception e) {
                Log.e(TAG, "❌ Error debugging database", e);
            }
        }).start();

    }




    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "ChatActivity destroyed");

        // Clean up all handlers
        if (statusHandler != null) {
            statusHandler.removeCallbacksAndMessages(null);
        }
        if (typingHandler != null) {
            typingHandler.removeCallbacksAndMessages(null);
        }
        if (refreshHandler != null) {
            refreshHandler.removeCallbacksAndMessages(null);
        }

        // Clean up managers safely
        if (meshManager != null) {
            meshManager.setMeshCallback(null);
            meshManager.stopDiscovery();
            meshManager.stopAdvertising();
        }
        if (contactManager != null) {
            contactManager.cleanup();
        }
    }

    // In ChatActivity.java - Add this method to filter public chat messages
    private boolean isPublicChatMessage(String rawMessage) {
        if (rawMessage == null || rawMessage.trim().isEmpty()) {
            return false;
        }

        // Extract the actual message content (remove phone prefix)
        String actualMessage = extractMessageContent(rawMessage);

        // Check if it's a public chat message by looking for public chat patterns
        return actualMessage.startsWith("PRESENCE|") ||
                actualMessage.startsWith("ROOM|") ||
                actualMessage.startsWith("PUBLIC|") ||
                actualMessage.contains("|JOIN|") ||
                actualMessage.contains("|LEAVE|") ||
                actualMessage.contains("|CHAT|");
    }

    // Helper method to extract message content
    private String extractMessageContent(String rawMessage) {
        if (rawMessage == null || rawMessage.trim().isEmpty()) {
            return "";
        }

        // Handle format: "9527887311:ROOM|CHAT|username|message"
        String[] parts = rawMessage.split(":", 2);
        if (parts.length == 2) {
            return parts[1]; // Return the message part after phone number
        }

        return rawMessage;
    }
}