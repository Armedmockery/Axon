package com.example.rippletalk;

public class PublicChatMessage {
    public String userName;
    public String message;
    public long timestamp;
    public boolean isOwnMessage;
    public boolean isSystemMessage;


    public PublicChatMessage(String userName, String message, long timestamp, boolean isOwnMessage) {
        this.userName = userName;
        this.message = message;
        this.timestamp = timestamp;
        this.isOwnMessage = isOwnMessage;
        this.isSystemMessage = false;
    }

    public void setSystemMessage(boolean systemMessage) {
        isSystemMessage = systemMessage;
    }
}