package com.example.rippletalk;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class LoginActivity extends AppCompatActivity implements AuthenticationManager.AuthenticationCallback {

    private static final int SMS_PERMISSION_REQUEST = 101;

    private EditText usernameInput, phoneInput; // Add username field
    private Button requestOtpButton;
    private AuthenticationManager authManager;
    private String currentPhoneNumber, currentUsername; // Add username variable
    private ProgressBar progressBar;
    private TextView statusText, instructionText;

    private BroadcastReceiver otpReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("OTP_RECEIVED".equals(intent.getAction())) {
                String otp = intent.getStringExtra("otp");
                if (otp != null) {
                    showInfo("OTP received: " + otp);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        // Initialize UI components - ADD USERNAME INPUT
        usernameInput = findViewById(R.id.usernameInput); // Add this line
        phoneInput = findViewById(R.id.phoneNumberInput);
        requestOtpButton = findViewById(R.id.sendOtpButton);
        progressBar = findViewById(R.id.progressBar);
        statusText = findViewById(R.id.statusText);
        instructionText = findViewById(R.id.instructionText);

        // Use Singleton AuthenticationManager
        authManager = AuthenticationManager.getInstance(this);
        authManager.setCallback(this);

        // ✅ Request runtime SMS permission
        checkAndRequestSmsPermission();

        requestOtpButton.setOnClickListener(v -> startAuthentication());
    }

    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.SEND_SMS,
                            Manifest.permission.READ_SMS,
                            Manifest.permission.RECEIVE_SMS
                    }, SMS_PERMISSION_REQUEST);
        }
    }

    private void startAuthentication() {
        // GET USERNAME FROM INPUT FIELD
        currentUsername = usernameInput.getText().toString().trim();
        currentPhoneNumber = phoneInput.getText().toString().trim();

        // VALIDATE BOTH FIELDS
        if (TextUtils.isEmpty(currentUsername)) {
            showError("Please enter your username");
            return;
        }

        if (TextUtils.isEmpty(currentPhoneNumber)) {
            showError("Please enter your phone number");
            return;
        }

        // Store BOTH username and phone number in shared preferences
        SharedPreferences prefs = getSharedPreferences("OTP_Prefs", MODE_PRIVATE);
        prefs.edit()
                .putString("LAST_PHONE_NUMBER", currentPhoneNumber)
                .putString("LAST_USER_NAME", currentUsername) // Store username
                .apply();

        Log.d("LoginActivity", "📱 Phone number stored: " + currentPhoneNumber);
        Log.d("LoginActivity", "👤 Username stored: " + currentUsername);

        // Set the phone number in auth manager
        authManager.setLastPhoneNumber(currentPhoneNumber);

        showProgress("Requesting OTP...");
        authManager.startAuthentication(currentPhoneNumber);
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(otpReceiver, new IntentFilter("OTP_RECEIVED"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(otpReceiver);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                showInfo("SMS permissions granted. You can now request OTP.");
            } else {
                showError("Some SMS permissions denied. OTP features may not work properly.");
            }
        }
    }

    // --- AuthenticationManager callbacks ---
    @Override
    public void onAuthenticationSuccess() {
        hideProgress();
        showInfo("Authentication successful!");

        // ✅ Redirect to MainActivity with username
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("USER_NAME", currentUsername); // Pass username to MainActivity
        startActivity(intent);
        finish();
    }

    @Override
    public void onAuthenticationFailed(String reason) {
        hideProgress();
        showError(reason);
    }

    @Override
    public void onOTPSent() {
        hideProgress();
        showInfo("OTP request sent. Waiting for SMS...");

        // Navigate to OtpActivity with both phone number and username
        Intent intent = new Intent(LoginActivity.this, OtpActivity.class);
        intent.putExtra("PHONE_NUMBER", currentPhoneNumber);
        intent.putExtra("USER_NAME", currentUsername); // Pass username to OtpActivity
        startActivity(intent);
        finish();
    }

    @Override
    public void onOTPReceived(String otp) {
        showInfo("OTP received: " + otp);
    }

    // --- UI Helper Methods ---
    private void showProgress(String msg) {
        progressBar.setVisibility(View.VISIBLE);
        statusText.setVisibility(View.VISIBLE);
        statusText.setText(msg);
        statusText.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
    }

    private void hideProgress() {
        progressBar.setVisibility(View.GONE);
        statusText.setVisibility(View.GONE);
    }

    private void showInfo(String msg) {
        statusText.setVisibility(View.VISIBLE);
        statusText.setText(msg);
        statusText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void showError(String msg) {
        statusText.setVisibility(View.VISIBLE);
        statusText.setText(msg);
        statusText.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}