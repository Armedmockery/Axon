package com.example.rippletalk;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private ContactManager contactManager;
    private LinearLayout chatContainer;
    private EditText searchInput;
    private AuthenticationManager authManager;
    private List<DeviceMapping> allContacts = new ArrayList<>();
    private static final int BLUETOOTH_PERMISSION_REQUEST = 100;
    private Handler mainHandler = new Handler();
    private boolean isServiceBound = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize authentication
        authManager = AuthenticationManager.getInstance(this);

        // Check if user is authenticated
        if (!authManager.isUserAuthenticated()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        if (getWindow() != null) {
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        // Clean up existing duplicates when app starts
        if (contactManager != null && contactManager.getMeshManager() != null) {
            contactManager.getMeshManager().cleanupDuplicateMessages();
        }
        // Request Bluetooth permissions first
        requestBluetoothPermissions();
    }

    private void requestBluetoothPermissions() {
        List<String> permissionsToRequest = new ArrayList<>();

        // Always request location permission (required for BLE scanning on older Android)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }

        // Android 12+ (API 31+) permissions
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            }
            //  REMOVED: android.permission.NEARBY_WIFI_DEVICES - NOT NEEDED FOR BLUETOOTH
        } else {
            // Legacy permissions for Android 11 and below
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_ADMIN);
            }
        }

        if (!permissionsToRequest.isEmpty()) {
            Log.d(TAG, "Requesting Bluetooth permissions: " + permissionsToRequest);
            ActivityCompat.requestPermissions(this,
                    permissionsToRequest.toArray(new String[0]),
                    BLUETOOTH_PERMISSION_REQUEST);
        } else {
            Log.d(TAG, "✅ All Bluetooth permissions granted");
            initializeApp();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BLUETOOTH_PERMISSION_REQUEST) {
            boolean allGranted = true;

            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                Log.d(TAG, "✅ All permissions granted - initializing app");
                initializeApp();
            } else {
                Log.e(TAG, "❌ Some permissions denied");

                // Check which permissions were denied
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Log.e(TAG, "❌ Permission denied: " + permissions[i]);
                    }
                }

                // Show better error message and don't close the app
                showPermissionExplanationWithRetry();
            }
        }
    }

    private void showPermissionExplanationWithRetry() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("Permissions Required")
                .setMessage("This app needs Bluetooth permissions to:\n\n" +
                        "• Discover nearby devices\n" +
                        "• Connect to other phones\n" +
                        "• Enable offline messaging\n\n" +
                        "Without these permissions, the app cannot function properly.")
                .setPositiveButton("Grant Permissions", (dialog, which) -> {
                    // Retry permission request
                    requestBluetoothPermissions();
                })
                .setNegativeButton("Exit App", (dialog, which) -> {
                    // Close app if user doesn't want to grant permissions
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    private void showPermissionExplanationDialog() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("Permissions Required")
                .setMessage("This app needs Bluetooth and Location permissions to discover nearby devices and enable offline messaging.")
                .setPositiveButton("OK", null)
                .setCancelable(false)
                .show();
    }

    private void initializeApp() {
        try {
            // Double-check that we have necessary permissions
            if (!hasMinimumBluetoothPermissions()) {
                Log.e(TAG, "❌ Missing required permissions after initialization");
                showPermissionExplanationWithRetry();
                return;
            }

            initializeContactSystem();
            setupUIComponents();

            // Welcome user
            String welcomeMessage = "Welcome, " + authManager.getDisplayName() + "!";
            Toast.makeText(this, welcomeMessage, Toast.LENGTH_SHORT).show();

            // Start debugging
            mainHandler.postDelayed(this::debugPhoneAndBluetoothStatus, 3000);

        } catch (Exception e) {
            Log.e(TAG, "Error initializing app: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing app", Toast.LENGTH_LONG).show();
        }
    }


    private boolean hasMinimumBluetoothPermissions() {
        // Check for location permission (required for BLE scanning)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "❌ Missing ACCESS_FINE_LOCATION permission");
            return false;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+ requires BLUETOOTH_SCAN and BLUETOOTH_CONNECT
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "❌ Missing BLUETOOTH_SCAN permission");
                return false;
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "❌ Missing BLUETOOTH_CONNECT permission");
                return false;
            }
        } else {
            // Android 11 and below require BLUETOOTH and BLUETOOTH_ADMIN
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "❌ Missing BLUETOOTH permission");
                return false;
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "❌ Missing BLUETOOTH_ADMIN permission");
                return false;
            }
        }

        Log.d(TAG, "✅ All required Bluetooth permissions granted");
        return true;
    }

    private void setupUIComponents() {
        chatContainer = findViewById(R.id.chatContainer);
        searchInput = findViewById(R.id.search);

        ImageButton menuButton = findViewById(R.id.menu);
        menuButton.setOnClickListener(v -> {
            Context wrapper = new ContextThemeWrapper(MainActivity.this, R.style.CustomPopupMenu);
            PopupMenu popupMenu = new PopupMenu(wrapper, menuButton);
            /*popupMenu.getMenu().add("Profile");
            popupMenu.getMenu().add("Add Contact");*/
            popupMenu.getMenuInflater().inflate(R.menu.main_menu, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {
                int itemId = item.getItemId();
                if (itemId == R.id.menu_profile) {
                    openProfileActivity();
                } else if (itemId == R.id.menu_add_contact) {
                    showAddContactDialog();
                }
                return true;
            });

            popupMenu.show();
        });

        ImageButton refreshButton = findViewById(R.id.blueBtn);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Just refresh contacts, NO discovery
                loadContacts();
                Toast.makeText(MainActivity.this, "Contacts refreshed", Toast.LENGTH_SHORT).show();
            }
        });

        // Debug button functionality - UPDATED WITH MESH DEBUG
        Button debugButton = findViewById(R.id.debugButton);
        if (debugButton != null) {
            debugButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    debugPhoneAndBluetoothStatus();
                    debugMeshNetworkStatus(); // ✅ ADD MESH DEBUG
                }
            });
        }

        // Search functionality
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterContacts(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Load contacts initially
        loadContacts();

        // Start advertising only (NO discovery)
        if (contactManager != null && contactManager.getMeshManager() != null) {
            contactManager.getMeshManager().startAdvertising();
        }

        ImageButton publicChatButton = findViewById(R.id.publicChatButton);
        publicChatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Public chat button clicked - opening PublicChatActivity");
                openPublicChatActivity();
            }
        });
    }
    private void setupPopupMenuBackground(PopupMenu popupMenu) {
        try {
            // Method 1: Set background to null
            Field mPopupField = popupMenu.getClass().getDeclaredField("mPopup");
            mPopupField.setAccessible(true);
            Object mPopup = mPopupField.get(popupMenu);
            mPopup.getClass().getDeclaredMethod("setBackgroundDrawable", Drawable.class)
                    .invoke(mPopup, null);

        } catch (NoSuchFieldException e) {
            try {
                // Method 2: Alternative field name
                Field mPopupField = popupMenu.getClass().getDeclaredField("mPopup");
                mPopupField.setAccessible(true);
                Object mPopup = mPopupField.get(popupMenu);
                mPopup.getClass().getDeclaredMethod("setBackgroundDrawable", Drawable.class)
                        .invoke(mPopup, ContextCompat.getDrawable(this, R.drawable.custom_popup_background));

            } catch (Exception ex) {
                Log.e(TAG, "Error setting popup background: " + ex.getMessage());

                // Method 3: Use reflection to access the ListView and set divider to null
                try {
                    Field[] fields = popupMenu.getClass().getDeclaredFields();
                    for (Field field : fields) {
                        if ("mMenu".equals(field.getName())) {
                            field.setAccessible(true);
                            Object mMenu = field.get(popupMenu);
                            Field listViewField = mMenu.getClass().getDeclaredField("mListView");
                            listViewField.setAccessible(true);
                            ListView listView = (ListView) listViewField.get(mMenu);
                            if (listView != null) {
                                listView.setDivider(null);
                                listView.setDividerHeight(0);
                            }
                        }
                    }
                } catch (Exception ex2) {
                    Log.e(TAG, "Error removing popup dividers: " + ex2.getMessage());
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error setting popup background: " + e.getMessage());
        }
    }
    private void openProfileActivity() {
        try {
            Log.d(TAG, "Opening Profile activity");
            Intent intent = new Intent(MainActivity.this, Profile.class);
            intent.putExtra("FROM_MENU", true);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error opening Profile: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening profile", Toast.LENGTH_SHORT).show();
        }
    }

    private void openPublicChatActivity() {
        try {
            Log.d(TAG, "Opening PublicChatActivity");
            Intent intent = new Intent(MainActivity.this, PublicChatActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error opening PublicChatActivity: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening public chat", Toast.LENGTH_SHORT).show();
        }
    }
    // ✅ SINGLE debugMeshNetworkStatus method (REMOVED DUPLICATE)
    private void debugMeshNetworkStatus() {
        Log.d(TAG, "=== MESH NETWORK DEBUG ===");

        if (contactManager == null || contactManager.getMeshManager() == null) {
            Log.e(TAG, "❌ ContactManager or MeshManager not initialized");
            Toast.makeText(this, "Mesh manager not ready", Toast.LENGTH_SHORT).show();
            return;
        }

        BluetoothMeshManager meshManager = contactManager.getMeshManager();

        try {
            String currentUser = authManager.getAuthenticatedUser();
            Log.d(TAG, "👤 Current User: " + currentUser);

            // Get all devices from database
            AppDatabase database = AppDatabase.getInstance(this);
            List<DeviceMapping> allDevices = database.deviceMappingDao().getAllContacts();

            Log.d(TAG, " Total devices in database: " + allDevices.size());

            int connectedCount = 0;
            int inRangeCount = 0;
            int manualContacts = 0;
            int autoDiscovered = 0;

            for (DeviceMapping device : allDevices) {
                boolean isManual = device.hasCustomName();
                boolean connected = meshManager.isDeviceConnected(device.phoneNumber);
                boolean inRange = meshManager.isDeviceInRange(device.phoneNumber);

                if (connected) connectedCount++;
                if (inRange) inRangeCount++;
                if (isManual) manualContacts++;
                else autoDiscovered++;

                Log.d(TAG, "📱 " + device.phoneNumber +
                        " | Manual: " + isManual +
                        " | Connected: " + connected +
                        " | In Range: " + inRange +
                        " | Name: " + device.deviceName);
            }

            Log.d(TAG, " SUMMARY:");
            Log.d(TAG, "   Manual Contacts: " + manualContacts);
            Log.d(TAG, "   Auto-Discovered: " + autoDiscovered);
            Log.d(TAG, "   Connected: " + connectedCount);
            Log.d(TAG, "   In Range: " + inRangeCount);

            // Test mesh routes for each manual contact
            if (currentUser != null) {
                Log.d(TAG, " TESTING MESH ROUTES:");
                for (DeviceMapping contact : allContacts) {
                    if (contact.hasCustomName() && !contact.phoneNumber.equals(currentUser)) {
                        Log.d(TAG, "   Checking routes to: " + contact.phoneNumber + " (" + contact.deviceName + ")");

                        boolean directConnection = meshManager.isDeviceConnected(contact.phoneNumber);

                        if (!directConnection) {
                            Log.d(TAG, "   ⚡ Direct connection: NO - Mesh routing required");
                            // Mesh routing will happen automatically when sending messages
                        } else {
                            Log.d(TAG, "   ⚡ Direct connection: YES - No mesh needed");
                        }
                    }
                }
            }

            // Show user-friendly summary
            String meshStatus = "🕸️ Mesh: " + connectedCount + " connected, " + inRangeCount + " in range";
            Toast.makeText(this, meshStatus, Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Log.e(TAG, "❌ Error debugging mesh network", e);
            Toast.makeText(this, "Error debugging mesh", Toast.LENGTH_SHORT).show();
        }

        Log.d(TAG, "=== END MESH DEBUG ===");
    }

    // ✅ ADD THIS METHOD: Test mesh routing with a specific contact
    private void testMeshRouting(DeviceMapping contact) {
        if (contactManager == null) {
            Toast.makeText(this, "ContactManager not ready", Toast.LENGTH_SHORT).show();
            return;
        }

        String testMessage = " Mesh test at " + System.currentTimeMillis();

        contactManager.sendMessageToContact(contact.phoneNumber, testMessage, new ContactManager.MessageSendCallback() {
            @Override
            public void onMessageSent(boolean success) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (success) {
                            Toast.makeText(MainActivity.this,
                                    "✅ Message sent to " + contact.contactName + " (may use mesh)",
                                    Toast.LENGTH_LONG).show();
                            Log.d(TAG, "✅ Mesh test message sent successfully");
                        } else {
                            Toast.makeText(MainActivity.this,
                                    "❌ Failed to send to " + contact.contactName,
                                    Toast.LENGTH_SHORT).show();
                            Log.d(TAG, "❌ Mesh test message failed");
                        }
                    }
                });
            }
        });
    }

    private void debugPhoneAndBluetoothStatus() {
        Log.d(TAG, "=== COMPREHENSIVE DEBUG ===");

        if (authManager == null) {
            Log.e(TAG, " AuthManager not initialized");
            return;
        }

        // Debug phone number status
        authManager.debugPhoneNumberStatus();

        if (contactManager != null && contactManager.getMeshManager() != null) {
            BluetoothMeshManager meshManager = contactManager.getMeshManager();

            Log.d(TAG, "=== BLUETOOTH STATUS ===");
            Log.d(TAG, "Is Advertising: " + meshManager.isAdvertising);
            Log.d(TAG, "Is Scanning: " + meshManager.isScanning);
            Log.d(TAG, "Contact Count: " + allContacts.size());

            String authStatus = authManager.hasValidPhoneForAdvertising() ? "✅" : "❌";
            String advStatus = meshManager.isAdvertising ? "✅" : "❌";

            String summary = "Phone: " + authStatus + " | Adv: " + advStatus + " | Contacts: " + allContacts.size();
            Toast.makeText(this, summary, Toast.LENGTH_LONG).show();

        } else {
            Log.e(TAG, " ContactManager or MeshManager not initialized");
        }
    }

    private void showAddContactDialog() {
        try {
            AddContactDialog dialog = new AddContactDialog(this, contactManager, new ContactManager.ContactAddCallback() {
                @Override
                public void onContactAdded(boolean success, String message) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                            if (success) {
                                loadContacts();
                            }
                        }
                    });
                }
            });
            if (getWindow() != null) {
                getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                getWindow().setBackgroundDrawableResource(android.R.color.transparent);

                // Clear all flags and set transparent background
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
            dialog.show();
        } catch (Exception e) {
            Log.e(TAG, "Error showing add contact dialog: " + e.getMessage(), e);
            Toast.makeText(this, "Error showing dialog", Toast.LENGTH_SHORT).show();
        }
    }

    private void initializeContactSystem() {
        try {
            AppDatabase database = AppDatabase.getInstance(this);
            contactManager = new ContactManager(this, database.deviceMappingDao(), database.chatMessageDao());

            // ✅ CRITICAL FIX: Add contact update callback
            contactManager.setContactsUpdateCallback(new ContactManager.ContactsUpdateCallback() {
                @Override
                public void onContactsUpdated() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loadContacts();
                        }
                    });
                }
            });

            // ✅ TARGETED DISCOVERY ONLY: Set up callback for when user clicks contact
            contactManager.setGlobalMessageCallback(new ContactManager.MessageReceivedCallback() {
                @Override
                public void onNewMessage(String fromPhone, String message) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Only show notification if it's from a manual contact
                            if (isManualContact(fromPhone)) {
                                Toast.makeText(MainActivity.this,
                                        "New message from " + fromPhone, Toast.LENGTH_SHORT).show();
                                loadContacts();
                            }
                        }
                    });
                }
            });

            // Set up minimal mesh callback - NO AUTO DISCOVERY
            contactManager.getMeshManager().setMeshCallback(new BluetoothMeshManager.MeshCallback() {
                @Override
                public void onDeviceDiscovered(String phoneNumber, String bluetoothAddress, int rssi) {
                    // ❌ IGNORE: We don't auto-discover devices
                    Log.d(TAG, "⏭ Ignoring auto-discovered device: " + phoneNumber);
                }

                @Override
                public void onMessageReceived(String fromPhone, String message) {
                    // Handled by global message callback
                }

                @Override
                public void onDeviceConnected(String phoneNumber) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loadContacts();
                            Log.d(TAG, " Device connected: " + phoneNumber);
                        }
                    });
                }

                @Override
                public void onDeviceDisconnected(String phoneNumber) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loadContacts();
                            Log.d(TAG, "🔌 Device disconnected: " + phoneNumber);
                        }
                    });
                }

                @Override
                public void onDiscoveryStarted() {
                    Log.d(TAG, " Discovery started for specific contact");
                }

                @Override
                public void onDiscoveryStopped() {
                    Log.d(TAG, " Discovery stopped");
                }

                @Override
                public void onMessageDeliveryStatus(String phoneNumber, boolean delivered, String messageId) {
                    // Message status updates
                }

                @Override
                public void onConnectionStatusChanged(String phoneNumber, boolean connected) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loadContacts();
                        }
                    });
                }

                @Override
                public void onDevicePaired(String phoneNumber) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loadContacts();
                            Log.d(TAG, " Device paired: " + phoneNumber);
                        }
                    });
                }

                @Override
                public void onAdvertisingStarted() {
                    Log.d(TAG, "📡 Advertising started");
                }

                @Override
                public void onAdvertisingStopped() {
                    Log.d(TAG, "📡 Advertising stopped");
                }

                @Override
                public void onError(String error) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.e(TAG, " Mesh error: " + error);
                        }
                    });
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error initializing contact system: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing contact system", Toast.LENGTH_LONG).show();
        }
    }

    // ✅ MANUAL CONTACTS ONLY: Load only manually added contacts
    private void loadContacts() {
        try {
            contactManager.getAllContacts(new ContactManager.ContactsLoadCallback() {
                @Override
                public void onContactsLoaded(List<DeviceMapping> contacts) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Filter to show only manual contacts
                            List<DeviceMapping> manualContacts = new ArrayList<>();
                            for (DeviceMapping contact : contacts) {
                                if (contact.hasCustomName()) {
                                    manualContacts.add(contact);
                                }
                            }

                            allContacts = manualContacts;
                            displayContacts(manualContacts);
                            Log.d(TAG, " Loaded " + manualContacts.size() + " manual contacts");

                            if (manualContacts.isEmpty()) {
                                showEmptyState();
                            }
                        }
                    });
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error loading contacts: " + e.getMessage(), e);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    displayContacts(new ArrayList<DeviceMapping>());
                }
            });
        }
    }

    // ✅ Helper to check if contact is manual
    private boolean isManualContact(String phoneNumber) {
        for (DeviceMapping contact : allContacts) {
            if (contact.phoneNumber.equals(phoneNumber) && contact.hasCustomName()) {
                return true;
            }
        }
        return false;
    }

    private void showEmptyState() {
        TextView emptyText = new TextView(this);
        emptyText.setText("No contacts yet.\n\nAdd contacts using the menu button.");
        emptyText.setTextColor(Color.parseColor("#666666"));
        emptyText.setPadding(50, 50, 50, 50);
        emptyText.setTextSize(16);
        emptyText.setGravity(View.TEXT_ALIGNMENT_CENTER);
        emptyText.setLineSpacing(1.5f, 1.5f);
        chatContainer.addView(emptyText);
    }

    private void displayContacts(List<DeviceMapping> contacts) {
        chatContainer.removeAllViews();

        if (contacts.isEmpty()) {
            showEmptyState();
            return;
        }

        for (DeviceMapping contact : contacts) {
            createContactViewAsync(contact);
        }
    }

    private void createContactViewAsync(DeviceMapping contact) {
        try {
            contactManager.getContactStatus(contact.phoneNumber, new ContactManager.ContactStatusCallback() {
                @Override
                public void onStatusReceived(String status) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            View contactView = createContactView(contact, status);
                            chatContainer.addView(contactView);
                        }
                    });
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error creating contact view: " + e.getMessage(), e);
        }
    }

    private View createContactView(DeviceMapping contact, String status) {
        View contactView = getLayoutInflater().inflate(R.layout.contact, null);

        TextView contactName = contactView.findViewById(R.id.et_username);
        TextView contactPhone = contactView.findViewById(R.id.contact_phone);
        TextView statusText = contactView.findViewById(R.id.onlineStatus);

        contactName.setText(contact.getDisplayName());
        contactPhone.setText(contact.phoneNumber);

        // Status display
        String statusDisplay;
        if (status.equals("Online")) {
            statusText.setTextColor(Color.parseColor("#038008"));
            statusDisplay = "● Online";
        } else if (status.equals("Offline")) {
            statusText.setTextColor(Color.parseColor("#B80404"));
            statusDisplay = "● Offline";
        } else {
            statusText.setTextColor(Color.parseColor("#DEDA02"));
            statusDisplay = "● Tap to connect";
        }
        statusText.setText(statusDisplay);

        // ✅ TARGETED DISCOVERY: Only discover when user clicks contact
        contactView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, " User clicked contact: " + contact.contactName);
                openChatWithContact(contact);
            }
        });

        // ✅ ADD: Long press to test mesh routing
        contactView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Log.d(TAG, " Testing mesh routing to: " + contact.contactName);
                testMeshRouting(contact);
                Toast.makeText(MainActivity.this,
                        "Testing mesh to " + contact.contactName, Toast.LENGTH_SHORT).show();
                return true; // Return true to indicate the long click was handled
            }
        });

        return contactView;
    }

    private void filterContacts(String query) {
        if (query.isEmpty()) {
            displayContacts(allContacts);
            return;
        }

        List<DeviceMapping> filteredContacts = new ArrayList<>();
        String lowerQuery = query.toLowerCase();

        for (DeviceMapping contact : allContacts) {
            String name = contact.deviceName != null ? contact.deviceName.toLowerCase() : "";
            String phone = contact.phoneNumber.toLowerCase();

            if (name.contains(lowerQuery) || phone.contains(lowerQuery)) {
                filteredContacts.add(contact);
            }
        }

        displayContacts(filteredContacts);
    }

    // ✅ TARGETED DISCOVERY: Only start discovery when opening chat
    private void openChatWithContact(DeviceMapping contact) {
        Log.d(TAG, "🎯 Starting targeted discovery for: " + contact.phoneNumber);

        // Show connecting dialog
        Toast.makeText(this, "Searching for " + contact.contactName + "...", Toast.LENGTH_SHORT).show();

        // Start targeted discovery for this specific contact
        contactManager.connectToContact(contact.phoneNumber, new ContactManager.ConnectionCallback() {
            @Override
            public void onConnectionResult(boolean success, String message) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (success) {
                            Toast.makeText(MainActivity.this, "Connected to " + contact.contactName, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                        }

                        // Open chat activity regardless of connection status
                        Intent intent = new Intent(MainActivity.this, ChatActivity.class);
                        intent.putExtra("CONTACT_PHONE", contact.phoneNumber);
                        intent.putExtra("CONTACT_NAME", contact.deviceName);
                        startActivity(intent);
                    }
                });
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadContacts();

        // Start advertising only (NO discovery)
        if (contactManager != null && contactManager.getMeshManager() != null) {
            contactManager.getMeshManager().startAdvertising();
        }
        // Clean up existing duplicates when app starts
        if (contactManager != null && contactManager.getMeshManager() != null) {
            contactManager.getMeshManager().cleanupDuplicateMessages();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Stop any ongoing discovery
        if (contactManager != null && contactManager.getMeshManager() != null) {
            contactManager.getMeshManager().stopDiscovery();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (contactManager != null) {
            contactManager.cleanup();
        }
        if (mainHandler != null) {
            mainHandler.removeCallbacksAndMessages(null);
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_profile) {
            Intent intent = new Intent(this, Profile.class);
            intent.putExtra("FROM_MENU", true);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}