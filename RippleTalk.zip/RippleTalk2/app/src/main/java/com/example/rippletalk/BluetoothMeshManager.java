package com.example.rippletalk;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.util.Log;
import android.util.SparseArray;

import androidx.core.content.ContextCompat;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections; // keep!
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * RippleTalk BluetoothMeshManager
 * - Android 12+ hardened (BLUETOOTH_SCAN / CONNECT / ADVERTISE)
 * - Safe wrappers for device name/address
 * - Guarded advertiser/scanner/socket calls
 * - Keeps your mesh routing & message logic
 */
public class BluetoothMeshManager {
    private static final String TAG = "BluetoothMeshManager";
    private static final UUID SERVICE_UUID = UUID.fromString("12345678-1234-1234-1234-123456789ABC");
    private static final ParcelUuid PARCEL_SERVICE_UUID = new ParcelUuid(SERVICE_UUID);

    private static final long DEVICE_TIMEOUT = 120000; // 2 minutes
    private static final long SCAN_DURATION = 30000;   // 30 seconds
    private static final long CONNECTION_COOLDOWN = 5000;

    private final Context context;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner bluetoothLeScanner;
    private BluetoothLeAdvertiser bluetoothLeAdvertiser;

    public boolean isScanning;
    public boolean isAdvertising;

    private final DeviceMappingDao deviceMappingDao;
    private final AuthenticationManager authManager;

    // Core mapping: Phone Number -> Bluetooth Device
    private final Map<String, BluetoothDevice> phoneToDeviceMap = new ConcurrentHashMap<>();
    private final Map<String, Long> deviceLastSeen = new ConcurrentHashMap<>();
    private final Map<String, Integer> deviceRssiMap = new ConcurrentHashMap<>();
    private final Map<String, Boolean> connectionStates = new ConcurrentHashMap<>();
    private final Map<String, BluetoothDevice> connectedDevices = new ConcurrentHashMap<>();
    private final Map<String, BluetoothDevice> discoveredDevices = new ConcurrentHashMap<>();

    private final Map<String, List<String>> pendingMessages = new ConcurrentHashMap<>();
    private final Map<String, List<String>> messageQueue = new ConcurrentHashMap<>();

    public final Handler handler = new Handler(Looper.getMainLooper());
    public MeshCallback meshCallback;

    private BluetoothChatService chatService;
    private final MeshRoutingManager meshRoutingManager;
    private AdvertiseCallback advertiseCallback;
    private ScanCallback scanCallback;

    private String currentConnectedDevice = null;
    private String targetContactPhone = null;

    private final Object connectionLock = new Object();
    private volatile boolean isConnectionInProgress = false;
    private String currentConnectingDevice = null;

    // Connection coordination
    private boolean isInitiatingConnection = false;
    private long lastConnectionAttempt = 0;

    // Keep-alive
    private final Handler keepAliveHandler = new Handler(Looper.getMainLooper());
    private final Runnable keepAliveTask = new Runnable() {
        @Override
        public void run() {
            if (chatService != null && chatService.isConnected()) {
                try {
                    String keepAliveMsg = "SYS_PING_KEEPALIVE_" + System.currentTimeMillis();
                    chatService.write(keepAliveMsg.getBytes(StandardCharsets.UTF_8));
                    Log.d(TAG, "❤️ Keep-alive sent (filtered by receiver)");
                } catch (Exception e) {
                    Log.e(TAG, "Keep-alive failed", e);
                }
            }
            if (chatService != null && chatService.isConnected()) {
                keepAliveHandler.postDelayed(this, 15000);
            } else {
                Log.d(TAG, "Not connected, stopping keep-alive");
            }
        }
    };

    // Bookkeeping
    private final Map<String, Long> processedDevices = new ConcurrentHashMap<>();

    public interface MeshCallback {
        void onDeviceDiscovered(String phoneNumber, String bluetoothAddress, int rssi);
        void onMessageReceived(String fromPhone, String message);
        void onDeviceConnected(String phoneNumber);
        void onDeviceDisconnected(String phoneNumber);
        void onDiscoveryStarted();
        void onDiscoveryStopped();
        void onMessageDeliveryStatus(String phoneNumber, boolean delivered, String messageId);
        void onConnectionStatusChanged(String phoneNumber, boolean connected);
        void onDevicePaired(String phoneNumber);
        void onAdvertisingStarted();
        void onAdvertisingStopped();
        void onError(String error);
    }

    public BluetoothMeshManager(Context context, DeviceMappingDao deviceMappingDao) {
        this.context = context.getApplicationContext();
        this.deviceMappingDao = deviceMappingDao;
        this.authManager = AuthenticationManager.getInstance(this.context);
        this.meshRoutingManager = new MeshRoutingManager(deviceMappingDao, this, authManager);

        initializeBluetooth();
        initializeChatService();
        startPeriodicOperations();
        loadExistingMappings();
    }

    // =========================== Android 12+ Security Helpers ===========================

    private boolean hasPermission(String perm) {
        return ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean ensurePermission(String perm, String op) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        if (!hasPermission(perm)) {
            String msg = "Missing " + perm + " required to " + op + " on Android 12+.";
            Log.e(TAG, msg);
            notifyError(msg);
            return false;
        }
        return true;
    }

    private boolean ensurePermissions(String[] perms, String op) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        List<String> missing = new ArrayList<>();
        for (String p : perms) {
            if (!hasPermission(p)) missing.add(p);
        }
        if (!missing.isEmpty()) {
            String msg = "Missing permissions " + missing + " required to " + op + " on Android 12+.";
            Log.e(TAG, msg);
            notifyError(msg);
            return false;
        }
        return true;
    }

    private String safeDeviceName(BluetoothDevice device) {
        if (device == null) return "unknown";
        try {
            return device.getName();
        } catch (SecurityException e) {
            // BLUETOOTH_CONNECT missing — fall back to address
            return safeDeviceAddress(device);
        } catch (Throwable t) {
            return "unknown";
        }
    }

    private String safeDeviceAddress(BluetoothDevice device) {
        if (device == null) return "00:00:00:00:00:00";
        try {
            return device.getAddress();
        } catch (SecurityException e) {
            return "00:00:00:00:00:00";
        } catch (Throwable t) {
            return "00:00:00:00:00:00";
        }
    }

    private boolean safeCancelDiscovery() {
        try {
            if (bluetoothAdapter != null) bluetoothAdapter.cancelDiscovery();
            return true;
        } catch (SecurityException e) {
            Log.e(TAG, "No permission to cancel discovery");
            return false;
        }
    }

    // =========================== Init & Lifecycle ===========================

    private void initializeBluetooth() {
        try {
            BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            if (bluetoothManager != null) {
                bluetoothAdapter = bluetoothManager.getAdapter();
                if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        try {
                            bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
                        } catch (SecurityException se) {
                            Log.e(TAG, "Scanner requires BLUETOOTH_SCAN on Android 12+");
                        }
                        try {
                            bluetoothLeAdvertiser = bluetoothAdapter.getBluetoothLeAdvertiser();
                        } catch (SecurityException se) {
                            Log.e(TAG, "Advertiser requires BLUETOOTH_ADVERTISE on Android 12+");
                        }
                    }
                    Log.d(TAG, "✅ Bluetooth initialized successfully");
                    Log.d(TAG, "   - BLE Scanner: " + (bluetoothLeScanner != null));
                    Log.d(TAG, "   - BLE Advertiser: " + (bluetoothLeAdvertiser != null));
                    startAdvertising();
                } else {
                    Log.e(TAG, "Bluetooth not available or disabled");
                    notifyError("Bluetooth not available or disabled");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing Bluetooth", e);
            notifyError("Bluetooth initialization failed: " + e.getMessage());
        }
    }

    private void initializeChatService() {
        chatService = new BluetoothChatService(context);
        chatService.setMessageListener(new BluetoothChatService.MessageListener() {
            @Override
            public void onMessageReceived(String message) {
                Log.d(TAG, "📩 Raw message received: " + message);
                handleIncomingMessage(message);
            }

            @Override
            public void onConnectionStatusChanged(int state) {
                Log.d(TAG, "Bluetooth connection state: " + state);
                handleConnectionStateChange(state);
            }

            @Override
            public void onConnectionFailed() {
                Log.d(TAG, "Bluetooth connection failed");
                handleConnectionFailed();
            }

            @Override
            public void onSecurityError(String[] missingPermissions, String operation, String detail) {
                String msg = "Security error: " + operation + " — " + detail + " | Missing: " + String.join(",", missingPermissions);
                Log.e(TAG, msg);
                notifyError(msg);
            }

            @Override
            public void onError(String title, String detail) {
                notifyError(title + ": " + detail);
            }
        });
        chatService.start();
    }

    private void loadExistingMappings() {
        new Thread(() -> {
            try {
                List<DeviceMapping> allContacts = deviceMappingDao.getAllContacts();
                for (DeviceMapping contact : allContacts) {
                    if (contact.bluetoothAddress != null && !contact.bluetoothAddress.isEmpty()) {
                        try {
                            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(contact.bluetoothAddress);
                            if (device != null) {
                                phoneToDeviceMap.put(contact.phoneNumber, device);
                                deviceLastSeen.put(contact.phoneNumber, System.currentTimeMillis());
                                Log.d(TAG, "Loaded mapping: " + contact.phoneNumber + " -> " + contact.bluetoothAddress);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error loading device for " + contact.phoneNumber, e);
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error loading existing mappings", e);
            }
        }).start();
    }

    // =========================== Advertising ===========================

    public void startAdvertising() {
        Log.d(TAG, "🎯 startAdvertising() - Checking authentication status...");

        if (!authManager.isUserAuthenticated()) {
            notifyError("Please login first");
            return;
        }

        String currentUserPhone = authManager.getPhoneNumberForAdvertising();
        if (currentUserPhone == null) {
            notifyError("Phone number not available for advertising");
            return;
        }
        if (!isValidPhoneNumber(currentUserPhone)) {
            notifyError("Invalid phone number format");
            return;
        }
        startAdvertisingWithPhone(currentUserPhone);
    }

    private void startAdvertisingWithPhone(String phoneNumber) {
        try {
            Log.d(TAG, "🚀 Advertising start");
            if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) return;
            if (bluetoothLeAdvertiser == null) return;

            if (!ensurePermission(Manifest.permission.BLUETOOTH_ADVERTISE, "start BLE advertising")) return;

            AdvertiseSettings settings = new AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build();

            // Service UUID only — no PII in advertisement
            AdvertiseData data = new AdvertiseData.Builder()
                    .addServiceUuid(PARCEL_SERVICE_UUID)
                    .setIncludeDeviceName(false)
                    .setIncludeTxPowerLevel(false)
                    .build();

            advertiseCallback = new AdvertiseCallback() {
                @Override
                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                    isAdvertising = true;
                    Log.d(TAG, "✅ Advertising started");
                    if (meshCallback != null) handler.post(() -> meshCallback.onAdvertisingStarted());
                }

                @Override
                public void onStartFailure(int errorCode) {
                    isAdvertising = false;
                    Log.e(TAG, "Advertising failed: " + getAdvertiseErrorString(errorCode));
                    handleAdvertisingFailure(errorCode, phoneNumber);
                }
            };

            try {
                bluetoothLeAdvertiser.startAdvertising(settings, data, advertiseCallback);
            } catch (SecurityException se) {
                isAdvertising = false;
                notifyError("Nearby Devices permission required to advertise");
            }

        } catch (Exception e) {
            Log.e(TAG, "Advertising error", e);
            isAdvertising = false;
        }
    }

    private void startManufacturerAdvertising(String phoneNumber) {
        try {
            Log.d(TAG, "🔄 Manufacturer Data advertising...");
            if (bluetoothLeAdvertiser == null) return;
            if (!ensurePermission(Manifest.permission.BLUETOOTH_ADVERTISE, "manufacturer advertising")) return;

            AdvertiseSettings settings = new AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build();

            byte[] phoneData = phoneNumber.getBytes(StandardCharsets.UTF_8);
            int manufacturerId = 0xFFFF;

            AdvertiseData manufacturerDataAd = new AdvertiseData.Builder()
                    .addServiceUuid(PARCEL_SERVICE_UUID)
                    .addManufacturerData(manufacturerId, phoneData)
                    .setIncludeDeviceName(false)
                    .setIncludeTxPowerLevel(false)
                    .build();

            bluetoothLeAdvertiser.startAdvertising(settings, manufacturerDataAd, new AdvertiseCallback() {
                @Override
                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                    isAdvertising = true;
                    Log.d(TAG, "✅ Manufacturer advertising success");
                    if (meshCallback != null) handler.post(() -> meshCallback.onAdvertisingStarted());
                }

                @Override
                public void onStartFailure(int errorCode) {
                    Log.e(TAG, "Manufacturer advertising failed: " + getAdvertiseErrorString(errorCode));
                    startMinimalAdvertising(phoneNumber);
                }
            });

        } catch (SecurityException se) {
            notifyError("Nearby Devices permission required to advertise (manufacturer data)");
        } catch (Exception e) {
            Log.e(TAG, "Manufacturer advertising error", e);
            isAdvertising = false;
        }
    }

    private void startMinimalAdvertising(String phoneNumber) {
        try {
            Log.d(TAG, "🔄 Minimal advertising (fallback)...");
            if (bluetoothLeAdvertiser == null) return;
            if (!ensurePermission(Manifest.permission.BLUETOOTH_ADVERTISE, "minimal advertising")) return;

            AdvertiseSettings settings = new AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build();

            AdvertiseData minimalData = new AdvertiseData.Builder()
                    .addServiceUuid(PARCEL_SERVICE_UUID)
                    .setIncludeDeviceName(false) // keep name off – requires CONNECT on read anyway
                    .setIncludeTxPowerLevel(false)
                    .build();

            bluetoothLeAdvertiser.startAdvertising(settings, minimalData, new AdvertiseCallback() {
                @Override
                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                    isAdvertising = true;
                    Log.d(TAG, "✅ Minimal advertising started");
                    if (meshCallback != null) handler.post(() -> meshCallback.onAdvertisingStarted());
                }

                @Override
                public void onStartFailure(int errorCode) {
                    isAdvertising = false;
                    Log.e(TAG, "All advertising methods failed");
                    notifyError("This device cannot advertise BLE data");
                }
            });

        } catch (SecurityException se) {
            notifyError("Nearby Devices permission required to advertise (minimal)");
        } catch (Exception e) {
            Log.e(TAG, "Minimal advertising error", e);
            isAdvertising = false;
        }
    }

    private void startUltraMinimalAdvertising(String shortPhone) {
        try {
            Log.d(TAG, "🔄 Ultra-minimal advertising...");
            if (bluetoothLeAdvertiser == null) return;
            if (!ensurePermission(Manifest.permission.BLUETOOTH_ADVERTISE, "ultra-minimal advertising")) return;

            AdvertiseSettings settings = new AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_LOW)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build();

            AdvertiseData data = new AdvertiseData.Builder()
                    .addServiceUuid(PARCEL_SERVICE_UUID)
                    .setIncludeDeviceName(false)
                    .setIncludeTxPowerLevel(false)
                    .build();

            bluetoothLeAdvertiser.startAdvertising(settings, data, new AdvertiseCallback() {
                @Override
                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                    isAdvertising = true;
                    Log.d(TAG, "✅ Ultra-minimal advertising started");
                }

                @Override
                public void onStartFailure(int errorCode) {
                    Log.e(TAG, "All advertising methods failed");
                    isAdvertising = false;
                }
            });

        } catch (SecurityException se) {
            notifyError("Nearby Devices permission required to advertise (ultra-minimal)");
        } catch (Exception e) {
            Log.e(TAG, "Ultra-minimal advertising error", e);
            isAdvertising = false;
        }
    }

    private void startAdvertisingWithoutServiceUuid(String shortPhone) {
        try {
            Log.d(TAG, "🔄 Advertising without Service UUID...");
            if (bluetoothLeAdvertiser == null) return;
            if (!ensurePermission(Manifest.permission.BLUETOOTH_ADVERTISE, "manufacturer-only advertising")) return;

            AdvertiseSettings settings = new AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build();

            byte[] phoneData = shortPhone.getBytes(StandardCharsets.UTF_8);

            AdvertiseData data = new AdvertiseData.Builder()
                    .addManufacturerData(0x00E0, phoneData)
                    .setIncludeDeviceName(false)
                    .setIncludeTxPowerLevel(false)
                    .build();

            bluetoothLeAdvertiser.startAdvertising(settings, data, new AdvertiseCallback() {
                @Override
                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                    isAdvertising = true;
                    Log.d(TAG, "✅ Manufacturer-only advertising success");
                }

                @Override
                public void onStartFailure(int errorCode) {
                    Log.e(TAG, "Manufacturer Data failed: " + getAdvertiseErrorString(errorCode));
                    startUltraMinimalAdvertising(shortPhone);
                }
            });

        } catch (SecurityException se) {
            notifyError("Nearby Devices permission required to advertise (manufacturer)");
        } catch (Exception e) {
            Log.e(TAG, "Manufacturer advertising error", e);
            isAdvertising = false;
        }
    }

    public void stopAdvertising() {
        if (bluetoothLeAdvertiser != null && isAdvertising && advertiseCallback != null) {
            try {
                if (!ensurePermission(Manifest.permission.BLUETOOTH_ADVERTISE, "stop advertising")) return;
                bluetoothLeAdvertiser.stopAdvertising(advertiseCallback);
                isAdvertising = false;
                Log.d(TAG, "📡 Advertising stopped");
                if (meshCallback != null) handler.post(() -> meshCallback.onAdvertisingStopped());
            } catch (SecurityException se) {
                notifyError("Nearby Devices permission required to stop advertising");
            } catch (Exception e) {
                Log.e(TAG, "Error stopping advertising", e);
            }
        }
    }

    private void handleAdvertisingFailure(int errorCode, String phoneNumber) {
        switch (errorCode) {
            case AdvertiseCallback.ADVERTISE_FAILED_DATA_TOO_LARGE:
                Log.d(TAG, "Data too large, trying minimal advertising...");
                startMinimalAdvertising(phoneNumber);
                break;
            case AdvertiseCallback.ADVERTISE_FAILED_FEATURE_UNSUPPORTED:
                Log.d(TAG, "Feature unsupported, trying basic advertising...");
                startBasicAdvertising(phoneNumber);
                break;
            default:
                Log.e(TAG, "Advertising failed with unrecoverable error");
                notifyError("Advertising failed: " + getAdvertiseErrorString(errorCode));
                break;
        }
    }

    private void startBasicAdvertising(String phoneNumber) {
        try {
            Log.d(TAG, "🔄 Basic advertising (last resort)");
            if (bluetoothLeAdvertiser == null) return;
            if (!ensurePermission(Manifest.permission.BLUETOOTH_ADVERTISE, "basic advertising")) return;

            AdvertiseSettings settings = new AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_POWER)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_LOW)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build();

            AdvertiseData data = new AdvertiseData.Builder()
                    .addServiceUuid(PARCEL_SERVICE_UUID)
                    .build();

            bluetoothLeAdvertiser.startAdvertising(settings, data, new AdvertiseCallback() {
                @Override
                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                    isAdvertising = true;
                    Log.d(TAG, "✅ Basic advertising started (no phone data)");
                    if (meshCallback != null) handler.post(() -> meshCallback.onAdvertisingStarted());
                }

                @Override
                public void onStartFailure(int errorCode) {
                    isAdvertising = false;
                    Log.e(TAG, "Basic advertising failed");
                    notifyError("This device cannot advertise BLE data");
                }
            });

        } catch (SecurityException se) {
            notifyError("Nearby Devices permission required to advertise (basic)");
        } catch (Exception e) {
            Log.e(TAG, "Error in basic advertising", e);
            isAdvertising = false;
        }
    }

    // =========================== Discovery / Scanning ===========================

    public void startDiscovery() {
        Log.d(TAG, "🎯 startDiscovery() called");

        if (bluetoothAdapter == null) {
            Log.e(TAG, "Cannot scan: Bluetooth adapter is null");
            return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            Log.e(TAG, "Cannot scan: Bluetooth is disabled");
            return;
        }
        if (bluetoothLeScanner == null) {
            try {
                bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
            } catch (SecurityException se) {
                notifyError("Nearby Devices permission required to get BLE scanner");
                return;
            }
            if (bluetoothLeScanner == null) {
                notifyError("BLE scanner unavailable on this device");
                return;
            }
        }
        if (isScanning) {
            Log.d(TAG, "Already scanning, skipping");
            return;
        }

        // Permission guard (Android 12+)
        if (!ensurePermissions(new String[]{
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT // reading names during callbacks
        }, "start scanning")) return;

        Log.d(TAG, "🔄 Starting device discovery");
        isScanning = true;

        try {
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
                    .setMatchMode(ScanSettings.MATCH_MODE_AGGRESSIVE)
                    .setReportDelay(0)
                    .build();

            List<ScanFilter> filters = new ArrayList<>();
            ScanFilter filter = new ScanFilter.Builder()
                    .setServiceUuid(PARCEL_SERVICE_UUID)
                    .build();
            filters.add(filter);

            if (scanCallback == null) {
                scanCallback = createScanCallback();
            }

            try {
                bluetoothLeScanner.startScan(filters, settings, scanCallback);
            } catch (SecurityException se) {
                isScanning = false;
                notifyError("Nearby Devices permission required to scan");
                return;
            }

            if (meshCallback != null) handler.post(() -> meshCallback.onDiscoveryStarted());
            handler.postDelayed(this::stopDiscovery, SCAN_DURATION);

        } catch (Exception e) {
            Log.e(TAG, "Unexpected error in scanning", e);
            isScanning = false;
        }
    }

    public void stopDiscovery() {
        if (bluetoothLeScanner != null && isScanning) {
            try {
                if (!ensurePermission(Manifest.permission.BLUETOOTH_SCAN, "stop scanning")) return;
                bluetoothLeScanner.stopScan(scanCallback);
                isScanning = false;
                Log.d(TAG, "🔍 Discovery stopped");
                if (meshCallback != null && !handler.getLooper().getThread().isInterrupted()) {
                    handler.post(() -> {
                        if (meshCallback != null) meshCallback.onDiscoveryStopped();
                    });
                }
            } catch (SecurityException se) {
                notifyError("Nearby Devices permission required to stop scanning");
            } catch (Exception e) {
                Log.e(TAG, "Error stopping scan", e);
            }
        }
    }

    private ScanCallback createScanCallback() {
        return new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                processScanResult(result);
            }

            @Override
            public void onBatchScanResults(List<ScanResult> results) {
                for (ScanResult result : results) {
                    processScanResult(result);
                }
            }

            @Override
            public void onScanFailed(int errorCode) {
                Log.e(TAG, "Scan failed: " + errorCode);
                isScanning = false;
                if (meshCallback != null) handler.post(() -> meshCallback.onDiscoveryStopped());
            }
        };
    }

    private void processScanResult(ScanResult result) {
        BluetoothDevice device = result.getDevice();
        String deviceAddress = safeDeviceAddress(device);
        int rssi = result.getRssi();

        long currentTime = System.currentTimeMillis();
        Long lastProcessed = processedDevices.get(deviceAddress);
        if (lastProcessed != null && (currentTime - lastProcessed) < 10000) {
            return;
        }
        processedDevices.put(deviceAddress, currentTime);

        Log.d(TAG, "🔍 Found Device: " + deviceAddress + " RSSI: " + rssi);

        ScanRecord scanRecord = result.getScanRecord();
        if (scanRecord == null) return;

        String deviceType = extractPhoneFromAdvertisement(scanRecord); // returns non-null if our service present
        if (deviceType != null) {
            Log.d(TAG, "🎯 RippleTalk device found: " + deviceAddress);
            if (shouldInitiateConnection(device) && currentConnectedDevice == null) {
                connectAndExchangePhoneNumbersSimple(device, deviceAddress, rssi);
            }
        }
    }

    // =========================== Connection & Phone Exchange ===========================

    private boolean shouldInitiateConnection(BluetoothDevice device) {
        if (device == null || bluetoothAdapter == null) return false;

        String ourMac;
        String theirMac;
        try {
            ourMac = bluetoothAdapter.getAddress();
        } catch (SecurityException se) {
            ourMac = "FF:FF:FF:FF:FF:FF";
        }
        theirMac = safeDeviceAddress(device);

        boolean shouldConnect = ourMac.compareTo(theirMac) < 0;
        Log.d(TAG, "🎯 Connection decision - Our MAC: " + ourMac +
                ", Their MAC: " + theirMac + ", Should connect: " + shouldConnect);
        return shouldConnect;
    }

    private void connectAndExchangePhoneNumbersSimple(BluetoothDevice device, String deviceAddress, int rssi) {
        try {
            if (isInitiatingConnection || currentConnectedDevice != null) return;
            isInitiatingConnection = true;
            lastConnectionAttempt = System.currentTimeMillis();

            Log.d(TAG, "🔗 QUICK CONNECT to: " + safeDeviceName(device));
            String tempId = "CONNECTING_" + System.currentTimeMillis();

            connectToDevice(device, tempId);

            handler.postDelayed(() -> isInitiatingConnection = false, 3000);
        } catch (Exception e) {
            Log.e(TAG, "Quick connect failed", e);
            isInitiatingConnection = false;
        }
    }

    private void connectToDevice(BluetoothDevice device, String phoneNumber) {
        synchronized (connectionLock) {
            if (isConnectionInProgress || currentConnectedDevice != null) {
                Log.d(TAG, "⏭️ Connection already in progress, skipping: " + phoneNumber);
                return;
            }
            isConnectionInProgress = true;
            currentConnectingDevice = phoneNumber;
        }

        if (!ensurePermission(Manifest.permission.BLUETOOTH_CONNECT, "connect to device")) {
            synchronized (connectionLock) { isConnectionInProgress = false; }
            return;
        }
        safeCancelDiscovery();

        Log.d(TAG, "🔗 Connecting to device (id): " + phoneNumber);
        currentConnectedDevice = phoneNumber;
        chatService.connect(device);
    }

    private void handleConnectionStateChange(int state) {
        Log.d(TAG, "🔗 Connection state changed: " + state);

        switch (state) {
            case BluetoothChatService.STATE_CONNECTED:
                synchronized (connectionLock) {
                    isConnectionInProgress = false;
                }
                if (currentConnectedDevice != null) {
                    connectionStates.put(currentConnectedDevice, true);
                    isInitiatingConnection = false;

                    Log.d(TAG, "🎉 CONNECTED TO: " + currentConnectedDevice);

                    startKeepAlive();

                    handler.postDelayed(() -> {
                        if (chatService.isConnected()) {
                            forcePhoneExchangeAfterConnection();
                        }
                    }, 500);

                    final String connectedDevice = currentConnectedDevice;
                    executeCallbackSafely(() -> {
                        meshCallback.onDeviceConnected(connectedDevice);
                        meshCallback.onConnectionStatusChanged(connectedDevice, true);
                    });
                }
                break;

            case BluetoothChatService.STATE_DISCONNECTED:
            case BluetoothChatService.STATE_NONE:
                Log.w(TAG, "⚠️ Connection lost or reset to listening");
                synchronized (connectionLock) {
                    isConnectionInProgress = false;
                }

                stopKeepAlive();
                isInitiatingConnection = false;

                if (currentConnectedDevice != null) {
                    connectionStates.put(currentConnectedDevice, false);

                    final String disconnectedDevice = currentConnectedDevice;
                    executeCallbackSafely(() -> {
                        meshCallback.onDeviceDisconnected(disconnectedDevice);
                        meshCallback.onConnectionStatusChanged(disconnectedDevice, false);
                    });

                    handler.postDelayed(() -> {
                        if (isDeviceInRange(currentConnectedDevice) && !isConnectionInProgress) {
                            Log.d(TAG, "🔄 Auto-reconnecting to: " + currentConnectedDevice);
                            BluetoothDevice device = phoneToDeviceMap.get(currentConnectedDevice);
                            if (device != null) {
                                connectToDevice(device, currentConnectedDevice);
                            }
                        }
                    }, 2000);
                }
                break;

            case BluetoothChatService.STATE_CONNECTING:
                Log.d(TAG, "🔄 Connecting to device...");
                break;

            case BluetoothChatService.STATE_LISTEN:
                Log.d(TAG, "👂 Listening for connections...");
                break;
        }
    }

    private void handleConnectionFailed() {
        Log.e(TAG, "Connection failed");
        if (currentConnectedDevice != null) {
            connectionStates.put(currentConnectedDevice, false);
            if (meshCallback != null) {
                handler.post(() -> {
                    meshCallback.onConnectionStatusChanged(currentConnectedDevice, false);
                    meshCallback.onError("Connection failed to " + currentConnectedDevice);
                });
            }
        } else {
            if (meshCallback != null) {
                handler.post(() -> meshCallback.onError("Connection failed - no device specified"));
            }
        }
        currentConnectedDevice = null;
        isInitiatingConnection = false;
        synchronized (connectionLock) { isConnectionInProgress = false; }
    }

    private void startKeepAlive() {
        Log.d(TAG, "❤️ Starting keep-alive");
        keepAliveHandler.removeCallbacks(keepAliveTask);
        if (chatService != null && chatService.isConnected()) {
            keepAliveHandler.postDelayed(keepAliveTask, 5000);
        } else {
            Log.w(TAG, "Cannot start keep-alive - not connected");
        }
    }

    private void stopKeepAlive() {
        Log.d(TAG, "🛑 Stopping keep-alive");
        keepAliveHandler.removeCallbacks(keepAliveTask);
    }

    private void forcePhoneExchangeAfterConnection() {
        if (currentConnectedDevice == null) {
            Log.e(TAG, "No connected device for phone exchange");
            return;
        }
        String currentUser = authManager.getAuthenticatedUser();
        if (currentUser == null) {
            Log.e(TAG, "No authenticated user for phone exchange");
            return;
        }
        try {
            String phoneMessage = "PHONE:" + currentUser + "\n";
            chatService.write(phoneMessage.getBytes(StandardCharsets.UTF_8));
            Log.d(TAG, "📱 PHONE SENT: " + currentUser);
        } catch (Exception e) {
            Log.e(TAG, "Phone exchange failed", e);
        }
    }

    // =========================== Messaging & Routing ===========================

    private void handleIncomingMessage(String message) {
        try {
            String[] messageLines = message.split("\n");
            for (String singleMessage : messageLines) {
                processSingleMessage(singleMessage.trim());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error handling message", e);
        }
    }

    private boolean isSystemMessage(String message) {
        if (message == null || message.trim().isEmpty()) return true;
        String lowerMessage = message.toLowerCase().trim();

        String[] systemPatterns = {
                "ping", "pong", "test message", "hello from rippletalk",
                "connection established", "connection successful", "connection working",
                "phone exchange", "keep-alive", "heartbeat", "bluetooth test",
                "mesh test", "routing test", "sys_", "keepalive", "test message at"
        };
        for (String pattern : systemPatterns) {
            if (lowerMessage.contains(pattern)) return true;
        }
        if (lowerMessage.matches(".*test.*at.*[0-9]{10,}.*")) return true;
        if (message.matches("^[0-9]{10,}$")) return true;
        return false;
    }

    // ✅ Safely post callback actions without risking NPE or thread errors
    private void executeCallbackSafely(Runnable callbackAction) {
        try {
            if (meshCallback != null && handler.getLooper().getThread().isAlive()) {
                handler.post(() -> {
                    if (meshCallback != null) {
                        callbackAction.run();
                    }
                });
            }
        } catch (Exception e) {
            Log.e(TAG, "Error executing callback safely", e);
        }
    }

    // ✅ Update message delivery status / UI notifications
    private void updateMessageStatus(String targetPhone, String message, boolean delivered) {
        new Thread(() -> {
            try {
                Log.d(TAG, "📨 Delivery status: " + message +
                        " -> " + targetPhone + " | delivered=" + delivered);

                if (meshCallback != null) {
                    handler.post(() ->
                            meshCallback.onMessageDeliveryStatus(
                                    targetPhone,
                                    delivered,
                                    String.valueOf(message.hashCode())
                            )
                    );
                }

            } catch (Exception e) {
                Log.e(TAG, "Error updating message status", e);
            }
        }).start();
    }

    private void processSingleMessage(String message) {
        if (message.isEmpty()) return;
        Log.d(TAG, "🔍 PROCESSING: " + message);

        // Relay first
        if (message.startsWith("RELAY|")) {
            handleRelayMessage(message);
            return;
        }

        // Filter system
        if (isSystemMessage(message)) {
            Log.d(TAG, "⏭️ Ignoring system message: " + message);
            return;
        }

        // Phone exchange
        if (message.startsWith("PHONE:")) {
            String phoneNumber = message.substring(6).trim();
            String cleanPhone = phoneNumber.replaceAll("[^0-9]", "");
            if (cleanPhone.length() > 10) cleanPhone = cleanPhone.substring(0, 10);

            if (isValidPhoneNumber(cleanPhone)) {
                if (currentConnectedDevice != null && currentConnectedDevice.equals(cleanPhone)) return;

                Log.d(TAG, "✅ Valid phone received: " + cleanPhone);

                synchronized (this) { currentConnectedDevice = cleanPhone; }
                connectionStates.put(cleanPhone, true);
                storePhoneNumberMapping(cleanPhone);

                final String finalCleanPhone = cleanPhone;
                executeCallbackSafely(() -> {
                    meshCallback.onDevicePaired(finalCleanPhone);
                    meshCallback.onConnectionStatusChanged(finalCleanPhone, true);
                    meshCallback.onDeviceConnected(finalCleanPhone);
                });

                sendOurPhoneNumber();
            }
            return;
        }

        // Chat format: FROM:MESSAGE
        if (message.contains(":")) {
            String[] parts = message.split(":", 2);
            if (parts.length == 2) {
                String fromPhone = parts[0].trim();
                String actualMessage = parts[1].trim();

                if (isSystemMessage(actualMessage)) return;

                String cleanFromPhone = fromPhone.replaceAll("[^0-9]", "");
                if (cleanFromPhone.length() > 10) {
                    cleanFromPhone = cleanFromPhone.substring(cleanFromPhone.length() - 10);
                }

                if (isValidPhoneNumber(cleanFromPhone)) {
                    Log.d(TAG, "💬 MESSAGE FROM: " + cleanFromPhone + " - " + actualMessage);
                    saveMessageToDatabase(cleanFromPhone, actualMessage, true);

                    final String finalFromPhone = cleanFromPhone;
                    final String finalActualMessage = actualMessage;
                    executeCallbackSafely(() -> {
                        meshCallback.onMessageReceived(finalFromPhone, finalActualMessage);
                        meshCallback.onConnectionStatusChanged(finalFromPhone, true);
                    });
                }
            }
        } else {
            if (currentConnectedDevice != null && isValidPhoneNumber(currentConnectedDevice)) {
                Log.d(TAG, "💬 PLAIN CHAT MESSAGE: " + message);
                saveMessageToDatabase(currentConnectedDevice, message, true);

                final String finalFromPhone = currentConnectedDevice;
                final String finalActualMessage = message;
                executeCallbackSafely(() -> meshCallback.onMessageReceived(finalFromPhone, finalActualMessage));
            }
        }
    }

    private void handleRelayMessage(String relayMessage) {
        try {
            // Format: "RELAY|TARGET_PHONE|SENDER_PHONE:ACTUAL_MESSAGE"
            String[] parts = relayMessage.split("\\|", 3);
            if (parts.length == 3) {
                String finalTarget = parts[1].trim();
                String originalMessage = parts[2].trim(); // "SENDER_PHONE:ACTUAL_MESSAGE"

                String currentUser = authManager.getAuthenticatedUser();

                if (finalTarget.equals(currentUser)) {
                    Log.d(TAG, "📨 RECEIVED RELAYED MESSAGE for me: " + originalMessage);
                    processSingleMessage(originalMessage);
                } else {
                    Log.d(TAG, "🔄 FORWARDING RELAY to: " + finalTarget);
                    if (isDeviceConnected(finalTarget)) {
                        String forwardMessage = "RELAY|" + finalTarget + "|" + originalMessage;
                        chatService.write(forwardMessage.getBytes(StandardCharsets.UTF_8));
                        Log.d(TAG, "✅ Successfully forwarded to final target");
                    } else {
                        Log.d(TAG, "Cannot reach final target directly, finding another relay...");
                        findAndUseRelay(finalTarget, originalMessage);
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error handling relay message", e);
        }
    }

    private boolean attemptDirectMessage(String targetPhone, String message) {
        try {
            if (isDeviceConnected(targetPhone)) {
                chatService.write(message.getBytes(StandardCharsets.UTF_8));
                Log.d(TAG, "✅ Direct message sent to: " + targetPhone);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Direct message failed to: " + targetPhone, e);
        }
        return false;
    }

    private void findAndUseRelay(String finalTarget, String originalMessage) {
        try {
            String currentUser = authManager.getAuthenticatedUser();
            List<DeviceMapping> potentialRelays = new ArrayList<>();
            List<DeviceMapping> allDevices = deviceMappingDao.getAllContacts();

            for (DeviceMapping device : allDevices) {
                if (!device.phoneNumber.equals(finalTarget) &&
                        !device.phoneNumber.equals(currentUser) &&
                        isDeviceConnected(device.phoneNumber)) {
                    potentialRelays.add(device);
                }
            }

            for (DeviceMapping relay : potentialRelays) {
                String relayMessage = "RELAY|" + finalTarget + "|" + originalMessage;
                boolean sent = attemptDirectMessage(relay.phoneNumber, relayMessage);
                if (sent) {
                    Log.d(TAG, "✅ Routed via alternative relay: " + relay.phoneNumber);
                    return;
                }
            }

            Log.d(TAG, "No alternative relay path found");

        } catch (Exception e) {
            Log.e(TAG, "Error finding alternative relay", e);
        }
    }

    public boolean sendMessageToContact(String targetPhoneNumber, String message) {
        Log.d(TAG, "📤 Sending message to: " + targetPhoneNumber + " - " + message);
        saveMessageToDatabase(targetPhoneNumber, message, false);

        if (attemptDirectDelivery(targetPhoneNumber, message)) return true;
        if (attemptMeshDelivery(targetPhoneNumber, message)) return true;

        Log.w(TAG, "Device not connected, queuing message for: " + targetPhoneNumber);
        queueMessageForDevice(targetPhoneNumber, message);
        startDiscovery();
        return false;
    }

    private boolean attemptDirectDelivery(String targetPhoneNumber, String message) {
        if (isDeviceConnected(targetPhoneNumber)) {
            try {
                String currentUser = authManager.getAuthenticatedUser();
                if (currentUser == null) return false;

                String formattedMessage = currentUser + ":" + message + "\n";
                Log.d(TAG, "📤 SENDING FORMATTED MESSAGE: " + formattedMessage.trim());

                chatService.write(formattedMessage.getBytes(StandardCharsets.UTF_8));
                Log.d(TAG, "✅ Message sent directly to: " + targetPhoneNumber);

                updateMessageStatus(targetPhoneNumber, message, true);
                return true;

            } catch (Exception e) {
                Log.e(TAG, "Direct message failed", e);
            }
        }
        return false;
    }

    private boolean attemptMeshDelivery(String targetPhoneNumber, String message) {
        Log.d(TAG, "🔄 Attempting mesh routing for: " + targetPhoneNumber);
        try {
            String currentUser = authManager.getAuthenticatedUser();
            if (currentUser == null) return false;

            List<DeviceMapping> potentialRelays = findPotentialRelays(targetPhoneNumber);
            if (potentialRelays.isEmpty()) return false;

            for (DeviceMapping relay : potentialRelays) {
                String relayMessage = "RELAY|" + targetPhoneNumber + "|" + currentUser + ":" + message + "\n";
                Log.d(TAG, "🔄 Trying relay via: " + relay.phoneNumber + " (" + relay.deviceName + ")");
                boolean sent = attemptDirectDelivery(relay.phoneNumber, relayMessage);
                if (sent) {
                    Log.d(TAG, "✅ Message routed via: " + relay.phoneNumber);
                    updateMessageStatus(targetPhoneNumber, message, true);
                    return true;
                }
            }
            return false;

        } catch (Exception e) {
            Log.e(TAG, "Mesh routing failed", e);
            return false;
        }
    }

    public List<DeviceMapping> findPotentialRelays(String excludePhone) {
        List<DeviceMapping> potentialRelays = new ArrayList<>();
        String currentUser = authManager.getAuthenticatedUser();
        try {
            List<DeviceMapping> allDevices = deviceMappingDao.getAllContacts();
            for (DeviceMapping device : allDevices) {
                if (!device.phoneNumber.equals(excludePhone) &&
                        !device.phoneNumber.equals(currentUser) &&
                        isDeviceConnected(device.phoneNumber)) {
                    potentialRelays.add(device);
                }
            }
            Collections.sort(potentialRelays, (d1, d2) ->
                    Integer.compare(d2.signalStrength, d1.signalStrength));
        } catch (Exception e) {
            Log.e(TAG, "Error finding potential relays", e);
        }
        return potentialRelays;
    }

    private void queueMessageForDevice(String phoneNumber, String message) {
        messageQueue.computeIfAbsent(phoneNumber, k -> new ArrayList<>()).add(message);
        Log.d(TAG, "💾 Queued message for " + phoneNumber + ": " + message);
    }

    private void retryQueuedMessages() {
        if (currentConnectedDevice == null) return;

        List<String> messages = messageQueue.get(currentConnectedDevice);
        if (messages != null && !messages.isEmpty()) {
            Log.d(TAG, "🔄 Retrying " + messages.size() + " queued messages for: " + currentConnectedDevice);
            List<String> messagesToSend = new ArrayList<>(messages);
            for (String message : messagesToSend) {
                if (sendDirectMessage(currentConnectedDevice, message)) {
                    messages.remove(message);
                    Log.d(TAG, "✅ Delivered queued message to: " + currentConnectedDevice);
                }
            }
        }
    }

    private boolean sendDirectMessage(String targetPhoneNumber, String message) {
        BluetoothDevice targetDevice = phoneToDeviceMap.get(targetPhoneNumber);
        if (targetDevice == null) {
            Log.e(TAG, "Cannot send message: Device not found for " + targetPhoneNumber);
            return false;
        }

        try {
            String currentUser = authManager.getAuthenticatedUser();
            String formattedMessage = currentUser + ":" + message;

            if (!targetPhoneNumber.equals(currentConnectedDevice)) {
                connectToDevice(targetDevice, targetPhoneNumber);
                Thread.sleep(500);
            }

            if (targetPhoneNumber.equals(currentConnectedDevice)) {
                chatService.write(formattedMessage.getBytes(StandardCharsets.UTF_8));
                Log.d(TAG, "✅ Direct message sent to: " + targetPhoneNumber);
                updateMessageStatus(targetPhoneNumber, message, true);
                return true;
            } else {
                Log.e(TAG, "Not connected to target device: " + targetPhoneNumber);
                return false;
            }

        } catch (Exception e) {
            Log.e(TAG, "Direct message failed: " + targetPhoneNumber, e);
            return false;
        }
    }

    private void sendOurPhoneNumber() {
        String currentUser = authManager.getAuthenticatedUser();
        if (currentUser == null) {
            Log.e(TAG, "No authenticated user to send phone number");
            return;
        }
        try {
            String phoneMessage = "PHONE:" + currentUser + "\n";
            chatService.write(phoneMessage.getBytes(StandardCharsets.UTF_8));
            Log.d(TAG, "✅ OUR PHONE SENT: " + currentUser);
        } catch (Exception e) {
            Log.e(TAG, "Error sending our phone number", e);
        }
    }

    // =========================== Data / Mapping / Persistence ===========================

    private void storePhoneNumberMapping(String phoneNumber) {
        try {
            BluetoothDevice connectedDevice = findConnectedBluetoothDevice();
            if (connectedDevice != null) {
                String deviceAddress = safeDeviceAddress(connectedDevice);
                phoneToDeviceMap.put(phoneNumber, connectedDevice);
                deviceLastSeen.put(phoneNumber, System.currentTimeMillis());

                Log.d(TAG, "✅ DEVICE MAPPING STORED: " + phoneNumber + " -> " + deviceAddress);
                updateExistingManualContact(phoneNumber, deviceAddress, safeDeviceName(connectedDevice), -50);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error storing phone number mapping", e);
        }
    }

    private BluetoothDevice findConnectedBluetoothDevice() {
        try {
            if (chatService != null && chatService.isConnected()) {
                Set<BluetoothDevice> bondedDevices;
                try {
                    bondedDevices = bluetoothAdapter != null ? bluetoothAdapter.getBondedDevices() : new HashSet<>();
                } catch (SecurityException se) {
                    bondedDevices = new HashSet<>();
                }
                for (BluetoothDevice device : bondedDevices) {
                    // Not a real connection check, but useful heuristic
                    Log.d(TAG, "Bonded device: " + safeDeviceName(device) + " - " + safeDeviceAddress(device));
                    return device;
                }
            }
            for (Map.Entry<String, BluetoothDevice> entry : phoneToDeviceMap.entrySet()) {
                BluetoothDevice device = entry.getValue();
                if (device != null) {
                    Log.d(TAG, "Found device in map: " + safeDeviceAddress(device));
                    return device;
                }
            }
            Log.w(TAG, "No connected Bluetooth device found");
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error finding connected Bluetooth device", e);
            return null;
        }
    }

    private void updateExistingManualContact(String phoneNumber, String deviceAddress, String deviceName, int rssi) {
        new Thread(() -> {
            try {
                DeviceMapping existing = deviceMappingDao.getByPhoneNumber(phoneNumber);
                if (existing != null && existing.hasCustomName()) {
                    existing.bluetoothAddress = deviceAddress;
                    existing.isPaired = true;
                    existing.lastSeen = System.currentTimeMillis();
                    existing.signalStrength = rssi;
                    deviceMappingDao.update(existing);
                    Log.d(TAG, "Updated manual contact device: " + existing.contactName);
                } else {
                    Log.d(TAG, "Skipping auto-contact creation for: " + phoneNumber);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error updating existing contact", e);
            }
        }).start();
    }

    private void updateDeviceMappingInDatabase(String phoneNumber, String deviceAddress,
                                               String deviceName, int rssi) {
        new Thread(() -> {
            try {
                DeviceMapping existing = deviceMappingDao.getByPhoneNumber(phoneNumber);
                if (existing == null) {
                    DeviceMapping newMapping = new DeviceMapping(phoneNumber, deviceAddress);
                    newMapping.deviceName = deviceName != null ? deviceName : "Discovered Device";
                    newMapping.contactName = phoneNumber;
                    newMapping.isPaired = true;
                    newMapping.lastSeen = System.currentTimeMillis();
                    newMapping.signalStrength = rssi;
                    deviceMappingDao.insert(newMapping);
                    Log.d(TAG, "New mapping created: " + phoneNumber);
                } else {
                    existing.bluetoothAddress = deviceAddress;
                    existing.deviceName = deviceName != null ? deviceName : existing.deviceName;
                    existing.isPaired = true;
                    existing.lastSeen = System.currentTimeMillis();
                    existing.signalStrength = rssi;
                    deviceMappingDao.update(existing);
                    Log.d(TAG, "Mapping updated: " + phoneNumber);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error updating database", e);
            }
        }).start();
    }

    private void saveMessageToDatabase(String fromPhone, String message, boolean isIncoming) {
        new Thread(() -> {
            try {
                String currentUserPhone = authManager.getAuthenticatedUser();
                if (currentUserPhone != null) {
                    AppDatabase database = AppDatabase.getInstance(context);
                    ChatMessageDao chatMessageDao = database.chatMessageDao();

                    long currentTime = System.currentTimeMillis();
                    List<ChatMessage> recentMessages = chatMessageDao.getChatHistory(currentUserPhone, fromPhone);

                    boolean isDuplicate = false;
                    for (ChatMessage existingMessage : recentMessages) {
                        if (existingMessage.message.equals(message) &&
                                (currentTime - existingMessage.timestamp) < 10000) {
                            Log.d(TAG, "⏭️ Skip duplicate: '" + message + "' from " + fromPhone);
                            isDuplicate = true;
                            break;
                        }
                    }
                    if (isDuplicate) return;

                    ChatMessage chatMessage = new ChatMessage(
                            isIncoming ? fromPhone : currentUserPhone,
                            isIncoming ? currentUserPhone : fromPhone,
                            message
                    );
                    chatMessage.isIncoming = isIncoming;
                    chatMessage.messageStatus = isIncoming ? 1 : 0; // 1=delivered, 0=sent
                    chatMessage.timestamp = currentTime;

                    chatMessageDao.insert(chatMessage);
                    Log.d(TAG, "💾 Message saved: " +
                            (isIncoming ? "FROM " : "TO ") + fromPhone + " | '" + message + "'");

                } else {
                    Log.e(TAG, "Cannot save message: No authenticated user");
                }
            } catch (Exception e) {
                Log.e(TAG, "Error saving message to database", e);
            }
        }).start();
    }

    // =========================== Discovery Utils / Diagnostics ===========================

    private String extractPhoneFromAdvertisement(ScanRecord scanRecord) {
        try {
            if (scanRecord == null) return null;
            List<ParcelUuid> serviceUuids = scanRecord.getServiceUuids();
            if (serviceUuids != null) {
                for (ParcelUuid uuid : serviceUuids) {
                    if (uuid.equals(PARCEL_SERVICE_UUID)) {
                        Log.d(TAG, "🎯 OUR SERVICE UUID present");
                        return "RIPPLE_DEVICE";
                    }
                }
            }
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error checking advertisement", e);
            return null;
        }
    }

    private boolean isValidPhoneNumber(String phone) {
        if (phone == null || phone.isEmpty()) return false;
        String cleanPhone = phone.replaceAll("[^0-9]", "");

        String[] garbagePatterns = {
                "2147483648", "4294967295", "0", "1", "12345678",
                "123456789", "1234567890", "1111111111", "9999999999",
                "0000000000", "0123456789"
        };
        for (String pattern : garbagePatterns) {
            if (cleanPhone.equals(pattern) || cleanPhone.startsWith(pattern)) return false;
        }
        if (cleanPhone.matches("^(0123456789|1234567890|9876543210)$")) return false;

        boolean isValid = cleanPhone.matches("^[2-9][0-9]{9,14}$");
        return isValid;
    }

    private void debugAdvertisementData(ScanRecord scanRecord) {
        try {
            Log.d(TAG, "=== FULL ADVERTISEMENT DEBUG ===");
            if (scanRecord == null) {
                Log.d(TAG, "ScanRecord is null");
                return;
            }

            List<ParcelUuid> serviceUuids = scanRecord.getServiceUuids();
            if (serviceUuids != null) {
                Log.d(TAG, "Service UUIDs: " + serviceUuids.size());
                for (ParcelUuid uuid : serviceUuids) {
                    boolean isOurService = uuid.equals(PARCEL_SERVICE_UUID);
                    Log.d(TAG, "  - " + uuid.toString() + (isOurService ? " ✅ OUR SERVICE" : ""));
                }
            } else {
                Log.d(TAG, "No Service UUIDs found");
            }

            Map<ParcelUuid, byte[]> serviceData = scanRecord.getServiceData();
            if (serviceData != null && !serviceData.isEmpty()) {
                Log.d(TAG, "Service Data entries: " + serviceData.size());
                for (Map.Entry<ParcelUuid, byte[]> entry : serviceData.entrySet()) {
                    ParcelUuid uuid = entry.getKey();
                    byte[] data = entry.getValue();

                    String dataString = data != null ? new String(data, StandardCharsets.UTF_8).trim() : "null";
                    String dataHex = data != null ? bytesToHex(data) : "null";

                    boolean isOurService = uuid.equals(PARCEL_SERVICE_UUID);
                    Log.d(TAG, "  - UUID: " + uuid + (isOurService ? " ✅ OUR SERVICE" : ""));
                    Log.d(TAG, "    String: '" + dataString + "'");
                    Log.d(TAG, "    Hex: " + dataHex);
                    Log.d(TAG, "    Length: " + (data != null ? data.length : 0));
                }
            } else {
                Log.d(TAG, "No Service Data found");
            }

            SparseArray<byte[]> manufacturerData = scanRecord.getManufacturerSpecificData();
            if (manufacturerData != null && manufacturerData.size() > 0) {
                Log.d(TAG, "Manufacturer Data entries: " + manufacturerData.size());
                for (int i = 0; i < manufacturerData.size(); i++) {
                    int key = manufacturerData.keyAt(i);
                    byte[] data = manufacturerData.valueAt(i);

                    String dataString = data != null ? new String(data, StandardCharsets.UTF_8).trim() : "null";
                    String dataHex = data != null ? bytesToHex(data) : "null";

                    Log.d(TAG, "  - Manufacturer ID: " + key);
                    Log.d(TAG, "    String: '" + dataString + "'");
                    Log.d(TAG, "    Hex: " + dataHex);
                    Log.d(TAG, "    Length: " + (data != null ? data.length : 0));
                }
            } else {
                Log.d(TAG, "No Manufacturer Data found");
            }

            Log.d(TAG, "=== END ADVERTISEMENT DEBUG ===");
        } catch (Exception e) {
            Log.e(TAG, "Error debugging advertisement data", e);
        }
    }

    private String bytesToHex(byte[] bytes) {
        if (bytes == null) return "null";
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02X ", b));
        return sb.toString().trim();
    }

    // =========================== Periodic / Cleanup ===========================

    private void startPeriodicOperations() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                cleanupOldDevices();
                retryQueuedMessagesForNearbyDevices();

                if (!isAdvertising && isBluetoothEnabled()) {
                    startAdvertising();
                }

                handler.postDelayed(this, 30000);
            }
        }, 10000);
    }

    private void cleanupOldDevices() {
        long currentTime = System.currentTimeMillis();
        List<String> toRemove = new ArrayList<>();

        for (Map.Entry<String, Long> entry : deviceLastSeen.entrySet()) {
            String phoneNumber = entry.getKey();
            long lastSeen = entry.getValue();
            if (currentTime - lastSeen > DEVICE_TIMEOUT) {
                toRemove.add(phoneNumber);
                Log.d(TAG, "🧹 Removing old device: " + phoneNumber);
            }
        }

        for (String phoneNumber : toRemove) {
            phoneToDeviceMap.remove(phoneNumber);
            deviceLastSeen.remove(phoneNumber);
            deviceRssiMap.remove(phoneNumber);
            connectionStates.put(phoneNumber, false);

            if (meshCallback != null) {
                final String pn = phoneNumber;
                handler.post(() -> meshCallback.onConnectionStatusChanged(pn, false));
            }
        }
    }

    private void retryQueuedMessagesForNearbyDevices() {
        for (String phoneNumber : messageQueue.keySet()) {
            if (isDeviceInRange(phoneNumber) && !messageQueue.get(phoneNumber).isEmpty()) {
                Log.d(TAG, "🔄 Device is nearby, queued messages pending for: " + phoneNumber);
            }
        }
    }

    public void cleanup() {
        Log.d(TAG, "🧹 Cleaning up BluetoothMeshManager...");

        stopDiscovery();
        stopAdvertising();

        if (chatService != null) chatService.stop();

        handler.removeCallbacksAndMessages(null);
        keepAliveHandler.removeCallbacksAndMessages(null);

        phoneToDeviceMap.clear();
        deviceLastSeen.clear();
        deviceRssiMap.clear();
        connectionStates.clear();
        messageQueue.clear();

        currentConnectedDevice = null;
        targetContactPhone = null;

        Log.d(TAG, "✅ Cleanup completed");
    }

    public void safeCleanup() {
        Log.d(TAG, "🧹 SAFE Cleanup started...");
        handler.removeCallbacksAndMessages(null);
        keepAliveHandler.removeCallbacksAndMessages(null);
        meshCallback = null;
        cleanup();
        Log.d(TAG, "✅ SAFE Cleanup completed");
    }

    // =========================== Public Utils / Debug ===========================

    public boolean isBluetoothSupported() {
        boolean supported = bluetoothAdapter != null;
        Log.d(TAG, "📱 Bluetooth supported: " + supported);
        return supported;
    }

    public boolean isBluetoothEnabled() {
        boolean enabled = bluetoothAdapter != null && bluetoothAdapter.isEnabled();
        Log.d(TAG, "📱 Bluetooth enabled: " + enabled);
        return enabled;
    }

    public boolean isBLEAdvertisingSupported() {
        if (bluetoothAdapter == null) return false;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return false;
        boolean supported;
        try {
            supported = bluetoothAdapter.isMultipleAdvertisementSupported();
        } catch (SecurityException se) {
            supported = false;
        }
        Log.d(TAG, "📡 BLE Advertising Supported: " + supported);
        return supported;
    }

    public boolean isDeviceConnected(String phoneNumber) {
        if (phoneNumber == null) return false;
        if (phoneNumber.equals(currentConnectedDevice)) return true;
        Boolean connected = connectionStates.get(phoneNumber);
        return connected != null && connected;
    }

    public boolean isDeviceInRange(String phoneNumber) {
        if (phoneNumber == null) return false;
        Long lastSeen = deviceLastSeen.get(phoneNumber);
        if (lastSeen == null) return false;
        boolean inRange = (System.currentTimeMillis() - lastSeen) < DEVICE_TIMEOUT;
        Log.d(TAG, "📡 Device " + phoneNumber + " in range: " + inRange);
        return inRange;
    }

    public boolean isDeviceDiscovered(String phoneNumber) {
        boolean discovered = phoneToDeviceMap.containsKey(phoneNumber);
        Log.d(TAG, "🔍 Device " + phoneNumber + " discovered: " + discovered);
        return discovered;
    }

    public String getConnectionStatus(String phoneNumber) {
        if (phoneNumber == null) return "Unknown";
        if (phoneNumber.equals(currentConnectedDevice)) return "Connected";
        Long lastSeen = deviceLastSeen.get(phoneNumber);
        if (lastSeen != null && (System.currentTimeMillis() - lastSeen) < DEVICE_TIMEOUT) return "Online";
        if (phoneToDeviceMap.containsKey(phoneNumber)) return "Discovered";
        return "Offline";
    }

    public void setTargetContact(String phoneNumber) {
        this.targetContactPhone = phoneNumber;
        Log.d(TAG, "🎯 Target contact set: " + phoneNumber);

        if (phoneToDeviceMap.containsKey(phoneNumber) && isDeviceInRange(phoneNumber)) {
            connectToDevice(phoneToDeviceMap.get(phoneNumber), phoneNumber);
        } else {
            Log.d(TAG, "🔍 Device not found or out of range, starting discovery...");
            startDiscovery();
        }
    }

    public void forceRestartBluetooth() {
        Log.d(TAG, "🔄 FORCE RESTARTING BLUETOOTH SERVICES");
        stopDiscovery();
        stopAdvertising();
        handler.postDelayed(() -> {
            Log.d(TAG, "🔄 Starting fresh Bluetooth services...");
            startAdvertising();
            startDiscovery();
        }, 1000);
    }

    public void debugBluetoothStatus() {
        Log.d(TAG, "=== BLUETOOTH DEBUG STATUS ===");
        Log.d(TAG, "Bluetooth Adapter: " + (bluetoothAdapter != null));
        if (bluetoothAdapter != null) {
            try {
                Log.d(TAG, "Bluetooth Enabled: " + bluetoothAdapter.isEnabled());
                Log.d(TAG, "Bluetooth Name: " + bluetoothAdapter.getName());
            } catch (SecurityException se) {
                Log.d(TAG, "Bluetooth properties require CONNECT permission");
            }
        }
        Log.d(TAG, "BLE Scanner: " + (bluetoothLeScanner != null));
        Log.d(TAG, "BLE Advertiser: " + (bluetoothLeAdvertiser != null));
        Log.d(TAG, "Is Advertising: " + isAdvertising);
        Log.d(TAG, "Is Scanning: " + isScanning);
        Log.d(TAG, "Current User: " + authManager.getAuthenticatedUser());
        if (bluetoothAdapter != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            boolean isSupported;
            try {
                isSupported = bluetoothAdapter.isMultipleAdvertisementSupported();
            } catch (SecurityException se) {
                isSupported = false;
            }
            Log.d(TAG, "📡 BLE Advertising Supported: " + isSupported);
        }
        Log.d(TAG, "=== END BLUETOOTH DEBUG ===");
    }

    public void validateServiceUUID() {
        Log.d(TAG, "=== SERVICE UUID VALIDATION ===");
        Log.d(TAG, "Service UUID: " + SERVICE_UUID);
        Log.d(TAG, "Parcel UUID: " + PARCEL_SERVICE_UUID);
        Log.d(TAG, "UUID String: " + PARCEL_SERVICE_UUID.toString());
    }

    public void testOwnAdvertisement() {
        new Thread(() -> {
            try {
                Log.d(TAG, "=== SELF-ADVERTISEMENT TEST ===");
                Thread.sleep(2000);

                if (!isScanning) {
                    ScanSettings settings = new ScanSettings.Builder()
                            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                            .build();

                    List<ScanFilter> filters = new ArrayList<>();
                    filters.add(new ScanFilter.Builder()
                            .setServiceUuid(PARCEL_SERVICE_UUID)
                            .build());

                    ScanCallback testCallback = new ScanCallback() {
                        @Override
                        public void onScanResult(int callbackType, ScanResult result) {
                            Log.d(TAG, "✅ SELF-TEST: Found our own advertisement!");
                            ScanRecord record = result.getScanRecord();
                            if (record != null) {
                                String tag = extractPhoneFromAdvertisement(record);
                                if (tag != null) {
                                    Log.d(TAG, "✅ SELF-TEST SUCCESS: Service detected");
                                } else {
                                    Log.d(TAG, "❌ SELF-TEST FAILED: Service missing");
                                }
                            }
                        }

                        @Override
                        public void onScanFailed(int errorCode) {
                            Log.e(TAG, "Self-scan failed: " + errorCode);
                        }
                    };

                    // ✅ Android 12+ permission guard + try/catch
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            if (!hasPermission(Manifest.permission.BLUETOOTH_SCAN)) {
                                notifyError("Nearby Devices permission required to scan (self-test)");
                                return;
                            }
                        }
                        if (bluetoothLeScanner == null && bluetoothAdapter != null) {
                            try {
                                bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
                            } catch (SecurityException se) {
                                notifyError("Nearby Devices permission required to get BLE scanner");
                                return;
                            }
                        }
                        bluetoothLeScanner.startScan(filters, settings, testCallback);
                    } catch (SecurityException se) {
                        notifyError("Permission needed: BLUETOOTH_SCAN for BLE self-test scanning");
                        Log.e(TAG, "SecurityException during self-scan", se);
                        return;
                    } catch (Exception e) {
                        Log.e(TAG, "Unexpected self-scan error", e);
                        return;
                    }

                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        try {
                            if (bluetoothLeScanner != null) {
                                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                                        hasPermission(Manifest.permission.BLUETOOTH_SCAN)) {
                                    bluetoothLeScanner.stopScan(testCallback);
                                }
                            }
                        } catch (SecurityException ignored) {
                            // ignore; we already surfaced the permission error
                        }
                        Log.d(TAG, "=== SELF-TEST COMPLETE ===");
                    }, 3000);
                }

            } catch (Exception e) {
                Log.e(TAG, "Self-test error", e);
            }
        }).start();
    }


    // ✅ Convert advertising error codes to readable text
    private String getAdvertiseErrorString(int errorCode) {
        switch (errorCode) {
            case AdvertiseCallback.ADVERTISE_FAILED_DATA_TOO_LARGE:
                return "Data too large";
            case AdvertiseCallback.ADVERTISE_FAILED_TOO_MANY_ADVERTISERS:
                return "Too many advertisers";
            case AdvertiseCallback.ADVERTISE_FAILED_ALREADY_STARTED:
                return "Already started";
            case AdvertiseCallback.ADVERTISE_FAILED_INTERNAL_ERROR:
                return "Internal error";
            case AdvertiseCallback.ADVERTISE_FAILED_FEATURE_UNSUPPORTED:
                return "Feature unsupported";
            default:
                return "Unknown error: " + errorCode;
        }
    }

    public void runBLEDiagnostic() {
        Log.d(TAG, "=== BLE DIAGNOSTIC ===");
        debugBluetoothStatus();
        validateServiceUUID();

        if (isAdvertising) {
            Log.d(TAG, "✅ We are currently advertising");
            testOwnAdvertisement();
        } else {
            Log.d(TAG, "❌ Not advertising - restarting...");
            startAdvertising();
        }

        Log.d(TAG, "🔄 Starting diagnostic discovery...");
        startDiscovery();

        handler.postDelayed(this::stopDiscovery, 10000);
    }

    public void cleanupDuplicateMessages() {
        new Thread(() -> {
            try {
                AppDatabase database = AppDatabase.getInstance(context);
                ChatMessageDao chatMessageDao = database.chatMessageDao();

                String currentUser = AuthenticationManager.getInstance(context).getAuthenticatedUser();
                if (currentUser != null) {
                    List<ChatMessage> allMessages = chatMessageDao.getMessagesForUser(currentUser);

                    Map<String, ChatMessage> uniqueMessages = new HashMap<>();
                    List<ChatMessage> messagesToDelete = new ArrayList<>();

                    for (ChatMessage message : allMessages) {
                        String messageKey = message.message + "_" + message.senderPhone + "_" + message.receiverPhone;
                        if (uniqueMessages.containsKey(messageKey)) {
                            ChatMessage existing = uniqueMessages.get(messageKey);
                            if (Math.abs(message.timestamp - existing.timestamp) < 10000) {
                                messagesToDelete.add(message);
                                Log.d(TAG, "🗑️ Mark duplicate for deletion: " + message.message);
                            }
                        } else {
                            uniqueMessages.put(messageKey, message);
                        }
                    }

                    for (ChatMessage duplicate : messagesToDelete) {
                        chatMessageDao.deleteMessage(duplicate.id);
                    }

                    Log.d(TAG, "✅ Cleaned " + messagesToDelete.size() + " duplicate messages");
                }
            } catch (Exception e) {
                Log.e(TAG, "Error cleaning up duplicate messages", e);
            }
        }).start();
    }

    public void testAdvertisingWithPhone(String phoneNumber) {
        Log.d(TAG, "🧪 TEST ADVERTISING WITH PHONE: " + phoneNumber);
        startAdvertisingWithPhone(phoneNumber);
        handler.postDelayed(this::testOwnAdvertisement, 2000);
    }

    public String findContactByShortPhone(String shortPhone) {
        try {
            List<DeviceMapping> allContacts = deviceMappingDao.getAllContacts();
            for (DeviceMapping contact : allContacts) {
                if (contact.phoneNumber != null && contact.phoneNumber.endsWith(shortPhone)) {
                    Log.d(TAG, "✅ MATCH short phone " + shortPhone + " to contact: " + contact.phoneNumber);
                    return contact.phoneNumber;
                }
            }
            Log.d(TAG, "No contact found for short phone: " + shortPhone);
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error finding contact by short phone", e);
            return null;
        }
    }

    public void debugEverything() {
        Log.d(TAG, "=== DEBUG EVERYTHING ===");
        Log.d(TAG, "Current Connected: " + currentConnectedDevice);
        Log.d(TAG, "Is Initiating: " + isInitiatingConnection);
        Log.d(TAG, "Chat Service State: " + (chatService != null ? chatService.getState() : -1));
        Log.d(TAG, "Is Connected: " + (chatService != null && chatService.isConnected()));
        Log.d(TAG, "Phone Map Size: " + phoneToDeviceMap.size());
        Log.d(TAG, "=== END DEBUG ===");
    }

    public boolean isConnectionHealthy() {
        return chatService != null && chatService.isConnected() && currentConnectedDevice != null;
    }

    public void debugConnectionHealth() {
        Log.d(TAG, "=== CONNECTION HEALTH ===");
        Log.d(TAG, "Chat Service: " + (chatService != null));
        Log.d(TAG, "Is Connected: " + (chatService != null && chatService.isConnected()));
        Log.d(TAG, "Current Device: " + currentConnectedDevice);
        Log.d(TAG, "Keep-alive Active: " + isKeepAliveActive());
        Log.d(TAG, "=== END HEALTH CHECK ===");
    }

    private boolean isKeepAliveActive() {
        return chatService != null && chatService.isConnected();
    }

    public void testStableConnection() {
        Log.d(TAG, "🧪 TESTING STABLE CONNECTION...");
        isInitiatingConnection = false;
        lastConnectionAttempt = 0;
        stopKeepAlive();
        stopDiscovery();
        if (chatService != null) chatService.start();
        Log.d(TAG, "✅ Ready for stable connection test");
    }

    public boolean sendBroadcastMessage(String message) {
        Log.d(TAG, "📢 Sending broadcast message: " + message);
        boolean sentToAny = false;
        for (String phoneNumber : phoneToDeviceMap.keySet()) {
            if (!phoneNumber.equals(currentConnectedDevice)) {
                try {
                    sendMessageToContact(phoneNumber, message);
                    sentToAny = true;
                    Log.d(TAG, "✅ Broadcast sent to: " + phoneNumber);
                } catch (Exception e) {
                    Log.d(TAG, "Broadcast failed for: " + phoneNumber);
                }
            }
        }
        return sentToAny;
    }

    public void updateAllConnectionStatuses() {
        for (String phoneNumber : phoneToDeviceMap.keySet()) {
            String status = getConnectionStatus(phoneNumber);
            final boolean isUp = status.equals("Connected") || status.equals("Online");
            final String pn = phoneNumber;
            if (meshCallback != null) {
                handler.post(() -> meshCallback.onConnectionStatusChanged(pn, isUp));
            }
        }
    }

    // =========================== Misc helpers ===========================

    public void setMeshCallback(MeshCallback callback) {
        this.meshCallback = callback;
        Log.d(TAG, "✅ Mesh callback set");
    }

    public boolean checkBluetoothPermissions() {
        try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "Missing ACCESS_FINE_LOCATION (pre-12 scanning)");
                // On Android 12+, location is not required for BLE scanning with Nearby; still keep as legacy
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (!hasPermission(Manifest.permission.BLUETOOTH_SCAN)) {
                    Log.e(TAG, "Missing BLUETOOTH_SCAN");
                    return false;
                }
                if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
                    Log.e(TAG, "Missing BLUETOOTH_CONNECT");
                    return false;
                }
                if (!hasPermission(Manifest.permission.BLUETOOTH_ADVERTISE)) {
                    Log.e(TAG, "Missing BLUETOOTH_ADVERTISE");
                    return false;
                }
            } else {
                if (!hasPermission(Manifest.permission.BLUETOOTH)) {
                    Log.e(TAG, "Missing BLUETOOTH");
                    return false;
                }
                if (!hasPermission(Manifest.permission.BLUETOOTH_ADMIN)) {
                    Log.e(TAG, "Missing BLUETOOTH_ADMIN");
                    return false;
                }
            }

            Log.d(TAG, "✅ All Bluetooth permissions granted (or acceptable)");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error checking permissions", e);
            return false;
        }
    }

    private void notifyError(String error) {
        Log.e(TAG, "❌ " + error);
        if (meshCallback != null) {
            handler.post(() -> meshCallback.onError(error));
        }
    }

    // =========================== End ===========================
}
