package com.example.rippletalk;

import org.json.JSONException;
import org.json.JSONObject;

public class MeshEnvelope {
    public static final String TYPE_MESSAGE = "MESSAGE";
    public static final String TYPE_ACK = "ACK";

    private String messageType = TYPE_MESSAGE;
    private String sourceId;
    private String destId;
    private String payload;
    private int hopCount;
    private String messageId;
    private String pathTaken;
    private boolean requiresAck;
    private long timestamp;

    public MeshEnvelope(String sourceId, String destId, String payload, int hopCount, boolean requiresAck) {
        this.sourceId = sourceId;
        this.destId = destId;
        this.payload = payload;
        this.hopCount = hopCount;
        this.requiresAck = requiresAck;
        this.messageId = generateMessageId();
        this.timestamp = System.currentTimeMillis();
        this.pathTaken = "";
    }

    // ACK constructor
    public MeshEnvelope(String originalMessageId, String ackSource, String ackDest, boolean ackStatus) {
        this.messageType = TYPE_ACK;
        this.sourceId = ackSource;
        this.destId = ackDest;
        this.payload = ackStatus ? "DELIVERED" : "FAILED";
        this.messageId = "ACK_" + originalMessageId;
        this.hopCount = 10;
        this.requiresAck = false;
        this.timestamp = System.currentTimeMillis();
        this.pathTaken = "";
    }

    private String generateMessageId() {
        return sourceId + "_" + System.currentTimeMillis() + "_" + payload.hashCode();
    }

    public String toJson() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("type", messageType);
            obj.put("source", sourceId);
            obj.put("dest", destId);
            obj.put("payload", CryptoManager.encrypt(payload));
            obj.put("hops", hopCount);
            obj.put("msgId", messageId);
            obj.put("timestamp", timestamp);
            obj.put("requiresAck", requiresAck);
            obj.put("path", pathTaken);
            return obj.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    public static MeshEnvelope fromJson(String json) {
        try {
            JSONObject obj = new JSONObject(json);
            String type = obj.optString("type", TYPE_MESSAGE);
            if (TYPE_ACK.equals(type)) {
                String ackFor = obj.getString("msgId").replace("ACK_", "");
                String source = obj.getString("source");
                String dest = obj.getString("dest");
                String status = obj.getString("payload");
                boolean ok = "DELIVERED".equals(status);
                MeshEnvelope ack = new MeshEnvelope(ackFor, source, dest, ok);
                ack.pathTaken = obj.optString("path", "");
                return ack;
            } else {
                String source = obj.getString("source");
                String dest = obj.getString("dest");
                String payload = CryptoManager.decrypt(obj.getString("payload"));
                int hops = obj.getInt("hops");
                boolean requiresAck = obj.optBoolean("requiresAck", false);

                MeshEnvelope env = new MeshEnvelope(source, dest, payload, hops, requiresAck);
                env.messageId = obj.optString("msgId", "");
                env.timestamp = obj.optLong("timestamp", System.currentTimeMillis());
                env.pathTaken = obj.optString("path", "");
                return env;
            }
        } catch (JSONException e) {
            return null;
        }
    }

    public void addPathStep(String interfaceType) {
        if (!pathTaken.isEmpty()) pathTaken += "→";
        pathTaken += interfaceType;
    }

    public boolean isAck() { return TYPE_ACK.equals(messageType); }
    public String getAckedMessageId() { return isAck() ? messageId.replace("ACK_", "") : null; }
    public void decrementHop() { hopCount--; }

    public String getSourceId() { return sourceId; }
    public String getDestId() { return destId; }
    public String getPayload() { return payload; }
    public int getHopCount() { return hopCount; }
    public String getMessageId() { return messageId; }
    public String getPathTaken() { return pathTaken; }
    public boolean requiresAck() { return requiresAck; }
}