package com.example.rippletalk;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface DeviceMappingDao {
    @Insert
    void insert(DeviceMapping mapping);

    @Update
    void update(DeviceMapping mapping);

    @Query("SELECT * FROM device_mappings WHERE phoneNumber = :phoneNumber")
    DeviceMapping getByPhoneNumber(String phoneNumber);

    @Query("SELECT * FROM device_mappings WHERE bluetoothAddress = :bluetoothAddress")
    DeviceMapping getByBluetoothAddress(String bluetoothAddress);

    // Get ALL contacts
    @Query("SELECT * FROM device_mappings")
    List<DeviceMapping> getAllContacts();

    // Get only paired devices
    @Query("SELECT * FROM device_mappings WHERE isPaired = 1")
    List<DeviceMapping> getAllPairedDevices();

    // Get unpaired contacts
    @Query("SELECT * FROM device_mappings WHERE isPaired = 0")
    List<DeviceMapping> getAllUnpairedContacts();

    @Query("DELETE FROM device_mappings WHERE phoneNumber = :phoneNumber")
    void deleteByPhoneNumber(String phoneNumber);

    @Query("SELECT COUNT(*) FROM device_mappings WHERE phoneNumber = :phoneNumber AND isPaired = 1")
    int isDevicePaired(String phoneNumber);

    // Mesh routing queries
    @Query("SELECT * FROM device_mappings WHERE lastSeen > :minTime")
    List<DeviceMapping> getRecentDevices(long minTime);

    @Query("UPDATE device_mappings SET hopCount = :hopCount, nextHop = :nextHop, lastRouteUpdate = :timestamp WHERE phoneNumber = :phoneNumber")
    void updateRoute(String phoneNumber, int hopCount, String nextHop, long timestamp);

    // Contact name functionality
    @Query("SELECT * FROM device_mappings WHERE contactName LIKE '%' || :query || '%' OR phoneNumber LIKE '%' || :query || '%'")
    List<DeviceMapping> searchContacts(String query);

    @Query("UPDATE device_mappings SET contactName = :contactName WHERE phoneNumber = :phoneNumber")
    void updateContactName(String phoneNumber, String contactName);

    @Query("SELECT * FROM device_mappings WHERE contactName IS NOT NULL AND contactName != '' ORDER BY contactName ASC")
    List<DeviceMapping> getContactsWithNames();

    // ✅ NEW: Update pairing status
    @Query("UPDATE device_mappings SET isPaired = :isPaired, bluetoothAddress = :bluetoothAddress WHERE phoneNumber = :phoneNumber")
    void updatePairingStatus(String phoneNumber, boolean isPaired, String bluetoothAddress);

    // ✅ NEW: Get contacts by connection status
    @Query("SELECT * FROM device_mappings WHERE isPaired = 1 ORDER BY lastSeen DESC")
    List<DeviceMapping> getPairedContactsByRecent();

    // ✅ ADD: Delete contact by ID (if you need it)
    @Query("DELETE FROM device_mappings WHERE phoneNumber = :phoneNumber")
    void deleteContact(String phoneNumber);

    // ✅ ADD: Check if contact exists
    @Query("SELECT COUNT(*) FROM device_mappings WHERE phoneNumber = :phoneNumber")
    int contactExists(String phoneNumber);

    // ✅ ADD: Get contacts by name pattern
    @Query("SELECT * FROM device_mappings WHERE contactName LIKE :namePattern")
    List<DeviceMapping> getContactsByName(String namePattern);

    // ✅ ADD: Update last seen timestamp
    @Query("UPDATE device_mappings SET lastSeen = :timestamp WHERE phoneNumber = :phoneNumber")
    void updateLastSeen(String phoneNumber, long timestamp);

    // ✅ ADD: Update signal strength
    @Query("UPDATE device_mappings SET signalStrength = :signalStrength WHERE phoneNumber = :phoneNumber")
    void updateSignalStrength(String phoneNumber, int signalStrength);

    // ✅ ADD: Get online contacts (seen recently)
    @Query("SELECT * FROM device_mappings WHERE lastSeen > :minTime AND isPaired = 1")
    List<DeviceMapping> getOnlineContacts(long minTime);

    // ✅ ADD: Clear all contacts (for testing/reset)
    @Query("DELETE FROM device_mappings")
    void deleteAllContacts();

    // ✅ ADD: Get contacts with custom names only
    @Query("SELECT * FROM device_mappings WHERE contactName IS NOT NULL AND contactName != '' AND contactName != phoneNumber")
    List<DeviceMapping> getCustomNamedContacts();

    // ✅ ADD: Update device name
    @Query("UPDATE device_mappings SET deviceName = :deviceName WHERE phoneNumber = :phoneNumber")
    void updateDeviceName(String phoneNumber, String deviceName);

    // ✅ ADD: Get contact count
    @Query("SELECT COUNT(*) FROM device_mappings")
    int getContactCount();

    // ✅ ADD: Get paired contact count
    @Query("SELECT COUNT(*) FROM device_mappings WHERE isPaired = 1")
    int getPairedContactCount();
}