package com.example.rippletalk;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PublicChatActivity extends AppCompatActivity {
    private static final String TAG = "PublicChatActivity";

    private RecyclerView publicMessagesRecyclerView;
    private RecyclerView onlineUsersRecyclerView;
    private EditText publicMessageInput;
    private ImageButton publicSendButton;
    private Button publicBackButton;
    private ImageButton openPanelButton, backButton;
    private ProgressBar publicProgressBar;
    private TextView onlineCountText;
    CardView sidePanel;
    private boolean isInRoom = false;

    private PublicChatAdapter chatAdapter;
    private OnlineUsersAdapter onlineUsersAdapter;
    private BluetoothMeshManager meshManager;
    private AuthenticationManager authManager;
    private List<PublicChatMessage> messagesList = new ArrayList<>();
    private List<OnlineUser> onlineUsersList = new ArrayList<>();

    private String currentUserName;
    private String currentUserPhone;
    private Handler refreshHandler = new Handler();
    private Handler userCleanupHandler = new Handler();

    // Track users and their last activity
    private Map<String, Long> userLastSeen = new HashMap<>();
    private Map<String, String> phoneToUsernameMap = new HashMap<>();
    private static final long USER_TIMEOUT = 120000; // 2 minutes

    // Simple duplicate prevention
    private Set<String> processedMessageIds = new HashSet<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_public_chat);

        // Initialize authentication
        authManager = AuthenticationManager.getInstance(this);

        // Check if user is authenticated
        if (!authManager.isUserAuthenticated()) {
            Log.e(TAG, "❌ User not authenticated - redirecting to login");
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Get user info with robust fallbacks
        currentUserPhone = authManager.getAuthenticatedUser();
        currentUserName = authManager.getUserName();

        // If no username from auth, try to get from SharedPreferences as fallback
        if (currentUserName == null || currentUserName.trim().isEmpty()) {
            SharedPreferences prefs = getSharedPreferences("OTP_Prefs", MODE_PRIVATE);
            currentUserName = prefs.getString("LAST_USER_NAME", null);
            Log.d(TAG, "🔄 Fallback username from prefs: " + currentUserName);
        }

        // If still no username, use phone number as display name
        if (currentUserName == null || currentUserName.trim().isEmpty()) {
            if (currentUserPhone != null) {
                currentUserName = "User_" + currentUserPhone.substring(Math.max(0, currentUserPhone.length() - 4));
                Log.d(TAG, "🔄 Generated username from phone: " + currentUserName);
            } else {
                currentUserName = "User";
                Log.d(TAG, "🔄 Using generic username");
            }
        }

        // Ensure we have phone number
        if (currentUserPhone == null) {
            SharedPreferences prefs = getSharedPreferences("OTP_Prefs", MODE_PRIVATE);
            currentUserPhone = prefs.getString("LAST_PHONE_NUMBER", null);
            Log.d(TAG, "🔄 Fallback phone from prefs: " + currentUserPhone);

            if (currentUserPhone == null) {
                currentUserPhone = "TEMP_" + System.currentTimeMillis();
                Log.d(TAG, "🔄 Using temporary phone: " + currentUserPhone);
            }
        }

        Log.d(TAG, "💬 Starting public chat as: " + currentUserName + " (" + currentUserPhone + ")");

        initializeViews();
        initializeManagers();
        startPublicChatDiscovery();
        openPanelButton = findViewById(R.id.openPanel);
        sidePanel = findViewById(R.id.sidePanel);
        backButton = findViewById(R.id.backButton);
        openPanelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sidePanel.getVisibility() == View.GONE) {
                    sidePanel.setVisibility(View.VISIBLE);
                    Log.d(TAG, "Panel opened");
                } else {
                    sidePanel.setVisibility(View.GONE);
                    Log.d(TAG, "Panel closed");
                }
            }
        });
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PublicChatActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void initializeViews() {
        publicMessagesRecyclerView = findViewById(R.id.publicMessagesRecyclerView);
        onlineUsersRecyclerView = findViewById(R.id.onlineUsersRecyclerView);
        publicMessageInput = findViewById(R.id.publicMessageInput);
        publicSendButton = findViewById(R.id.publicSendButton);
        publicBackButton = findViewById(R.id.publicBackButton);
        publicProgressBar = findViewById(R.id.publicProgressBar);
        onlineCountText = findViewById(R.id.onlineCountText);

        // Setup Messages RecyclerView
        publicMessagesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatAdapter = new PublicChatAdapter(messagesList, currentUserName);
        publicMessagesRecyclerView.setAdapter(chatAdapter);
        publicMessagesRecyclerView.setItemAnimator(null);
        // Setup Online Users RecyclerView
        onlineUsersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        onlineUsersAdapter = new OnlineUsersAdapter(onlineUsersList);
        onlineUsersRecyclerView.setAdapter(onlineUsersAdapter);

        setupJoinButton();

        publicSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
        publicSendButton.setEnabled(false);

        publicMessageInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent event) {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                    sendMessage();
                    return true;
                }
                return false;
            }
        });

        // Add current user to online list
        addOrUpdateOnlineUser(currentUserName, currentUserPhone, true);
        updateOnlineCount();
    }

    private void setupJoinButton() {
        // Use the back button as join button initially
        publicBackButton.setText("Join Room");
        publicBackButton.setTextSize(14);
        publicBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isInRoom) {
                    joinPublicRoom();
                } else {
                    leavePublicRoom();
                }
            }
        });
    }

    private void initializeManagers() {
        AppDatabase database = AppDatabase.getInstance(this);
        meshManager = new BluetoothMeshManager(this, database.deviceMappingDao());

        meshManager.setMeshCallback(new BluetoothMeshManager.MeshCallback() {
            @Override
            public void onMessageReceived(String fromPhone, String rawMessage) {
                Log.d(TAG, "📩 Raw message received from " + fromPhone + ": " + rawMessage);

                // ✅ FIX: Use the correct method that extracts message content
                MessageProcessor.ProcessedMessage processed = processIncomingMessage(fromPhone, rawMessage);

                if (processed != null) {
                    Log.d(TAG, "✅ Message processed - Type: " + processed.messageType +
                            ", User: " + processed.userName + ", Content: " + processed.content);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            handleProcessedMessage(processed);
                        }
                    });
                } else {
                    Log.d(TAG, "⏭️ Message filtered (duplicate or invalid): " + rawMessage);
                }
            }

            @Override
            public void onDeviceDiscovered(String phoneNumber, String bluetoothAddress, int rssi) {
                Log.d(TAG, "👤 Device discovered - Phone: " + phoneNumber + " MAC: " + bluetoothAddress + " RSSI: " + rssi);

                if (phoneNumber == null || phoneNumber.equals(currentUserPhone)) {
                    return;
                }

                broadcastUserPresence();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String userName = "User_" + phoneNumber.substring(Math.max(0, phoneNumber.length() - 4));
                        addOrUpdateOnlineUser(userName, phoneNumber, false);

                        if (isInRoom) {
                            addSystemMessage(userName + " discovered nearby");
                        }
                    }
                });
            }

            @Override
            public void onDeviceConnected(String phoneNumber) {
                Log.d(TAG, "🔗 Device connected: " + phoneNumber);

                if (phoneNumber == null || phoneNumber.equals(currentUserPhone)) {
                    return;
                }

                broadcastUserPresence();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String userName = phoneToUsernameMap.get(phoneNumber);
                        if (userName == null) {
                            userName = "User_" + phoneNumber.substring(Math.max(0, phoneNumber.length() - 4));
                            phoneToUsernameMap.put(phoneNumber, userName);
                        }
                        addOrUpdateOnlineUser(userName, phoneNumber, false);

                        if (isInRoom) {
                            addSystemMessage("✅ " + userName + " connected");
                        }
                    }
                });
            }

            @Override
            public void onDeviceDisconnected(String phoneNumber) {
                Log.d(TAG, "🔌 Device disconnected: " + phoneNumber);

                if (phoneNumber == null || phoneNumber.equals(currentUserPhone)) {
                    return;
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String userName = phoneToUsernameMap.get(phoneNumber);
                        if (userName != null && isInRoom) {
                            addSystemMessage("❌ " + userName + " disconnected");
                        }
                    }
                });
            }

            @Override
            public void onDiscoveryStarted() {
                Log.d(TAG, " Public chat discovery started");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        publicProgressBar.setVisibility(View.VISIBLE);
                        addSystemMessage(" Searching for nearby users...");
                    }
                });
            }

            @Override
            public void onDiscoveryStopped() {
                Log.d(TAG, " Public chat discovery stopped");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        publicProgressBar.setVisibility(View.GONE);
                    }
                });
            }

            @Override
            public void onMessageDeliveryStatus(String phoneNumber, boolean delivered, String messageId) {
                Log.d(TAG, "📨 Message delivery: " + phoneNumber + " - " + (delivered ? "DELIVERED" : "FAILED"));
            }

            @Override
            public void onConnectionStatusChanged(String phoneNumber, boolean connected) {
                Log.d(TAG, "🔗 Connection status: " + phoneNumber + " - " + (connected ? "CONNECTED" : "DISCONNECTED"));
            }

            @Override
            public void onDevicePaired(String phoneNumber) {
                Log.d(TAG, "🤝 Device paired: " + phoneNumber);
            }

            @Override
            public void onAdvertisingStarted() {
                Log.d(TAG, "📡 Public chat advertising started");
            }

            @Override
            public void onAdvertisingStopped() {
                Log.d(TAG, "📡 Public chat advertising stopped");
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Public chat error: " + error);
                // Ignore connection errors - they're normal in Bluetooth
                if (error.contains("Connection failed")) {
                    Log.d(TAG, "🔗 Bluetooth connection error (normal)");
                }
            }
        });
    }

    /**
     * ✅ FIX: Process incoming messages with proper content extraction
     */
    private MessageProcessor.ProcessedMessage processIncomingMessage(String fromPhone, String rawMessage) {
        try {
            // Skip our own messages
            if (fromPhone.equals(currentUserPhone)) {
                return null;
            }

            // Extract actual message content from raw format
            String actualMessage = extractActualMessage(rawMessage);
            if (actualMessage.isEmpty()) {
                return null;
            }

            Log.d(TAG, "🔍 Processing message: " + actualMessage);

            // Use MessageProcessor to parse the message
            return MessageProcessor.processMessage(fromPhone, actualMessage);

        } catch (Exception e) {
            Log.e(TAG, "❌ Error processing message", e);
            return null;
        }
    }

    /**
     * ✅ FIX: Extract actual message content from raw format
     */
    private String extractActualMessage(String rawMessage) {
        if (rawMessage == null || rawMessage.trim().isEmpty()) {
            return "";
        }

        // Handle format: "9527887311:ROOM|CHAT|harshu|bola"
        // We need to extract "ROOM|CHAT|harshu|bola" from "9527887311:ROOM|CHAT|harshu|bola"
        String[] parts = rawMessage.split(":", 2);
        if (parts.length == 2) {
            String extractedMessage = parts[1];
            Log.d(TAG, "✅ Extracted message: '" + extractedMessage + "' from: '" + rawMessage + "'");
            return extractedMessage;
        }

        // If no phone prefix, return as is
        return rawMessage;
    }

    /**
     * Handle processed messages with SIMPLE duplicate check
     */
    private void handleProcessedMessage(MessageProcessor.ProcessedMessage message) {
        if (message == null) return;

        Log.d(TAG, "🎯 Handling processed message - Type: " + message.messageType +
                ", User: " + message.userName + ", Content: " + message.content);

        // ✅ SIMPLE DUPLICATE CHECK - Check last few messages
        if (isDuplicateInUI(message.userName, message.content)) {
            Log.d(TAG, "⏭️ Skipping duplicate message from UI: " + message.content);
            return;
        }

        // Update user mapping and activity
        phoneToUsernameMap.put(message.senderPhone, message.userName);
        updateUserActivity(message.userName);

        // Handle presence messages even when not in room
        if (message.messageType.equals(MessageProcessor.TYPE_PRESENCE)) {
            addOrUpdateOnlineUser(message.userName, message.senderPhone, false);
            return;
        }

        // For other messages, only process if in room
        if (!isInRoom) {
            Log.d(TAG, "⏸️ Not in room, ignoring message type: " + message.messageType);
            return;
        }

        switch (message.messageType) {
            case MessageProcessor.TYPE_JOIN:
                addOrUpdateOnlineUser(message.userName, message.senderPhone, false);
                addSystemMessage(" " + message.userName + " joined the room");
                break;

            case MessageProcessor.TYPE_LEAVE:
                removeOnlineUser(message.senderPhone);
                addSystemMessage(" " + message.userName + " left the room");
                break;

            case MessageProcessor.TYPE_CHAT:
                Log.d(TAG, " Adding CHAT message to UI: " + message.userName + " - " + message.content);
                addChatMessage(message.userName, message.content, false);
                break;

            default:
                Log.w(TAG, " Unknown message type: " + message.messageType);
        }
    }

    /**
     * Simple duplicate check in UI
     */
    private boolean isDuplicateInUI(String userName, String message) {
        long currentTime = System.currentTimeMillis();

        // Check last 3 messages for duplicates within 2 seconds
        int checkCount = Math.min(3, messagesList.size());
        for (int i = messagesList.size() - 1; i >= Math.max(0, messagesList.size() - checkCount); i--) {
            PublicChatMessage existing = messagesList.get(i);
            if (existing.userName.equals(userName) &&
                    existing.message.equals(message) &&
                    (currentTime - existing.timestamp) < 2000) {
                return true;
            }
        }
        return false;
    }

    private void startPublicChatDiscovery() {
        Log.d(TAG, " Starting public chat discovery");

        publicProgressBar.setVisibility(View.VISIBLE);

        meshManager.startAdvertising();
        meshManager.startDiscovery();

        startPeriodicTasks();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                publicProgressBar.setVisibility(View.GONE);
                addSystemMessage("✅ Click 'Join Room' to start chatting with nearby users");
            }
        }, 3000);
    }

    private void joinPublicRoom() {
        if (isInRoom) {
            return;
        }

        isInRoom = true;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                publicSendButton.setEnabled(true);
                publicBackButton.setText("Leave Room");

                // Clear previous messages when joining
                messagesList.clear();
                chatAdapter.notifyDataSetChanged();

                addSystemMessage(" YOU JOINED THE PUBLIC CHAT ROOM!");
                addSystemMessage(" Start chatting with nearby users...");
            }
        });

        // Broadcast join message to all users
        String joinMessage = formatRoomMessage("JOIN", currentUserName + " joined the room");
        broadcastMessageToAll(joinMessage);
        broadcastUserPresence();
    }

    private void leavePublicRoom() {
        if (!isInRoom) {
            return;
        }

        isInRoom = false;

        // Broadcast leave message
        String leaveMessage = formatRoomMessage("LEAVE", currentUserName + " left the room");
        broadcastMessageToAll(leaveMessage);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                publicSendButton.setEnabled(false);
                publicBackButton.setText("Join Room");

                addSystemMessage(" You left the public chat room");
                addSystemMessage(" Click 'Join Room' to chat again");
            }
        });
    }

    private void sendMessage() {
        if (!isInRoom) {
            Toast.makeText(this, "Please join the room first", Toast.LENGTH_SHORT).show();
            return;
        }

        String message = publicMessageInput.getText().toString().trim();
        if (TextUtils.isEmpty(message)) {
            return;
        }

        publicMessageInput.setText("");
        addChatMessage(currentUserName, message, true);

        String publicMessage = formatRoomMessage("CHAT", message);
        boolean sent = broadcastMessageToAll(publicMessage);

        if (sent) {
            Log.d(TAG, " Message broadcasted to room: " + message);
        } else {
            Log.d(TAG, " No other users online, message saved locally");
        }

        updateUserActivity(currentUserName);
    }

    private boolean broadcastMessageToAll(String message) {
        Log.d(TAG, " Broadcasting message: " + message);

        try {
            boolean sentToAny = false;
            int sentCount = 0;

            for (OnlineUser user : onlineUsersList) {
                if (!user.isSelf && !user.phoneNumber.equals(currentUserPhone)) {
                    Log.d(TAG, " Sending to: " + user.userName + " (" + user.phoneNumber + ")");

                    // Add phone prefix for proper routing
                    String formattedMessage = currentUserPhone + ":" + message;
                    boolean success = meshManager.sendMessageToContact(user.phoneNumber, formattedMessage);

                    if (success) {
                        sentToAny = true;
                        sentCount++;
                        Log.d(TAG, "✅ Message sent to: " + user.userName);
                    } else {
                        Log.d(TAG, "❌ Failed to send to: " + user.userName);
                    }
                }
            }

            Log.d(TAG, " Message sent to " + sentCount + " users");
            return sentToAny;

        } catch (Exception e) {
            Log.e(TAG, " Error in broadcast: " + e.getMessage());
            return false;
        }
    }

    private void addChatMessage(String userName, String message, boolean isOwnMessage) {
        Log.d(TAG, "💬 Adding message to UI - User: " + userName + ", Message: " + message + ", Own: " + isOwnMessage);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    PublicChatMessage chatMessage = new PublicChatMessage(userName, message, System.currentTimeMillis(), isOwnMessage);
                    messagesList.add(chatMessage);
                    chatAdapter.notifyItemInserted(messagesList.size() - 1);

                    publicMessagesRecyclerView.scrollToPosition(messagesList.size() - 1);
                    Log.d(TAG, "✅ Message added to UI. Total messages: " + messagesList.size());

                    // Debug: Check if message is actually in the list
                    if (messagesList.contains(chatMessage)) {
                        Log.d(TAG, "✅ Message confirmed in messagesList");
                    } else {
                        Log.d(TAG, "❌ Message NOT in messagesList!");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "❌ Error adding message to UI", e);
                }
            }
        });
    }

    private void addSystemMessage(String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                PublicChatMessage systemMessage = new PublicChatMessage("System", message, System.currentTimeMillis(), false);
                systemMessage.setSystemMessage(true);
                messagesList.add(systemMessage);
                chatAdapter.notifyItemInserted(messagesList.size() - 1);
                publicMessagesRecyclerView.scrollToPosition(messagesList.size() - 1);
            }
        });
    }
    private void scrollToBottomIfNeeded() {
        if (publicMessagesRecyclerView != null && messagesList.size() > 0) {
            publicMessagesRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    LinearLayoutManager layoutManager = (LinearLayoutManager) publicMessagesRecyclerView.getLayoutManager();
                    if (layoutManager != null) {
                        int lastVisiblePosition = layoutManager.findLastCompletelyVisibleItemPosition();
                        int totalItemCount = layoutManager.getItemCount();

                        // More relaxed scrolling - scroll if within last 5 messages
                        // or if the new message is from the current user
                        boolean shouldScroll = lastVisiblePosition >= totalItemCount - 5;

                        if (shouldScroll) {
                            publicMessagesRecyclerView.smoothScrollToPosition(totalItemCount - 1);
                            Log.d(TAG, "🔽 Auto-scrolling to bottom");
                        } else {
                            Log.d(TAG, "⏸️ Not auto-scrolling - user is reading older messages");
                        }
                    }
                }
            });
        }
    }
    private void addOrUpdateOnlineUser(String userName, String phoneNumber, boolean isSelf) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Update user activity using USERNAME as key
                updateUserActivity(userName);
                phoneToUsernameMap.put(phoneNumber, userName);

                // Check if user already exists
                for (int i = 0; i < onlineUsersList.size(); i++) {
                    if (onlineUsersList.get(i).userName.equals(userName)) {
                        // Update existing user
                        onlineUsersList.get(i).lastSeen = System.currentTimeMillis();
                        onlineUsersAdapter.notifyItemChanged(i);
                        updateOnlineCount();
                        Log.d(TAG, "👤 Updated existing user: " + userName);
                        return;
                    }
                }

                // Add new user
                OnlineUser newUser = new OnlineUser(userName, phoneNumber, System.currentTimeMillis(), isSelf);
                onlineUsersList.add(newUser);
                onlineUsersAdapter.notifyItemInserted(onlineUsersList.size() - 1);
                updateOnlineCount();

                Log.d(TAG, "👤 New user online: " + userName);
            }
        });
    }

    private void removeOnlineUser(String phoneNumber) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String userName = phoneToUsernameMap.get(phoneNumber);
                if (userName == null) return;

                for (int i = 0; i < onlineUsersList.size(); i++) {
                    if (onlineUsersList.get(i).userName.equals(userName)) {
                        onlineUsersList.remove(i);
                        onlineUsersAdapter.notifyItemRemoved(i);
                        userLastSeen.remove(userName);
                        phoneToUsernameMap.remove(phoneNumber);
                        updateOnlineCount();
                        Log.d(TAG, "👤 User offline: " + userName);
                        break;
                    }
                }
            }
        });
    }

    private void updateOnlineCount() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (onlineCountText != null) {
                    int onlineCount = onlineUsersList.size();
                    onlineCountText.setText("Online: " + onlineCount + " users");
                }
            }
        });
    }

    private void updateUserActivity(String userName) {
        userLastSeen.put(userName, System.currentTimeMillis());
        Log.d(TAG, "⏰ User activity updated: " + userName);
    }

    private void scrollToBottom() {
        if (publicMessagesRecyclerView != null && messagesList.size() > 0) {
            publicMessagesRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    publicMessagesRecyclerView.smoothScrollToPosition(messagesList.size() - 1);
                }
            });
        }
    }

    private String formatRoomMessage(String type, String content) {
        return MessageProcessor.formatRoomMessage(type, currentUserName, content);
    }

    private String formatPresenceMessage() {
        return MessageProcessor.formatPresenceMessage(currentUserName);
    }

    private void startPeriodicTasks() {
        // Broadcast presence every 30 seconds
        refreshHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "🔄 Periodic: Broadcasting presence");
                broadcastUserPresence();
                refreshHandler.postDelayed(this, 30000);
            }
        }, 30000);

        // Cleanup inactive users every 60 seconds
        userCleanupHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "🔄 Periodic: Cleaning up inactive users");
                cleanupInactiveUsers();
                userCleanupHandler.postDelayed(this, 60000);
            }
        }, 60000);
    }

    private void broadcastUserPresence() {
        String presenceMessage = formatPresenceMessage();
        broadcastMessageToAll(presenceMessage);
    }

    private void cleanupInactiveUsers() {
        long currentTime = System.currentTimeMillis();
        List<String> toRemove = new ArrayList<>();

        for (Map.Entry<String, Long> entry : userLastSeen.entrySet()) {
            long timeSinceLastSeen = currentTime - entry.getValue();

            // Don't remove current user
            if (entry.getKey().equals(currentUserName)) {
                continue;
            }

            if (timeSinceLastSeen > USER_TIMEOUT) {
                toRemove.add(entry.getKey());
                Log.d(TAG, "🧹 Cleaning up inactive user: " + entry.getKey() +
                        " (last seen " + timeSinceLastSeen + "ms ago)");
            }
        }

        for (String userName : toRemove) {
            // Find and remove user from online list
            for (int i = 0; i < onlineUsersList.size(); i++) {
                if (onlineUsersList.get(i).userName.equals(userName)) {
                    String phoneNumber = onlineUsersList.get(i).phoneNumber;
                    onlineUsersList.remove(i);
                    onlineUsersAdapter.notifyItemRemoved(i);
                    phoneToUsernameMap.remove(phoneNumber);
                    userLastSeen.remove(userName);
                    Log.d(TAG, "👤 Removed inactive user: " + userName);
                    break;
                }
            }
        }

        if (!toRemove.isEmpty()) {
            Log.d(TAG, "🧹 Cleaned up " + toRemove.size() + " inactive users");
        }

        updateOnlineCount();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Public chat resumed");

        if (meshManager != null) {
            meshManager.startAdvertising();
            meshManager.startDiscovery();
        }

        if (isInRoom) {
            broadcastUserPresence();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Public chat paused");

        if (meshManager != null) {
            meshManager.stopDiscovery();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Public chat destroyed");

        if (isInRoom) {
            leavePublicRoom();
        }

        if (meshManager != null) {
            meshManager.stopDiscovery();
            meshManager.stopAdvertising();
            meshManager.setMeshCallback(null);
        }

        refreshHandler.removeCallbacksAndMessages(null);
        userCleanupHandler.removeCallbacksAndMessages(null);
    }
}