package com.example.rippletalk;

import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class PublicChatAdapter extends RecyclerView.Adapter<PublicChatAdapter.MessageViewHolder> {

    private List<PublicChatMessage> messagesList;
    private String currentUserName;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private static final int VIEW_TYPE_SYSTEM = 0;
    private static final int VIEW_TYPE_OWN = 1;
    private static final int VIEW_TYPE_OTHER = 2;
    public PublicChatAdapter(List<PublicChatMessage> messagesList, String currentUserName) {
        this.messagesList = messagesList;
        this.currentUserName = currentUserName;
        setHasStableIds(true);
    }
    @Override
    public long getItemId(int position) {
        // Create unique stable ID for each message
        PublicChatMessage message = messagesList.get(position);
        return (message.userName + "|" + message.message + "|" + message.timestamp).hashCode();
    }
    @Override
    public int getItemViewType(int position) {
        PublicChatMessage message = messagesList.get(position);
        if (message.isSystemMessage) {
            return VIEW_TYPE_SYSTEM;
        } else if (message.isOwnMessage) {
            return VIEW_TYPE_OWN;
        } else {
            return VIEW_TYPE_OTHER;
        }
    }
    @Override
    public MessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_public_message, parent, false);
        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MessageViewHolder holder, int position) {
        PublicChatMessage message = messagesList.get(position);
        holder.bind(message);
    }

    @Override
    public int getItemCount() {
        return messagesList.size();
    }

    public void updateMessages(List<PublicChatMessage> newMessages) {
        int previousSize = messagesList.size();
        messagesList.clear();
        messagesList.addAll(newMessages);

        if (previousSize == 0) {
            notifyDataSetChanged();
        } else {
            notifyItemRangeChanged(0, messagesList.size());
        }
    }
    /*public void addMessage(PublicChatMessage message) {
        messagesList.add(message);
        notifyItemInserted(messagesList.size() - 1);
    }*/

    class MessageViewHolder extends RecyclerView.ViewHolder {
        private TextView userNameText;
        private TextView messageText;
        private TextView timeText;
        private View messageLayout;
        private LinearLayout rootLayout;

        public MessageViewHolder(View itemView) {
            super(itemView);
            userNameText = itemView.findViewById(R.id.userNameText);
            messageText = itemView.findViewById(R.id.messageText);
            timeText = itemView.findViewById(R.id.timeText);
            messageLayout = itemView.findViewById(R.id.messageLayout);
            rootLayout = itemView.findViewById(R.id.rootLayout);
        }

        public void bind(PublicChatMessage message) {

            if (message.isSystemMessage) {
                // System message styling
                rootLayout.setGravity(Gravity.CENTER_HORIZONTAL);
                userNameText.setVisibility(View.GONE);
                messageText.setText(message.message);
                timeText.setVisibility(View.GONE);
                messageLayout.setBackgroundColor(Color.TRANSPARENT);
                messageText.setTextColor(Color.parseColor("#666666"));
                messageText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);


            } else {
                // Regular message styling
                userNameText.setVisibility(View.VISIBLE);
                timeText.setVisibility(View.VISIBLE);

                userNameText.setText(message.userName);
                messageText.setText(message.message);
                timeText.setText(timeFormat.format(message.timestamp));
                if (message.isOwnMessage) {
                    // Own message - right aligned with blue background
                    rootLayout.setGravity(Gravity.END);
                    messageLayout.setBackgroundResource(R.drawable.msg_bg_user);
                    userNameText.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
                    messageText.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
                    timeText.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
                    userNameText.setTextColor(Color.parseColor("#333333"));
                    messageText.setTextColor(Color.BLACK);
                    timeText.setTextColor(Color.parseColor("#333333"));
                    /**/
                } else {
                    // Others' message - left aligned with light background
                    rootLayout.setGravity(Gravity.START);
                    messageLayout.setBackgroundResource(R.drawable.msg_bg);
                    userNameText.setTextColor(Color.parseColor("#333333"));
                    messageText.setTextColor(Color.BLACK);
                    timeText.setTextColor(Color.parseColor("#333333"));
                    userNameText.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
                    messageText.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
                    timeText.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
                }
            }
        }
    }
}