package com.example.rippletalk;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "device_mappings")
public class DeviceMapping {
    @PrimaryKey
    @NonNull
    public String phoneNumber;

    public String bluetoothAddress;
    public String deviceName;
    public String contactName; // NEW: User-defined contact name
    public long lastSeen;
    public boolean isPaired;
    public int hopCount;

    // Mesh routing fields
    public int signalStrength;
    public String nextHop;
    public boolean isRouter;
    public long lastRouteUpdate;

    public DeviceMapping(@NonNull String phoneNumber, String bluetoothAddress) {
        this.phoneNumber = phoneNumber;
        this.bluetoothAddress = bluetoothAddress;
        this.isPaired = false;
        this.lastSeen = System.currentTimeMillis();
        this.hopCount = 0;
        this.signalStrength = -100;
        this.nextHop = null;
        this.isRouter = true;
        this.lastRouteUpdate = System.currentTimeMillis();
        this.contactName = ""; // Initialize as empty
        this.deviceName = "Unknown Device";
    }

    // Helper method to get display name (contact name preferred, fallback to phone)
    public String getDisplayName() {
        if (contactName != null && !contactName.trim().isEmpty()) {
            return contactName.trim();
        }
        return phoneNumber;
    }

    // Helper to check if contact has a custom name
    public boolean hasCustomName() {
        return contactName != null && !contactName.trim().isEmpty();
    }
}