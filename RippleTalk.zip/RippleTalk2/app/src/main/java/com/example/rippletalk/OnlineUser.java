package com.example.rippletalk;

public class OnlineUser {
    public String userName;
    public String phoneNumber;
    public long lastSeen;
    public boolean isSelf;

    public OnlineUser(String userName, String phoneNumber, long lastSeen, boolean isSelf) {
        this.userName = userName;
        this.phoneNumber = phoneNumber;
        this.lastSeen = lastSeen;
        this.isSelf = isSelf;
    }
}