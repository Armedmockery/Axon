package com.example.rippletalk;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddContactDialog extends Dialog {
    private ContactManager contactManager;
    private ContactManager.ContactAddCallback callback;
    private EditText usernameInput, phoneInput;

    public AddContactDialog(Context context, ContactManager contactManager,
                            ContactManager.ContactAddCallback callback) {
        super(context);
        this.contactManager = contactManager;
        this.callback = callback;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_add_user);

        usernameInput = findViewById(R.id.usernameInput);
        phoneInput = findViewById(R.id.phoneInput);
        Button submitBtn = findViewById(R.id.submitBtn);
        Button cancelBtn = findViewById(R.id.cancelBtn);

        submitBtn.setOnClickListener(v -> addContact());
        cancelBtn.setOnClickListener(v -> dismiss());

        // Auto-focus on name field
        usernameInput.requestFocus();
    }

    private void addContact() {
        String contactName = usernameInput.getText().toString().trim();
        String phoneNumber = phoneInput.getText().toString().trim();

        if (TextUtils.isEmpty(contactName)) {
            Toast.makeText(getContext(), "Please enter contact name", Toast.LENGTH_SHORT).show();
            usernameInput.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(phoneNumber) || !phoneNumber.matches("^[0-9]{10,15}$")) {
            Toast.makeText(getContext(), "Please enter valid phone number (10-15 digits)", Toast.LENGTH_SHORT).show();
            phoneInput.requestFocus();
            return;
        }

        // Add contact with custom name
        contactManager.addContact(contactName, phoneNumber, new ContactManager.ContactAddCallback() {
            @Override
            public void onContactAdded(boolean success, String message) {
                if (success) {
                    dismiss();
                }
                Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}