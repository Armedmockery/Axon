package com.example.rippletalk;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ChatMessageDao {
    @Insert
    void insert(ChatMessage message);

    @Update
    void update(ChatMessage message);

    @Query("SELECT * FROM chat_messages WHERE (senderPhone = :phone OR receiverPhone = :phone) ORDER BY timestamp ASC")
    List<ChatMessage> getMessagesForUser(String phone);

    @Query("SELECT * FROM chat_messages WHERE (receiverPhone = :receiverPhone AND senderPhone = :senderPhone) OR (receiverPhone = :senderPhone AND senderPhone = :receiverPhone) ORDER BY timestamp ASC")
    List<ChatMessage> getChatHistory(String senderPhone, String receiverPhone);

    @Query("UPDATE chat_messages SET messageStatus = :status WHERE id = :messageId")
    void updateMessageStatus(int messageId, int status);

    @Query("DELETE FROM chat_messages")
    void deleteAll();

    // Add this to your ChatMessageDao interface
    @Query("DELETE FROM chat_messages WHERE id = :messageId")
    void deleteMessage(int messageId);


    // ✅ OR ADD BATCH DELETE BY CONTENT
    @Query("DELETE FROM chat_messages WHERE message LIKE '%ping%' OR message LIKE '%test message%' OR message LIKE '%hello from rippletalk%'")
    void deleteSystemMessages();

    @Query("SELECT * FROM chat_messages WHERE " +
            "((senderPhone = :user1 AND receiverPhone = :user2) OR " +
            "(senderPhone = :user2 AND receiverPhone = :user1)) AND " +
            "timestamp > :sinceTime " +
            "ORDER BY timestamp ASC")
    List<ChatMessage> getRecentMessagesBetweenUsers(String user1, String user2, long sinceTime);

}