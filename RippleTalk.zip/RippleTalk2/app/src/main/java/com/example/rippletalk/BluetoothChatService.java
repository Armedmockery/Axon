package com.example.rippletalk;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class BluetoothChatService {
    private static final String TAG = "BluetoothChatService";
    private static final String APP_NAME = "RippleTalk";
    private static final UUID MY_UUID = UUID.fromString("12345678-1234-1234-1234-123456789ABC");

    private final BluetoothAdapter bluetoothAdapter;
    private final Handler handler;
    private final Context appContext;

    private AcceptThread acceptThread;
    private ConnectThread connectThread;
    private ConnectedThread connectedThread;
    private int state;

    // Connection states
    public static final int STATE_NONE = 0;
    public static final int STATE_LISTEN = 1;
    public static final int STATE_CONNECTING = 2;
    public static final int STATE_CONNECTED = 3;
    public static final int STATE_DISCONNECTED = 4;

    public interface MessageListener {
        void onMessageReceived(String message);
        void onConnectionStatusChanged(int state);
        void onConnectionFailed();
        /**
         * Android 12+ permission/security issue surfaced here.
         * Example: Ask user for BLUETOOTH_CONNECT when operation is "connect socket to <device>".
         */
        default void onSecurityError(String[] missingPermissions, String operation, String detail) {}
        /** Generic errors (BT off / no adapter etc.). */
        default void onError(String title, String detail) {}
    }

    private MessageListener messageListener;

    public BluetoothChatService(Context context) {
        this.appContext = context.getApplicationContext();
        this.bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        this.state = STATE_NONE;
        this.handler = new Handler(Looper.getMainLooper());
    }

    public void setMessageListener(MessageListener listener) {
        this.messageListener = listener;
    }

    public synchronized void start() {
        Log.d(TAG, "Starting Bluetooth service");

        if (bluetoothAdapter == null) {
            emitError("Bluetooth not available", "Device has no BluetoothAdapter");
            setState(STATE_NONE);
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            emitError("Bluetooth is off", "Enable Bluetooth to start listening/connecting.");
            setState(STATE_NONE);
            return;
        }

        cancelSilently(connectThread);
        connectThread = null;

        cancelSilently(connectedThread);
        connectedThread = null;

        if (acceptThread == null) {
            acceptThread = new AcceptThread();
            acceptThread.start();
        }
        setState(STATE_LISTEN);
    }

    // Connect to a specific remote device (client role)
    public synchronized void connect(BluetoothDevice device) {
        final String op = "connect to device " + safeDeviceName(device);
        Log.d(TAG, "🔗 Connecting to: " + safeDeviceName(device));

        if (!preflightBtEnabled(op)) return;
        if (!requirePermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op)) {
            setState(STATE_NONE);
            return;
        }

        cancelSilently(connectThread);
        connectThread = null;

        cancelSilently(connectedThread);
        connectedThread = null;

        connectThread = new ConnectThread(device);
        connectThread.start();

        setState(STATE_CONNECTING);
    }

    public synchronized void connected(BluetoothSocket socket, BluetoothDevice device) {
        Log.d(TAG, "Connected to device: " + safeDeviceName(device));

        cancelSilently(connectThread);
        connectThread = null;

        cancelSilently(connectedThread);
        connectedThread = null;

        cancelSilently(acceptThread);
        acceptThread = null;

        connectedThread = new ConnectedThread(socket);
        connectedThread.start();

        setState(STATE_CONNECTED);
    }

    public synchronized void stop() {
        Log.d(TAG, "Stopping Bluetooth service");

        cancelSilently(connectThread);
        connectThread = null;

        cancelSilently(connectedThread);
        connectedThread = null;

        cancelSilently(acceptThread);
        acceptThread = null;

        setState(STATE_NONE);
    }

    public void write(byte[] out) {
        ConnectedThread r;
        synchronized (this) {
            if (state != STATE_CONNECTED) {
                Log.e(TAG, "Not connected, cannot send message");
                return;
            }
            r = connectedThread;
        }
        Log.d(TAG, "Writing message: " + new String(out));
        if (r != null) r.write(out);
    }

    private synchronized void setState(int newState) {
        state = newState;
        Log.d(TAG, "Connection state changed to: " + newState);
        if (messageListener != null) {
            handler.post(() -> messageListener.onConnectionStatusChanged(newState));
        }
    }

    private void connectionFailed() {
        Log.e(TAG, "Connection failed");
        if (messageListener != null) {
            handler.post(() -> messageListener.onConnectionFailed());
        }
        start(); // restart listening
    }

    private void connectionLost() {
        Log.e(TAG, "Connection lost");
        if (messageListener != null) {
            handler.post(() -> messageListener.onConnectionFailed());
        }
        start(); // restart listening
    }

    // ===================== Permissions & Safety helpers =====================

    private boolean hasBtConnect() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true; // no runtime CONNECT before 12
        return ContextCompat.checkSelfPermission(appContext, Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean requirePermissions(String[] perms, String operation) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(appContext, p) != PackageManager.PERMISSION_GRANTED) {
                emitSecurityError(perms, operation,
                        "Missing " + p + " for Android 12+ to " + operation);
                return false;
            }
        }
        return true;
    }

    private String safeDeviceName(BluetoothDevice device) {
        if (device == null) return "unknown";
        try {
            // BLUETOOTH_CONNECT required on Android 12+; fallback to address when denied
            return device.getName() != null ? device.getName() : device.getAddress();
        } catch (SecurityException se) {
            Log.w(TAG, "No BLUETOOTH_CONNECT; using address only");
            return device.getAddress();
        }
    }

    private boolean preflightBtEnabled(String op) {
        if (bluetoothAdapter == null) {
            emitError("Bluetooth not available", "No BluetoothAdapter while trying to " + op);
            return false;
        }
        if (!bluetoothAdapter.isEnabled()) {
            emitError("Bluetooth is off", "Turn on Bluetooth to " + op);
            return false;
        }
        return true;
    }

    private void emitSecurityError(String[] missing, String op, String detail) {
        Log.e(TAG, "Security error (" + op + "): " + detail);
        if (messageListener != null) {
            handler.post(() -> messageListener.onSecurityError(missing, op, detail));
        }
    }

    private void emitError(String title, String detail) {
        Log.e(TAG, title + ": " + detail);
        if (messageListener != null) {
            handler.post(() -> messageListener.onError(title, detail));
        }
    }

    private void cancelSilently(Thread t) {
        if (t == null) return;
        try {
            if (t instanceof AcceptThread) ((AcceptThread) t).cancel();
            else if (t instanceof ConnectThread) ((ConnectThread) t).cancel();
            else if (t instanceof ConnectedThread) ((ConnectedThread) t).cancel();
        } catch (Throwable ignored) {}
    }

    // ===================== Threads =====================

    private class AcceptThread extends Thread {
        private BluetoothServerSocket serverSocket;
        private volatile boolean isRunning = true;

        public AcceptThread() {
            BluetoothServerSocket tmp = null;
            final String op = "accept incoming connections (server listen)";
            try {
                if (!preflightBtEnabled(op)) return;
                if (!requirePermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op)) return;

                try {
                    tmp = bluetoothAdapter.listenUsingRfcommWithServiceRecord(APP_NAME, MY_UUID);
                    Log.d(TAG, "Server socket created using RFCOMM");
                } catch (SecurityException se) {
                    emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op,
                            "BLUETOOTH_CONNECT required to listen for RFCOMM");
                } catch (IOException e) {
                    Log.w(TAG, "RFCOMM listen failed, trying insecure: " + e.getMessage());
                    try {
                        tmp = bluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(APP_NAME, MY_UUID);
                        Log.d(TAG, "Server socket created using insecure RFCOMM");
                    } catch (SecurityException se2) {
                        emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op,
                                "BLUETOOTH_CONNECT required to listen insecure RFCOMM");
                    } catch (IOException ex2) {
                        Log.e(TAG, "All socket creation methods failed", ex2);
                    }
                }
            } catch (SecurityException se) {
                emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op, se.getMessage());
            }
            serverSocket = tmp;
        }

        public void run() {
            BluetoothSocket socket;
            Log.d(TAG, "AcceptThread started, waiting for connections");

            while (isRunning && state != STATE_CONNECTED) {
                try {
                    if (serverSocket == null) {
                        Log.e(TAG, "Server socket is null, stopping accept thread");
                        break;
                    }

                    socket = serverSocket.accept();
                    Log.d(TAG, "Incoming connection accepted from: " +
                            (socket != null ? safeDeviceName(socket.getRemoteDevice()) : "unknown"));

                    if (socket != null) {
                        synchronized (BluetoothChatService.this) {
                            switch (state) {
                                case STATE_LISTEN:
                                case STATE_CONNECTING:
                                    connected(socket, socket.getRemoteDevice());
                                    break;
                                case STATE_NONE:
                                case STATE_CONNECTED:
                                    try {
                                        socket.close();
                                        Log.d(TAG, "Closed unwanted socket");
                                    } catch (IOException e) {
                                        Log.e(TAG, "Could not close unwanted socket", e);
                                    }
                                    break;
                            }
                        }
                    }
                } catch (SecurityException se) {
                    emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                            "accept incoming connection", se.getMessage());
                    // Back off a bit to avoid tight loop
                    sleepQuiet(1000);
                } catch (IOException e) {
                    if (isRunning) {
                        Log.e(TAG, "Socket accept() failed, but continuing", e);
                        sleepQuiet(1000);
                    } else {
                        Log.d(TAG, "Socket accept() stopped due to shutdown");
                        break;
                    }
                }
            }

            Log.d(TAG, "AcceptThread ended");
        }

        public void cancel() {
            isRunning = false;
            try {
                if (serverSocket != null) {
                    serverSocket.close();
                    Log.d(TAG, "Server socket closed");
                }
            } catch (IOException e) {
                Log.e(TAG, "Socket close() of server failed", e);
            } catch (SecurityException se) {
                emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        "close server socket", se.getMessage());
            }
        }
    }

    private class ConnectThread extends Thread {
        private BluetoothSocket socket;
        private final BluetoothDevice device;

        public ConnectThread(BluetoothDevice device) {
            this.device = device;
            final String op = "create client socket to " + safeDeviceName(device);

            try {
                if (!preflightBtEnabled(op)) return;
                if (!requirePermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op)) return;

                try {
                    socket = device.createRfcommSocketToServiceRecord(MY_UUID);
                    Log.d(TAG, "Client socket created using secure RFCOMM");
                } catch (SecurityException se) {
                    emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op,
                            "BLUETOOTH_CONNECT required to create RFCOMM socket");
                } catch (IOException e) {
                    Log.w(TAG, "Secure RFCOMM failed, trying insecure: " + e.getMessage());
                    try {
                        socket = device.createInsecureRfcommSocketToServiceRecord(MY_UUID);
                        Log.d(TAG, "Client socket created using insecure RFCOMM");
                    } catch (SecurityException se2) {
                        emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op,
                                "BLUETOOTH_CONNECT required to create insecure RFCOMM socket");
                    } catch (IOException ex2) {
                        Log.e(TAG, "All socket creation methods failed", ex2);
                    }
                }
            } catch (SecurityException se) {
                emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op, se.getMessage());
            }
        }

        public void run() {
            final String op = "connect socket to " + safeDeviceName(device);
            Log.d(TAG, "ConnectThread started for: " + safeDeviceName(device));

            try {
                // Cancel discovery (reduces interference). Requires CONNECT on 12+ when touching adapter state.
                try {
                    bluetoothAdapter.cancelDiscovery();
                } catch (SecurityException se) {
                    emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                            "cancel discovery", se.getMessage());
                }

                if (socket == null) {
                    Log.e(TAG, "Socket is null, cannot connect");
                    connectionFailed();
                    return;
                }

                try {
                    socket.connect();
                    Log.d(TAG, "Socket connected successfully to: " + safeDeviceName(device));
                } catch (SecurityException se) {
                    emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, op, se.getMessage());
                    closeQuiet(socket);
                    connectionFailed();
                    return;
                } catch (IOException e) {
                    Log.e(TAG, "Socket connection failed: " + e.getMessage());

                    // Fallback reflection method (may fail on some devices/SDKs)
                    try {
                        Log.d(TAG, "Trying fallback connection method");
                        BluetoothSocket fallbackSocket = (BluetoothSocket) device.getClass()
                                .getMethod("createRfcommSocket", int.class)
                                .invoke(device, 1);
                        try {
                            fallbackSocket.connect();
                            synchronized (BluetoothChatService.this) {
                                connectThread = null;
                            }
                            connected(fallbackSocket, device);
                            return;
                        } catch (SecurityException se2) {
                            emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                                    "fallback connect", se2.getMessage());
                            closeQuiet(fallbackSocket);
                            connectionFailed();
                            return;
                        }
                    } catch (Exception fallbackException) {
                        Log.e(TAG, "Fallback connection also failed", fallbackException);
                    }

                    closeQuiet(socket);
                    connectionFailed();
                    return;
                }

                synchronized (BluetoothChatService.this) {
                    connectThread = null;
                }

                connected(socket, device);

            } catch (Throwable t) {
                Log.e(TAG, "Unexpected error in ConnectThread", t);
                closeQuiet(socket);
                connectionFailed();
            }
        }

        public void cancel() {
            closeQuiet(socket);
            Log.d(TAG, "Client socket closed");
        }
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket socket;
        private InputStream inputStream;
        private OutputStream outputStream;
        private volatile boolean isRunning = true;

        public ConnectedThread(BluetoothSocket socket) {
            this.socket = socket;
            try {
                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream();
                Log.d(TAG, "Streams obtained successfully");
            } catch (SecurityException se) {
                emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        "get input/output streams", se.getMessage());
            } catch (IOException e) {
                Log.e(TAG, "Temp sockets not created", e);
            }
        }

        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;
            Log.d(TAG, "ConnectedThread started, waiting for messages");

            while (isRunning) {
                try {
                    if (inputStream == null) {
                        Log.e(TAG, "InputStream is null, terminating read loop");
                        break;
                    }
                    bytes = inputStream.read(buffer);
                    if (bytes == -1) {
                        Log.d(TAG, "End of stream reached, connection closed");
                        break;
                    }

                    String receivedMessage = new String(buffer, 0, bytes);
                    Log.d(TAG, "Message received: " + receivedMessage);

                    if (messageListener != null) {
                        handler.post(() -> messageListener.onMessageReceived(receivedMessage));
                    }
                } catch (SecurityException se) {
                    emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                            "read from socket", se.getMessage());
                    break;
                } catch (IOException e) {
                    if (isRunning) {
                        Log.e(TAG, "Connection lost: " + e.getMessage());
                        connectionLost();
                    }
                    break;
                }
            }

            Log.d(TAG, "ConnectedThread ended");
        }

        public void write(byte[] buffer) {
            try {
                if (outputStream == null) {
                    Log.e(TAG, "OutputStream is null; cannot write");
                    return;
                }
                outputStream.write(buffer);
                Log.d(TAG, "Message sent successfully: " + new String(buffer));
            } catch (SecurityException se) {
                emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        "write to socket", se.getMessage());
            } catch (IOException e) {
                Log.e(TAG, "Exception during write: " + e.getMessage());
            }
        }

        public void cancel() {
            isRunning = false;
            closeQuiet(socket);
            Log.d(TAG, "Connected socket closed");
        }
    }

    // ===================== Utilities =====================

    private void sleepQuiet(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private void closeQuiet(BluetoothSocket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (IOException e) {
            Log.e(TAG, "close() of socket failed", e);
        } catch (SecurityException se) {
            emitSecurityError(new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                    "close socket", se.getMessage());
        }
    }

    public int getState() {
        return state;
    }

    public boolean isConnected() {
        return state == STATE_CONNECTED;
    }
}
