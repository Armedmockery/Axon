package com.example.rippletalk;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile extends AppCompatActivity {

    private TextView displayNameText, bluIdText, logoutBtn;
    private EditText genderInput, ageInput;
    private ImageButton backButton;
    private ImageView addPhoto;
    private CircleImageView profileImage;
    private String userName, userPhone;

    private ActivityResultLauncher<String> galleryLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Optional: only open if launched properly from menu
        boolean fromMenu = getIntent().getBooleanExtra("FROM_MENU", true);

        setContentView(R.layout.activity_profile);

        // Initialize UI
        displayNameText = findViewById(R.id.displayName);
        bluIdText = findViewById(R.id.phoneText);
        genderInput = findViewById(R.id.genderInput);
        ageInput = findViewById(R.id.ageInput);
        backButton = findViewById(R.id.backButton);
        logoutBtn = findViewById(R.id.logoutBtn);
        addPhoto = findViewById(R.id.addPhoto);
        profileImage = findViewById(R.id.profileImage);

        SharedPreferences prefs = getSharedPreferences("OTP_Prefs", MODE_PRIVATE);
        userName = prefs.getString("LAST_USER_NAME", "Unknown");
        userPhone = prefs.getString("LAST_PHONE_NUMBER", "N/A");
        String savedGender = prefs.getString("USER_GENDER", "");
        String savedAge = prefs.getString("USER_AGE", "");
        String savedPhotoUri = prefs.getString("USER_PHOTO_URI", null);

        // Set saved values
        displayNameText.setText(userName);
        bluIdText.setText(userPhone);
        genderInput.setText(savedGender);
        ageInput.setText(savedAge);

        if (savedPhotoUri != null) {
            profileImage.setImageURI(Uri.parse(savedPhotoUri));
        }

        // Launcher for selecting profile image
        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        profileImage.setImageURI(uri);
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putString("USER_PHOTO_URI", uri.toString());
                        editor.apply();
                        Toast.makeText(Profile.this, "Profile photo updated", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        // Add photo click
        addPhoto.setOnClickListener(v -> galleryLauncher.launch("image/*"));

        // Save gender and age when focus is lost
        genderInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) saveProfileData();
        });

        ageInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) saveProfileData();
        });

        // Back button
        backButton.setOnClickListener(v -> onBackPressed());

        // Logout button
        logoutBtn.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();

            Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Profile.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void saveProfileData() {
        String gender = genderInput.getText().toString().trim();
        String age = ageInput.getText().toString().trim();

        SharedPreferences prefs = getSharedPreferences("OTP_Prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("USER_GENDER", gender);
        editor.putString("USER_AGE", age);
        editor.apply();

        Toast.makeText(this, "Profile updated", Toast.LENGTH_SHORT).show();
    }
}
