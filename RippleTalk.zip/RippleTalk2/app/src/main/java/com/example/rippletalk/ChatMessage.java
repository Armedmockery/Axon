package com.example.rippletalk;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "chat_messages")
public class ChatMessage {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @NonNull
    public String senderPhone;

    @NonNull
    public String receiverPhone;

    public String message;
    public long timestamp;
    public int messageStatus; // 0=sent, 1=delivered, 2=read, 3=failed
    public boolean isIncoming;
    public int hopCount;

    public ChatMessage(@NonNull String senderPhone, @NonNull String receiverPhone, String message) {
        this.senderPhone = senderPhone;
        this.receiverPhone = receiverPhone;
        this.message = message;
        this.timestamp = System.currentTimeMillis();
        this.messageStatus = 0;
        this.isIncoming = false;
        this.hopCount = 0;
    }
}