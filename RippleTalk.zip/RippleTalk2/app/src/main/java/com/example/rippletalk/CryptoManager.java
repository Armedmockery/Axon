package com.example.rippletalk;

import android.util.Base64;
import android.util.Log;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.util.Arrays;

public class CryptoManager {
    private static final String TAG = "CryptoManager";
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";
    private static final String SECRET_KEY = "RippletalkMeshKey"; // Change this in production!

    private static SecretKeySpec generateKey() throws Exception {
        byte[] key = SECRET_KEY.getBytes("UTF-8");
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        key = sha.digest(key);
        key = Arrays.copyOf(key, 16); // Use only first 128 bit
        return new SecretKeySpec(key, ALGORITHM);
    }

    public static String encrypt(String data) {
        try {
            if (data == null) return null;
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, generateKey());
            byte[] encrypted = cipher.doFinal(data.getBytes());
            String result = Base64.encodeToString(encrypted, Base64.DEFAULT);
            Log.d(TAG, "✅ Encryption successful");
            return result;
        } catch (Exception e) {
            Log.e(TAG, "❌ Encryption failed: " + e.getMessage());
            return data; // Fallback to plaintext if encryption fails
        }
    }

    public static String decrypt(String encryptedData) {
        try {
            if (encryptedData == null) return null;
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, generateKey());
            byte[] decoded = Base64.decode(encryptedData, Base64.DEFAULT);
            byte[] decrypted = cipher.doFinal(decoded);
            String result = new String(decrypted);
            Log.d(TAG, "✅ Decryption successful");
            return result;
        } catch (Exception e) {
            Log.e(TAG, "❌ Decryption failed: " + e.getMessage());
            return encryptedData; // Fallback to plaintext if decryption fails
        }
    }
}