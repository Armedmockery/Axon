package com.example.rippletalk;

import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.MessageViewHolder> {

    private List<ChatMessage> messagesList;
    private String currentUserPhone;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());

    public ChatAdapter(List<ChatMessage> messagesList, String currentUserPhone) {
        this.messagesList = messagesList;
        this.currentUserPhone = currentUserPhone;
    }

    @Override
    public MessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message, parent, false);
        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MessageViewHolder holder, int position) {
        ChatMessage message = messagesList.get(position);
        holder.bind(message);
    }

    @Override
    public int getItemCount() {
        return messagesList.size();
    }

    public void updateMessages(List<ChatMessage> newMessages) {
        messagesList.clear();
        messagesList.addAll(newMessages);
        notifyDataSetChanged();
    }

    class MessageViewHolder extends RecyclerView.ViewHolder {
        private TextView messageText;
        private TextView timeText;
        private View messageLayout;

        public MessageViewHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.messageText);
            timeText = itemView.findViewById(R.id.timeText);
            messageLayout = itemView.findViewById(R.id.messageLayout);
        }

        public void bind(ChatMessage message) {
            messageText.setText(message.message);
            timeText.setText(timeFormat.format(message.timestamp));

            // Check if message is incoming or outgoing
            boolean isIncoming = !message.senderPhone.equals(currentUserPhone);
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) messageLayout.getLayoutParams();
            if (isIncoming) {
                // Incoming message (from others)
                messageLayout.setBackgroundResource(R.drawable.msg_bg);
                messageText.setTextColor(Color.BLACK);
                params.gravity = Gravity.START;
                timeText.setTextColor(Color.parseColor("#333333"));
            } else {
                // Outgoing message (from me)
                messageLayout.setBackgroundResource(R.drawable.msg_bg_user);
                messageText.setTextColor(Color.BLACK);
                params.gravity = Gravity.END;
                timeText.setTextColor(Color.parseColor("#333333"));
            }
        }
    }
}