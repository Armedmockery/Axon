package com.example.rippletalk;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ContactManager {
    private static final String TAG = "ContactManager";
    private DeviceMappingDao deviceMappingDao;
    private ChatMessageDao chatMessageDao;
    private BluetoothMeshManager meshManager;
    private Context context;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    // Callback for new messages
    private MessageReceivedCallback globalMessageCallback;

    // ✅ ADD: Callback for contact list updates
    private ContactsUpdateCallback contactsUpdateCallback;

    public interface MessageReceivedCallback {
        void onNewMessage(String fromPhone, String message);
    }

    // ✅ ADD: Interface for contact updates
    public interface ContactsUpdateCallback {
        void onContactsUpdated();
    }

    public ContactManager(Context context, DeviceMappingDao deviceMappingDao, ChatMessageDao chatMessageDao) {
        this.context = context;
        this.deviceMappingDao = deviceMappingDao;
        this.chatMessageDao = chatMessageDao;
        this.meshManager = new BluetoothMeshManager(context, deviceMappingDao);

        setupGlobalMessageHandling();
    }

    // ✅ ADD: Setter for contacts update callback
    public void setContactsUpdateCallback(ContactsUpdateCallback callback) {
        this.contactsUpdateCallback = callback;
    }

    // ✅ ADD: Global message handling setup
    private void setupGlobalMessageHandling() {
        meshManager.setMeshCallback(new BluetoothMeshManager.MeshCallback() {
            @Override
            public void onMessageReceived(String fromPhone, String message) {
                Log.d(TAG, "📩 GLOBAL: Message from " + fromPhone + ": " + message);

                // Save message to database
                saveIncomingMessage(fromPhone, message);

                // Notify UI about new message
                if (globalMessageCallback != null) {
                    mainHandler.post(() -> globalMessageCallback.onNewMessage(fromPhone, message));
                }

                // ✅ NOTIFY CONTACT LIST UPDATE
                notifyContactsUpdated();
            }

            @Override
            public void onDeviceDiscovered(String phoneNumber, String bluetoothAddress, int rssi) {
                Log.d(TAG, "🔍 Device discovered: " + phoneNumber);
                // Auto-connect to discovered devices for messaging
                handleDiscoveredDevice(phoneNumber, bluetoothAddress, rssi);

                // ✅ NOTIFY CONTACT LIST UPDATE
                notifyContactsUpdated();
            }

            @Override
            public void onDeviceConnected(String phoneNumber) {
                Log.d(TAG, "🔗 Connected to: " + phoneNumber);
                // ✅ NOTIFY CONTACT LIST UPDATE
                notifyContactsUpdated();
            }

            @Override
            public void onDevicePaired(String phoneNumber) {
                Log.d(TAG, "🤝 Device paired: " + phoneNumber);
                // ✅ NOTIFY CONTACT LIST UPDATE
                notifyContactsUpdated();
            }

            // Other required methods with minimal implementation
            @Override public void onDeviceDisconnected(String phoneNumber) {
                // ✅ NOTIFY CONTACT LIST UPDATE
                notifyContactsUpdated();
            }
            @Override public void onDiscoveryStarted() {}
            @Override public void onDiscoveryStopped() {}
            @Override public void onMessageDeliveryStatus(String phoneNumber, boolean delivered, String messageId) {}
            @Override public void onConnectionStatusChanged(String phoneNumber, boolean connected) {
                // ✅ NOTIFY CONTACT LIST UPDATE
                notifyContactsUpdated();
            }
            @Override public void onAdvertisingStarted() {}
            @Override public void onAdvertisingStopped() {}
            @Override public void onError(String error) {}
        });
    }

    // ✅ ADD: Helper method to notify contacts updated
    private void notifyContactsUpdated() {
        if (contactsUpdateCallback != null) {
            mainHandler.post(() -> contactsUpdateCallback.onContactsUpdated());
        }
    }

    // ✅ ADD: Auto-handle discovered devices
    private void handleDiscoveredDevice(String phoneNumber, String bluetoothAddress, int rssi) {
        executor.execute(() -> {
            try {
                // Auto-create contact if doesn't exist
                DeviceMapping contact = deviceMappingDao.getByPhoneNumber(phoneNumber);
                if (contact == null) {
                    contact = new DeviceMapping(phoneNumber, bluetoothAddress);
                    contact.contactName = phoneNumber; // Use phone as default name
                    contact.deviceName = "User " + phoneNumber.substring(phoneNumber.length() - 4);
                    contact.isPaired = true;
                    deviceMappingDao.insert(contact);
                    Log.d(TAG, "✅ Auto-created contact: " + phoneNumber);

                    // ✅ NOTIFY CONTACT LIST UPDATE
                    notifyContactsUpdated();
                } else {
                    // Update existing contact
                    contact.bluetoothAddress = bluetoothAddress;
                    contact.isPaired = true;
                    contact.lastSeen = System.currentTimeMillis();
                    deviceMappingDao.update(contact);

                    // ✅ NOTIFY CONTACT LIST UPDATE
                    notifyContactsUpdated();
                }

            } catch (Exception e) {
                Log.e(TAG, "Error handling discovered device", e);
            }
        });
    }

    // ✅ UPDATED: Contact add method with immediate notification
    public void addContact(String name, String phoneNumber, ContactAddCallback callback) {
        executor.execute(() -> {
            try {
                String cleanPhone = phoneNumber.replaceAll("[^0-9]", "");

                // Check if contact already exists
                DeviceMapping existing = deviceMappingDao.getByPhoneNumber(cleanPhone);
                if (existing != null) {
                    mainHandler.post(() -> callback.onContactAdded(false, "Contact '" + name + "' already exists"));
                    return;
                }

                // Create contact
                DeviceMapping newContact = new DeviceMapping(cleanPhone, "");
                newContact.contactName = name;
                newContact.deviceName = name;
                newContact.isPaired = false;
                newContact.lastSeen = System.currentTimeMillis();

                deviceMappingDao.insert(newContact);
                Log.d(TAG, "✅ Contact saved: " + name + " - " + cleanPhone);

                // ✅ NOTIFY THAT CONTACTS WERE UPDATED IMMEDIATELY
                notifyContactsUpdated();

                mainHandler.post(() -> callback.onContactAdded(true, "Contact '" + name + "' saved!"));

            } catch (Exception e) {
                Log.e(TAG, "Error adding contact", e);
                mainHandler.post(() -> callback.onContactAdded(false, "Error: " + e.getMessage()));
            }
        });
    }

    // ✅ ADD: Get only manual contacts
    public void getManualContacts(ContactsLoadCallback callback) {
        executor.execute(() -> {
            try {
                List<DeviceMapping> allContacts = deviceMappingDao.getAllContacts();
                List<DeviceMapping> manualContacts = new ArrayList<>();

                // Filter only contacts with custom names
                for (DeviceMapping contact : allContacts) {
                    if (contact.hasCustomName()) {
                        manualContacts.add(contact);
                    }
                }

                Log.d(TAG, "📱 Loaded " + manualContacts.size() + " manual contacts");
                mainHandler.post(() -> callback.onContactsLoaded(manualContacts));
            } catch (Exception e) {
                Log.e(TAG, "Error loading manual contacts", e);
                mainHandler.post(() -> callback.onContactsLoaded(new ArrayList<>()));
            }
        });
    }

    // ✅ ADD: Get all contacts (manual + auto-discovered)
    public void getAllContacts(ContactsLoadCallback callback) {
        executor.execute(() -> {
            try {
                List<DeviceMapping> allContacts = deviceMappingDao.getAllContacts();

                // Sort: manual contacts first, then by recent activity
                Collections.sort(allContacts, (c1, c2) -> {
                    // Manual contacts with custom names first
                    boolean c1Manual = c1.hasCustomName();
                    boolean c2Manual = c2.hasCustomName();

                    if (c1Manual && !c2Manual) return -1;
                    if (!c1Manual && c2Manual) return 1;

                    // Then by last seen (recent first)
                    return Long.compare(c2.lastSeen, c1.lastSeen);
                });

                Log.d(TAG, "📱 Loaded " + allContacts.size() + " total contacts");
                mainHandler.post(() -> callback.onContactsLoaded(allContacts));
            } catch (Exception e) {
                Log.e(TAG, "Error loading all contacts", e);
                mainHandler.post(() -> callback.onContactsLoaded(new ArrayList<>()));
            }
        });
    }

    // ✅ ADD: Start continuous discovery
    public void startContinuousDiscovery() {
        meshManager.startDiscovery();

        // Auto-restart discovery when it stops
        mainHandler.postDelayed(() -> {
            if (!meshManager.isScanning) {
                startContinuousDiscovery();
            }
        }, 30000);
    }

    // ✅ ADD: Stop continuous discovery
    public void stopContinuousDiscovery() {
        meshManager.stopDiscovery();
    }

    // ✅ ADD: Set global message callback
    public void setGlobalMessageCallback(MessageReceivedCallback callback) {
        this.globalMessageCallback = callback;
    }

    public void getContactStatus(String phoneNumber, ContactStatusCallback callback) {
        executor.execute(() -> {
            try {
                String cleanPhone = phoneNumber.replaceAll("[^0-9]", "");
                String status = "Offline";

                if (meshManager.isDeviceInRange(cleanPhone)) {
                    status = "Online";
                } else if (meshManager.isDeviceDiscovered(cleanPhone)) {
                    status = "Nearby";
                }

                final String finalStatus = status;
                mainHandler.post(() -> callback.onStatusReceived(finalStatus));
            } catch (Exception e) {
                Log.e(TAG, "Error getting contact status", e);
                mainHandler.post(() -> callback.onStatusReceived("Unknown"));
            }
        });
    }

    public void connectToContact(String phoneNumber, ConnectionCallback callback) {
        executor.execute(() -> {
            try {
                String cleanPhone = phoneNumber.replaceAll("[^0-9]", "");
                DeviceMapping contact = deviceMappingDao.getByPhoneNumber(cleanPhone);

                if (contact == null || !contact.hasCustomName()) {
                    mainHandler.post(() -> callback.onConnectionResult(false, "Contact not found"));
                    return;
                }

                Log.d(TAG, "🔍 Connecting to " + contact.contactName);

                // Strategy 1: If device is already known and in range, connect directly
                if (contact.isPaired && meshManager.isDeviceInRange(cleanPhone)) {
                    Log.d(TAG, "✅ Device known and in range - connecting directly");
                    meshManager.setTargetContact(cleanPhone);
                    mainHandler.post(() -> callback.onConnectionResult(true, "Connected directly"));
                    return;
                }

                // Strategy 2: Start targeted discovery for this specific contact
                Log.d(TAG, "🔍 Starting targeted discovery for: " + contact.contactName);
                startTargetedDiscovery(cleanPhone, callback);

            } catch (Exception e) {
                Log.e(TAG, "Error connecting to contact", e);
                mainHandler.post(() -> callback.onConnectionResult(false, "Error: " + e.getMessage()));
            }
        });
    }

    private void startTargetedDiscovery(String phoneNumber, ConnectionCallback callback) {
        // Set up temporary callback for this specific discovery
        BluetoothMeshManager.MeshCallback tempCallback = new BluetoothMeshManager.MeshCallback() {
            private boolean deviceFound = false;

            @Override
            public void onDeviceDiscovered(String discoveredPhone, String bluetoothAddress, int rssi) {
                Log.d(TAG, "🔍 Discovery found: " + discoveredPhone + " (looking for: " + phoneNumber + ")");

                if (discoveredPhone.equals(phoneNumber)) {
                    deviceFound = true;
                    Log.d(TAG, "✅ TARGET DEVICE FOUND: " + phoneNumber);

                    // Update contact with device info
                    updateContactDevice(phoneNumber, bluetoothAddress, rssi);

                    // Stop discovery immediately
                    meshManager.stopDiscovery();
                    meshManager.setMeshCallback(null);

                    // Set as target contact
                    meshManager.setTargetContact(phoneNumber);

                    // ✅ NOTIFY CONTACT LIST UPDATE
                    notifyContactsUpdated();

                    mainHandler.post(() -> callback.onConnectionResult(true, "Device found and connected"));
                }
            }

            @Override
            public void onDiscoveryStarted() {
                Log.d(TAG, "🎯 Targeted discovery started for: " + phoneNumber);
            }

            @Override
            public void onDiscoveryStopped() {
                if (!deviceFound) {
                    Log.d(TAG, "❌ Targeted discovery stopped - device not found: " + phoneNumber);
                    meshManager.setMeshCallback(null);
                    mainHandler.post(() -> callback.onConnectionResult(false, "Device not found"));
                }
            }

            // Other required methods
            @Override public void onMessageReceived(String fromPhone, String message) {}
            @Override public void onDeviceConnected(String phoneNumber) {}
            @Override public void onDeviceDisconnected(String phoneNumber) {}
            @Override public void onMessageDeliveryStatus(String phoneNumber, boolean delivered, String messageId) {}
            @Override public void onConnectionStatusChanged(String phoneNumber, boolean connected) {}
            @Override public void onDevicePaired(String phoneNumber) {}
            @Override public void onAdvertisingStarted() {}
            @Override public void onAdvertisingStopped() {}
            @Override public void onError(String error) {
                Log.e(TAG, "Targeted discovery error: " + error);
            }
        };

        // Set callback and start discovery
        meshManager.setMeshCallback(tempCallback);
        meshManager.startDiscovery();

        // Auto-stop after 10 seconds if device not found
        mainHandler.postDelayed(() -> {
            if (!meshManager.isScanning) return;

            meshManager.stopDiscovery();
            meshManager.setMeshCallback(null);
            mainHandler.post(() -> callback.onConnectionResult(false, "Device not found after search"));
        }, 10000);
    }

    private void updateContactDevice(String phoneNumber, String bluetoothAddress, int rssi) {
        try {
            DeviceMapping contact = deviceMappingDao.getByPhoneNumber(phoneNumber);
            if (contact != null) {
                contact.bluetoothAddress = bluetoothAddress;
                contact.isPaired = true;
                contact.lastSeen = System.currentTimeMillis();
                contact.signalStrength = rssi;
                deviceMappingDao.update(contact);
                Log.d(TAG, "✅ Updated device for: " + contact.contactName);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating contact device", e);
        }
    }

    public void sendMessageToContact(String targetPhone, String message, MessageSendCallback callback) {
        executor.execute(() -> {
            try {
                String cleanPhone = targetPhone.replaceAll("[^0-9]", "");

                // Check if contact exists
                DeviceMapping contact = deviceMappingDao.getByPhoneNumber(cleanPhone);
                if (contact == null || !contact.hasCustomName()) {
                    mainHandler.post(() -> callback.onMessageSent(false));
                    return;
                }

                // Save message locally
                saveOutgoingMessage(cleanPhone, message);

                // Send message
                boolean success = meshManager.sendMessageToContact(cleanPhone, message);

                mainHandler.post(() -> callback.onMessageSent(success));

                if (success) {
                    Log.d(TAG, "✅ Message sent to: " + contact.contactName);
                } else {
                    Log.d(TAG, "⏳ Message queued for: " + contact.contactName);
                }

            } catch (Exception e) {
                Log.e(TAG, "Error sending message", e);
                mainHandler.post(() -> callback.onMessageSent(false));
            }
        });
    }

    private void saveOutgoingMessage(String targetPhone, String message) {
        try {
            AuthenticationManager authManager = AuthenticationManager.getInstance(context);
            String currentUserPhone = authManager.getAuthenticatedUser();

            if (currentUserPhone != null) {
                ChatMessage chatMessage = new ChatMessage(currentUserPhone, targetPhone, message);
                chatMessage.isIncoming = false;
                chatMessage.messageStatus = 0; // Sent
                chatMessageDao.insert(chatMessage);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error saving outgoing message", e);
        }
    }

    // ✅ ADD: Save incoming message
    private void saveIncomingMessage(String fromPhone, String message) {
        try {
            AuthenticationManager authManager = AuthenticationManager.getInstance(context);
            String currentUserPhone = authManager.getAuthenticatedUser();

            if (currentUserPhone != null) {
                ChatMessage chatMessage = new ChatMessage(fromPhone, currentUserPhone, message);
                chatMessage.isIncoming = true;
                chatMessage.messageStatus = 1; // Delivered
                chatMessageDao.insert(chatMessage);

                Log.d(TAG, "💾 Saved incoming message from: " + fromPhone);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error saving incoming message", e);
        }
    }

    public BluetoothMeshManager getMeshManager() {
        return meshManager;
    }

    public void cleanup() {
        if (meshManager != null) {
            meshManager.cleanup();
        }
        if (executor != null) {
            executor.shutdown();
        }
    }

    // Callback interfaces
    public interface ContactAddCallback {
        void onContactAdded(boolean success, String message);
    }

    public interface ContactsLoadCallback {
        void onContactsLoaded(List<DeviceMapping> contacts);
    }

    public interface ContactStatusCallback {
        void onStatusReceived(String status);
    }

    public interface MessageSendCallback {
        void onMessageSent(boolean success);
    }

    public interface ConnectionCallback {
        void onConnectionResult(boolean success, String message);
    }
}